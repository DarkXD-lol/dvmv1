export type VMStatus = 'running' | 'stopped' | 'suspended' | 'provisioning' | 'error' | 'rebooting';

export type OSImage = 'ubuntu-24.04' | 'debian-12' | 'almalinux-9' | 'windows-2022' | 'arch-linux' | 'fedora-40' | 'alpine-3.20';

export interface VMInstance {
  id: string;
  name: string;
  vmid: number;
  status: VMStatus;
  os: OSImage;
  osName: string;
  ipAddress: string;
  ipv6Address?: string;
  node: string;
  vcpu: number;
  ramGB: number;
  diskGB: number;
  cpuUsagePct: number;
  ramUsagePct: number;
  diskUsagePct: number;
  networkRxMbps: number;
  networkTxMbps: number;
  uptimeSeconds: number;
  tags: string[];
  autoBackup: boolean;
  notes?: string;
  createdTime: string;
  expiryDate?: string;
  renewalDate?: string;
}

export interface HypervisorNode {
  id: string;
  name: string;
  region: string;
  status: 'online' | 'degraded' | 'maintenance' | 'offline';
  ipAddress: string;
  kvmVersion: string;
  totalVcpu: number;
  usedVcpu: number;
  totalRamGB: number;
  usedRamGB: number;
  totalStorageTB: number;
  usedStorageTB: number;
  vmCount: number;
  loadAverage: [number, number, number];
  uptimeDays: number;
}

export interface NetworkInterface {
  id: string;
  name: string;
  bridge: string;
  vlanId?: number;
  subnetCIDR: string;
  gateway: string;
  dhcpEnabled: boolean;
  totalIPs: number;
  usedIPs: number;
  type: 'public' | 'private' | 'isolated';
}

export interface FirewallRule {
  id: string;
  vmId?: string;
  direction: 'inbound' | 'outbound';
  action: 'ACCEPT' | 'DROP' | 'REJECT';
  protocol: 'TCP' | 'UDP' | 'ICMP' | 'ANY';
  portRange: string;
  sourceCIDR: string;
  description: string;
  enabled: boolean;
}

export interface StoragePool {
  id: string;
  name: string;
  type: 'nvme-raid10' | 'ceph-distributed' | 'zfs-pool' | 'nfs-backup';
  node: string;
  totalGB: number;
  usedGB: number;
  freeGB: number;
  health: 'HEALTH_OK' | 'HEALTH_WARN' | 'HEALTH_ERR';
}

export interface VMSnapshot {
  id: string;
  vmId: string;
  vmName: string;
  name: string;
  description: string;
  sizeMB: number;
  createdAt: string;
  type: 'manual' | 'scheduled';
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  target: string;
  status: 'success' | 'warning' | 'error';
  ipAddress: string;
}

export interface ClusterStats {
  totalVMs: number;
  runningVMs: number;
  totalNodes: number;
  onlineNodes: number;
  avgCpuUsagePct: number;
  avgRamUsagePct: number;
  totalStorageUsedTB: number;
  totalStorageCapacityTB: number;
  totalNetworkRxMbps: number;
  totalNetworkTxMbps: number;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: 'Administrator' | 'Cloud Engineer' | 'Read Only';
  avatarUrl: string;
  twoFactorEnabled: boolean;
  lastActive: string;
}

export interface AlertThresholdSettings {
  enabled: boolean;
  cpuLimitPct: number;
  ramLimitPct: number;
  notifyOnExceed: boolean;
  customVmLimits?: Record<string, { cpuLimitPct?: number; ramLimitPct?: number }>;
}

export type ViewTab = 'dashboard' | 'vms' | 'nodes' | 'global_map' | 'scheduled_tasks' | 'networking' | 'storage' | 'installer' | 'settings' | 'logs' | 'expiring' | 'broadcast' | 'maintenance';
