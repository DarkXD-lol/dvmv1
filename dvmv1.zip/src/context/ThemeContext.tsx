import React, { createContext, useContext, useState, useEffect } from 'react';

export interface GlowTargets {
  buttons: boolean;
  cards: boolean;
  sidebar: boolean;
  charts: boolean;
  progressBars: boolean;
  notifications: boolean;
  dialogs: boolean;
  inputs: boolean;
  logo: boolean;
  icons: boolean;
  activeNav: boolean;
}

export interface AmbientEffectsConfig {
  aurora: { enabled: boolean; intensity: number };
  floatingParticles: { enabled: boolean; density: 'low' | 'medium' | 'high' };
  neonLines: { enabled: boolean; intensity: number };
  circuitNetwork: { enabled: boolean; intensity: number };
  dataFlow: { enabled: boolean; speed: number };
  lightOrbs: { enabled: boolean; count: number };
  cursorGlow: { enabled: boolean; size: number };
  mouseParallax: { enabled: boolean; strength: number };
  glassReflections: { enabled: boolean; opacity: number };
  fog: { enabled: boolean; opacity: number };
  noiseTexture: { enabled: boolean; opacity: number };
  lightRays: { enabled: boolean; intensity: number };
}

export interface ScheduledSwitchingConfig {
  enabled: boolean;
  dayThemePreset: string;
  nightThemePreset: string;
  dayStartHour: number;
  nightStartHour: number;
}

export interface ThemeConfig {
  // Colors
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  glowColor: string;
  borderColor: string;
  successColor: string;
  warningColor: string;
  dangerColor: string;
  sidebarColor: string;
  cardColor: string;
  topNavColor: string;
  bgColor: string;
  textColor: string;

  // Glow Effects
  glowIntensity: number; // 0 - 100
  glowBlur: number; // 0 - 100 px
  glowOpacity: number; // 0 - 100
  enableGlow: boolean;
  glowTargets: GlowTargets;

  // Background Customization
  bgStyle: 'aurora' | 'solid' | 'gradient' | 'mesh' | 'particles' | 'circuit' | 'neonLines' | 'glass' | 'waves' | 'starfield' | 'customImage';
  customBgImage: string;
  bgImageDisplay: 'cover' | 'contain' | 'stretch';
  bgImageBlur: number; // 0 - 50 px
  bgImageBrightness: number; // 0 - 100 %
  bgImageOpacity: number; // 0 - 100 %
  bgImagePosition: 'center' | 'top' | 'bottom';
  bgImageAttachment: 'fixed' | 'scroll';

  // Typography
  fontFamily: 'Plus Jakarta Sans' | 'Inter' | 'Geist' | 'Poppins' | 'Manrope' | 'Outfit' | 'Space Grotesk' | 'Sora' | 'IBM Plex Sans';
  fontSizeScale: number; // 80 - 120 %
  fontWeight: 'normal' | 'medium' | 'semibold' | 'bold' | 'black';
  letterSpacing: 'tight' | 'normal' | 'wide' | 'widest';
  lineHeight: 'tight' | 'normal' | 'relaxed';

  // Ambient Effects
  ambientEffects: AmbientEffectsConfig;

  // Animation Settings
  bgAnimationSpeed: number; // 0.2 - 3.0
  transitionSpeed: number; // 0.1 - 1.0s
  pageTransitionStyle: 'fade' | 'scale' | 'slide' | 'sharedLayout' | 'blur';
  hoverIntensity: number; // 0 - 100
  cardLiftAmount: number; // 0 - 20px
  glowAnimationSpeed: number; // 0.2 - 3.0
  progressBarAnimation: boolean;
  rippleEffect: boolean;
  reducedMotion: boolean;

  // Panel Layout
  sidebarWidth: number; // 220 - 320 px
  layoutMode: 'compact' | 'comfortable' | 'spacious';
  borderRadius: number; // 0 - 36 px
  cardShadowIntensity: number; // 0 - 100
  glassBlurAmount: number; // 0 - 40 px
  iconStyle: 'outline' | 'glow' | 'solid';
  dashboardDensity: 'compact' | 'comfortable' | 'spacious';
  gridListDefaultView: 'grid' | 'table';

  // Theme Auto-Switching Schedule
  scheduledSwitching: ScheduledSwitchingConfig;

  // Legacy compatibility fields
  auroraIntensity: number;
  bgBrightness: number;
  borderGlow: number;
  particleDensity: 'low' | 'medium' | 'high';
  enableBgAnimations: boolean;
  enableFloatingLines: boolean;
  enableAmbientLighting: boolean;
}

export const DEFAULT_THEME: ThemeConfig = {
  primaryColor: '#8B5CF6',
  secondaryColor: '#3B82F6',
  accentColor: '#22D3EE',
  glowColor: '#8B5CF6',
  borderColor: 'rgba(255, 255, 255, 0.08)',
  successColor: '#22C55E',
  warningColor: '#F59E0B',
  dangerColor: '#EF4444',
  sidebarColor: '#0A0D16',
  cardColor: '#0D111E',
  topNavColor: '#0A0D16',
  bgColor: '#080A12',
  textColor: '#F1F5F9',

  glowIntensity: 85,
  glowBlur: 30,
  glowOpacity: 80,
  enableGlow: true,
  glowTargets: {
    buttons: true,
    cards: true,
    sidebar: true,
    charts: true,
    progressBars: true,
    notifications: true,
    dialogs: true,
    inputs: true,
    logo: true,
    icons: true,
    activeNav: true,
  },

  bgStyle: 'aurora',
  customBgImage: '',
  bgImageDisplay: 'cover',
  bgImageBlur: 0,
  bgImageBrightness: 80,
  bgImageOpacity: 100,
  bgImagePosition: 'center',
  bgImageAttachment: 'fixed',

  fontFamily: 'Plus Jakarta Sans',
  fontSizeScale: 100,
  fontWeight: 'bold',
  letterSpacing: 'normal',
  lineHeight: 'normal',

  ambientEffects: {
    aurora: { enabled: true, intensity: 75 },
    floatingParticles: { enabled: true, density: 'medium' },
    neonLines: { enabled: true, intensity: 65 },
    circuitNetwork: { enabled: true, intensity: 70 },
    dataFlow: { enabled: true, speed: 1.0 },
    lightOrbs: { enabled: true, count: 4 },
    cursorGlow: { enabled: true, size: 300 },
    mouseParallax: { enabled: true, strength: 1.0 },
    glassReflections: { enabled: true, opacity: 50 },
    fog: { enabled: true, opacity: 30 },
    noiseTexture: { enabled: true, opacity: 15 },
    lightRays: { enabled: true, intensity: 50 },
  },

  bgAnimationSpeed: 1.0,
  transitionSpeed: 0.3,
  pageTransitionStyle: 'fade',
  hoverIntensity: 80,
  cardLiftAmount: 4,
  glowAnimationSpeed: 1.0,
  progressBarAnimation: true,
  rippleEffect: true,
  reducedMotion: false,

  sidebarWidth: 260,
  layoutMode: 'comfortable',
  borderRadius: 24,
  cardShadowIntensity: 80,
  glassBlurAmount: 24,
  iconStyle: 'glow',
  dashboardDensity: 'comfortable',
  gridListDefaultView: 'grid',

  scheduledSwitching: {
    enabled: false,
    dayThemePreset: 'solarAmber',
    nightThemePreset: 'default',
    dayStartHour: 6,
    nightStartHour: 18,
  },

  auroraIntensity: 75,
  bgBrightness: 85,
  borderGlow: 70,
  particleDensity: 'medium',
  enableBgAnimations: true,
  enableFloatingLines: true,
  enableAmbientLighting: true,
};

export const PRESET_THEMES: Record<string, { name: string; config: Partial<ThemeConfig> }> = {
  default: {
    name: 'Cyber Purple (Default)',
    config: {
      primaryColor: '#8B5CF6',
      secondaryColor: '#3B82F6',
      accentColor: '#22D3EE',
      glowColor: '#8B5CF6',
      bgStyle: 'aurora',
      glowIntensity: 85,
      bgAnimationSpeed: 1.0,
      fontFamily: 'Plus Jakarta Sans',
      borderRadius: 24,
    }
  },
  cyanMatrix: {
    name: 'Electric Cyan',
    config: {
      primaryColor: '#06B6D4',
      secondaryColor: '#3B82F6',
      accentColor: '#67E8F9',
      glowColor: '#06B6D4',
      bgStyle: 'neonLines',
      glowIntensity: 90,
      bgAnimationSpeed: 1.2,
      fontFamily: 'Space Grotesk',
      borderRadius: 20,
    }
  },
  matrixGreen: {
    name: 'Matrix Emerald',
    config: {
      primaryColor: '#10B981',
      secondaryColor: '#059669',
      accentColor: '#34D399',
      glowColor: '#10B981',
      bgStyle: 'circuit',
      glowIntensity: 80,
      bgAnimationSpeed: 0.9,
      fontFamily: 'Inter',
      borderRadius: 16,
    }
  },
  solarAmber: {
    name: 'Solar Flare Amber',
    config: {
      primaryColor: '#F59E0B',
      secondaryColor: '#EC4899',
      accentColor: '#FBBF24',
      glowColor: '#F59E0B',
      bgStyle: 'mesh',
      glowIntensity: 85,
      bgAnimationSpeed: 1.0,
      fontFamily: 'Outfit',
      borderRadius: 28,
    }
  },
  deepOcean: {
    name: 'Deep Ocean Blue',
    config: {
      primaryColor: '#2563EB',
      secondaryColor: '#0284C7',
      accentColor: '#38BDF8',
      glowColor: '#2563EB',
      bgStyle: 'waves',
      glowIntensity: 75,
      bgAnimationSpeed: 0.8,
      fontFamily: 'Geist',
      borderRadius: 20,
    }
  },
  luxuryGold: {
    name: 'Luxury Dark Gold',
    config: {
      primaryColor: '#EAB308',
      secondaryColor: '#CA8A04',
      accentColor: '#FDE047',
      glowColor: '#EAB308',
      bgStyle: 'starfield',
      glowIntensity: 90,
      bgAnimationSpeed: 0.7,
      fontFamily: 'Poppins',
      borderRadius: 24,
    }
  },
  neonCyberpunk: {
    name: 'Neon Cyberpunk 2077',
    config: {
      primaryColor: '#F43F5E',
      secondaryColor: '#8B5CF6',
      accentColor: '#22D3EE',
      glowColor: '#F43F5E',
      bgStyle: 'neonLines',
      glowIntensity: 100,
      bgAnimationSpeed: 1.5,
      fontFamily: 'Space Grotesk',
      borderRadius: 12,
    }
  }
};

const GOOGLE_FONTS_MAP: Record<string, string> = {
  'Plus Jakarta Sans': 'Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800',
  'Inter': 'Inter:wght@300;400;500;600;700;800;900',
  'Geist': 'Geist:wght@300;400;500;600;700;800',
  'Poppins': 'Poppins:wght@300;400;500;600;700;800',
  'Manrope': 'Manrope:wght@300;400;500;600;700;800',
  'Outfit': 'Outfit:wght@300;400;500;600;700;800;900',
  'Space Grotesk': 'Space+Grotesk:wght@300;400;500;600;700',
  'Sora': 'Sora:wght@300;400;500;600;700;800',
  'IBM Plex Sans': 'IBM+Plex+Sans:wght@300;400;500;600;700',
};

interface ThemeContextType {
  theme: ThemeConfig;
  savedThemes: Record<string, ThemeConfig>;
  updateTheme: (updates: Partial<ThemeConfig>) => void;
  applyPreset: (presetKey: string) => void;
  resetTheme: () => void;
  saveCustomTheme: (name: string) => void;
  deleteCustomTheme: (name: string) => void;
  importThemeJSON: (jsonString: string) => boolean;
  exportThemeJSON: () => string;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<ThemeConfig>(() => {
    try {
      const saved = localStorage.getItem('dvm_theme_config');
      if (saved) {
        return { ...DEFAULT_THEME, ...JSON.parse(saved) };
      }
    } catch (e) {
      // Ignore
    }
    return DEFAULT_THEME;
  });

  const [savedThemes, setSavedThemes] = useState<Record<string, ThemeConfig>>(() => {
    try {
      const saved = localStorage.getItem('dvm_saved_themes');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      // Ignore
    }
    return {};
  });

  // Apply theme variables & font dynamically whenever theme changes
  useEffect(() => {
    const root = document.documentElement;
    const intensityRatio = theme.glowIntensity / 100;

    // CSS variables
    root.style.setProperty('--glow-primary', theme.primaryColor);
    root.style.setProperty('--glow-secondary', theme.secondaryColor);
    root.style.setProperty('--glow-accent', theme.accentColor);
    root.style.setProperty('--glow-color', theme.glowColor || theme.primaryColor);
    root.style.setProperty('--glow-success', theme.successColor);
    root.style.setProperty('--glow-warning', theme.warningColor);
    root.style.setProperty('--glow-danger', theme.dangerColor);
    root.style.setProperty('--glow-border', theme.borderColor);
    root.style.setProperty('--color-sidebar', theme.sidebarColor);
    root.style.setProperty('--color-card', theme.cardColor);
    root.style.setProperty('--color-topnav', theme.topNavColor);
    root.style.setProperty('--color-bg', theme.bgColor);
    root.style.setProperty('--color-text', theme.textColor);

    root.style.setProperty('--glow-intensity', intensityRatio.toString());
    root.style.setProperty('--glow-blur', `${theme.glowBlur || 30}px`);
    root.style.setProperty('--glow-opacity', ((theme.glowOpacity ?? 80) / 100).toString());
    root.style.setProperty('--glass-blur', `${theme.glassBlurAmount}px`);
    root.style.setProperty('--border-radius-custom', `${theme.borderRadius}px`);
    root.style.setProperty('--sidebar-width-custom', `${theme.sidebarWidth}px`);
    root.style.setProperty('--font-size-scale', `${theme.fontSizeScale}%`);
    root.style.setProperty('--transition-speed', `${theme.transitionSpeed}s`);

    // Dynamically load Google Font if requested
    if (theme.fontFamily && GOOGLE_FONTS_MAP[theme.fontFamily]) {
      const fontQuery = GOOGLE_FONTS_MAP[theme.fontFamily];
      let linkEl = document.getElementById('dvm-dynamic-font') as HTMLLinkElement | null;
      if (!linkEl) {
        linkEl = document.createElement('link');
        linkEl.id = 'dvm-dynamic-font';
        linkEl.rel = 'stylesheet';
        document.head.appendChild(linkEl);
      }
      linkEl.href = `https://fonts.googleapis.com/css2?family=${fontQuery}&display=swap`;
    }

    // Apply font-family to body
    document.body.style.fontFamily = `"${theme.fontFamily}", system-ui, -apple-system, sans-serif`;

    // Save to localStorage
    try {
      localStorage.setItem('dvm_theme_config', JSON.stringify(theme));
    } catch (e) {
      // Ignore
    }
  }, [theme]);

  // Handle scheduled switching if enabled
  useEffect(() => {
    if (!theme.scheduledSwitching?.enabled) return;

    const checkSchedule = () => {
      const currentHour = new Date().getHours();
      const { dayStartHour, nightStartHour, dayThemePreset, nightThemePreset } = theme.scheduledSwitching;
      
      const isDay = currentHour >= dayStartHour && currentHour < nightStartHour;
      const targetPresetKey = isDay ? dayThemePreset : nightThemePreset;

      if (PRESET_THEMES[targetPresetKey]) {
        setTheme(prev => ({ ...prev, ...PRESET_THEMES[targetPresetKey].config }));
      }
    };

    checkSchedule();
    const interval = setInterval(checkSchedule, 60000 * 15); // Check every 15 min
    return () => clearInterval(interval);
  }, [theme.scheduledSwitching]);

  const updateTheme = (updates: Partial<ThemeConfig>) => {
    setTheme(prev => ({ ...prev, ...updates }));
  };

  const applyPreset = (presetKey: string) => {
    if (PRESET_THEMES[presetKey]) {
      setTheme(prev => ({ ...prev, ...PRESET_THEMES[presetKey].config }));
    } else if (savedThemes[presetKey]) {
      setTheme(savedThemes[presetKey]);
    }
  };

  const resetTheme = () => {
    setTheme(DEFAULT_THEME);
  };

  const saveCustomTheme = (name: string) => {
    if (!name.trim()) return;
    const updated = { ...savedThemes, [name.trim()]: theme };
    setSavedThemes(updated);
    try {
      localStorage.setItem('dvm_saved_themes', JSON.stringify(updated));
    } catch (e) {
      // Ignore
    }
  };

  const deleteCustomTheme = (name: string) => {
    const updated = { ...savedThemes };
    delete updated[name];
    setSavedThemes(updated);
    try {
      localStorage.setItem('dvm_saved_themes', JSON.stringify(updated));
    } catch (e) {
      // Ignore
    }
  };

  const importThemeJSON = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed && typeof parsed === 'object') {
        setTheme(prev => ({ ...prev, ...parsed }));
        return true;
      }
    } catch (e) {
      // Invalid
    }
    return false;
  };

  const exportThemeJSON = (): string => {
    return JSON.stringify(theme, null, 2);
  };

  return (
    <ThemeContext.Provider 
      value={{ 
        theme, 
        savedThemes, 
        updateTheme, 
        applyPreset, 
        resetTheme, 
        saveCustomTheme, 
        deleteCustomTheme, 
        importThemeJSON, 
        exportThemeJSON 
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

