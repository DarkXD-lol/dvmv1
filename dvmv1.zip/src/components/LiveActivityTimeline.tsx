import React from 'react';
import { motion } from 'motion/react';
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Server, 
  Play, 
  Square, 
  RotateCcw, 
  Terminal, 
  Camera, 
  Archive, 
  User 
} from 'lucide-react';
import { ActivityLog } from '../types';

interface LiveActivityTimelineProps {
  logs: ActivityLog[];
}

export const LiveActivityTimeline: React.FC<LiveActivityTimelineProps> = ({ logs }) => {
  const getActionIcon = (action: string) => {
    const act = action.toLowerCase();
    if (act.includes('start')) return <Play className="w-3.5 h-3.5 text-[#10B981]" />;
    if (act.includes('stop')) return <Square className="w-3.5 h-3.5 text-[#F43F5E]" />;
    if (act.includes('reboot') || act.includes('restart')) return <RotateCcw className="w-3.5 h-3.5 text-[#3B82F6]" />;
    if (act.includes('ssh') || act.includes('terminal') || act.includes('console')) return <Terminal className="w-3.5 h-3.5 text-[#22D3EE]" />;
    if (act.includes('snapshot')) return <Camera className="w-3.5 h-3.5 text-[#A855F7]" />;
    if (act.includes('backup')) return <Archive className="w-3.5 h-3.5 text-[#8B5CF6]" />;
    return <Server className="w-3.5 h-3.5 text-[#22D3EE]" />;
  };

  return (
    <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.06)] pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-[#22D3EE]/15 text-[#22D3EE] border border-[#22D3EE]/30 shadow-sm">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-sans tracking-wide">Live Infrastructure Activity Timeline</h3>
            <p className="text-xs text-[#A1A1AA]">Real-time system events, audit trail logs, and operator actions</p>
          </div>
        </div>

        <span className="px-3 py-1 rounded-full bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 text-[10px] font-mono font-bold uppercase tracking-widest flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-ping" /> Live Sync
        </span>
      </div>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-gradient-to-b before:from-[#8B5CF6] before:via-[#3B82F6] before:to-transparent">
        {logs.slice(0, 10).map((log, idx) => (
          <motion.div
            key={log.id || idx}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="relative group flex items-start justify-between gap-4 p-3.5 rounded-2xl hover:bg-[rgba(255,255,255,0.03)] transition-colors"
          >
            {/* Timeline Node Dot */}
            <div className="absolute -left-6 top-4 w-5 h-5 rounded-full bg-[#050509] border-2 border-[#8B5CF6] flex items-center justify-center shadow-[0_0_10px_rgba(139,92,246,0.6)]">
              <div className="w-1.5 h-1.5 rounded-full bg-white" />
            </div>

            <div className="flex items-center gap-3.5">
              <div className="p-2 rounded-xl bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.08)]">
                {getActionIcon(log.action)}
              </div>
              <div>
                <div className="text-xs font-bold text-white font-sans flex items-center gap-2">
                  <span>{log.action}</span>
                  <span className="text-[10px] font-mono text-[#22D3EE] bg-[#22D3EE]/10 px-2 py-0.5 rounded border border-[#22D3EE]/20">
                    {log.target}
                  </span>
                </div>
                <div className="text-[10px] text-[#A1A1AA] font-mono mt-1 flex items-center gap-2">
                  <span className="flex items-center gap-1"><User className="w-3 h-3 text-[#A855F7]" /> {log.user}</span>
                  <span>•</span>
                  <span>IP: {log.ipAddress}</span>
                </div>
              </div>
            </div>

            <div className="text-[10px] font-mono text-[#A1A1AA] shrink-0 text-right">
              {log.timestamp}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
