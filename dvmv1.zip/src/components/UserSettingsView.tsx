import React, { useState, useRef } from 'react';
import { 
  User, 
  Lock, 
  Bell, 
  Sliders, 
  Camera, 
  Upload, 
  Trash2, 
  Check, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  Globe, 
  Clock, 
  Mail, 
  Key, 
  Monitor, 
  Smartphone, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle,
  RotateCw,
  ZoomIn,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CURRENT_USER } from '../data/mockData';

export const UserSettingsView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications' | 'preferences'>('profile');

  // Profile State
  const [displayName, setDisplayName] = useState(CURRENT_USER.name);
  const [username, setUsername] = useState('alex_cloud');
  const [email, setEmail] = useState(CURRENT_USER.email);
  const [avatarUrl, setAvatarUrl] = useState(CURRENT_USER.avatarUrl);
  const [profileSuccess, setProfileSuccess] = useState(false);

  // Avatar Modal / Cropper Simulation
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [tempImage, setTempImage] = useState<string | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [rotation, setRotation] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Security State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  // Notifications State
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [inAppNotifs, setInAppNotifs] = useState(true);
  const [maintenanceAlerts, setMaintenanceAlerts] = useState(true);
  const [vpsStatusAlerts, setVpsStatusAlerts] = useState(true);
  const [notifSuccess, setNotifSuccess] = useState(false);

  // Preferences State
  const [timezone, setTimezone] = useState('UTC (Coordinated Universal Time)');
  const [language, setLanguage] = useState('English (US)');
  const [dateFormat, setDateFormat] = useState('YYYY-MM-DD');
  const [use24Hour, setUse24Hour] = useState(true);
  const [defaultLanding, setDefaultLanding] = useState('dashboard');
  const [prefSuccess, setPrefSuccess] = useState(false);

  // Active Sessions
  const [sessions, setSessions] = useState([
    { id: 'sess-1', device: 'Chrome on macOS (Apple M3 Max)', ip: '192.168.1.45', location: 'San Francisco, US', current: true, time: 'Active now' },
    { id: 'sess-2', device: 'Safari on iPhone 15 Pro', ip: '172.56.21.9', location: 'San Francisco, US', current: false, time: '2 hours ago' },
  ]);

  // Handle Profile Save
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess(true);
    setTimeout(() => setProfileSuccess(false), 2500);
  };

  // Handle Password Change
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }
    setPasswordSuccess(true);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => setPasswordSuccess(false), 3000);
  };

  // Handle Notifications Save
  const handleSaveNotifications = () => {
    setNotifSuccess(true);
    setTimeout(() => setNotifSuccess(false), 2500);
  };

  // Handle Preferences Save
  const handleSavePreferences = () => {
    setPrefSuccess(true);
    setTimeout(() => setPrefSuccess(false), 2500);
  };

  // File Upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setTempImage(event.target?.result as string);
        setShowAvatarModal(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const calculatePasswordStrength = (pwd: string) => {
    if (!pwd) return { score: 0, label: '', color: 'bg-white/10' };
    let score = 0;
    if (pwd.length >= 8) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;

    if (score <= 1) return { score: 25, label: 'Weak', color: 'bg-rose-500' };
    if (score === 2) return { score: 50, label: 'Fair', color: 'bg-amber-500' };
    if (score === 3) return { score: 75, label: 'Strong', color: 'bg-blue-500' };
    return { score: 100, label: 'Secure', color: 'bg-emerald-500' };
  };

  const pwdStrength = calculatePasswordStrength(newPassword);

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#8B5CF6]/20 via-[#3B82F6]/15 to-transparent rounded-full blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#D8B4FE] text-[10px] font-mono font-bold tracking-widest uppercase">
              <User className="w-3 h-3 text-[#22D3EE]" /> User Account Management & Security
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Account Settings
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Manage your personal profile, security credentials, active sessions, and global user preferences.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#8B5CF6]/40 bg-[#111827]">
                <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">{displayName}</div>
                <div className="text-[10px] font-mono text-[#22D3EE]">Client Member</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 bg-[#080A12] p-1.5 rounded-2xl border border-white/10 w-fit">
        {[
          { id: 'profile', label: 'Profile', icon: User },
          { id: 'security', label: 'Security & Password', icon: Lock },
          { id: 'notifications', label: 'Notifications', icon: Bell },
          { id: 'preferences', label: 'Preferences', icon: Sliders },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isActive 
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white shadow-lg shadow-[#8B5CF6]/25' 
                  : 'text-[#A1A1AA] hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: PROFILE */}
      {activeTab === 'profile' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-8"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-white/10">
            <div className="flex items-center gap-5">
              <div className="relative group">
                <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-[#8B5CF6]/50 bg-[#111827] shadow-xl">
                  <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white"
                >
                  <Camera className="w-6 h-6 text-[#22D3EE]" />
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/png, image/jpeg, image/jpg, image/webp"
                  className="hidden"
                />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white font-sans">Profile Picture & Avatar</h3>
                <p className="text-xs text-[#A1A1AA]">Supports PNG, JPG, JPEG, WEBP up to 5MB. Drag & drop or upload.</p>
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold border border-white/10 transition-all cursor-pointer"
                  >
                    Upload New Image
                  </button>
                  <button
                    onClick={() => setAvatarUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150')}
                    className="px-3.5 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/20 transition-all cursor-pointer"
                  >
                    Remove Avatar
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 font-mono text-[11px] space-y-1">
              <div className="text-[#A1A1AA]">User ID: <span className="text-white">usr_98127391823</span></div>
              <div className="text-[#A1A1AA]">Role: <span className="text-[#22D3EE] font-bold">Client User</span></div>
              <div className="text-[#A1A1AA]">Member Since: <span className="text-white">June 12, 2025</span></div>
            </div>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="space-y-2 sm:col-span-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              {profileSuccess && (
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Profile updated successfully!</span>
                </div>
              )}
              <div className="ml-auto">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 cursor-pointer hover:opacity-90"
                >
                  Save Profile Changes
                </button>
              </div>
            </div>
          </form>
        </motion.div>
      )}

      {/* TAB 2: SECURITY */}
      {activeTab === 'security' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-6">
            <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
              <Key className="w-5 h-5 text-[#8B5CF6]" /> Change Password
            </h3>

            <form onSubmit={handleChangePassword} className="space-y-6 max-w-xl">
              {passwordError && (
                <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{passwordError}</span>
                </div>
              )}

              {passwordSuccess && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Password changed successfully!</span>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">Current Password</label>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A1A1AA] hover:text-white"
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">New Password</label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password (min 8 chars)"
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A1A1AA] hover:text-white"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {newPassword && (
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-[#A1A1AA]">Strength: <strong className="text-white">{pwdStrength.label}</strong></span>
                      <span className="text-[#22D3EE]">{pwdStrength.score}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden">
                      <div className={`h-full transition-all duration-300 ${pwdStrength.color}`} style={{ width: `${pwdStrength.score}%` }} />
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-[#A1A1AA] uppercase">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 cursor-pointer hover:opacity-90"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>

          <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-[#22D3EE]" /> Active Sessions
                </h3>
                <p className="text-xs text-[#A1A1AA] mt-1">Manage and logout active login sessions across your devices.</p>
              </div>

              <button
                onClick={() => setSessions(sessions.filter(s => s.current))}
                className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 text-xs font-bold transition-all cursor-pointer"
              >
                Logout All Other Sessions
              </button>
            </div>

            <div className="space-y-3">
              {sessions.map((sess) => (
                <div key={sess.id} className="p-4 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-white/5 text-[#22D3EE]">
                      {sess.device.includes('iPhone') ? <Smartphone className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-2">
                        <span>{sess.device}</span>
                        {sess.current && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-mono font-bold uppercase">
                            Current Session
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#A1A1AA] font-mono mt-0.5">IP: {sess.ip} • {sess.location} • {sess.time}</div>
                    </div>
                  </div>

                  {!sess.current && (
                    <button
                      onClick={() => setSessions(sessions.filter(s => s.id !== sess.id))}
                      className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-rose-500/20 text-[#A1A1AA] hover:text-rose-400 text-xs font-bold border border-white/10 transition-all cursor-pointer"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* TAB 3: NOTIFICATIONS */}
      {activeTab === 'notifications' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-6"
        >
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
              <Bell className="w-5 h-5 text-[#8B5CF6]" /> Notification Preferences
            </h3>
            <p className="text-xs text-[#A1A1AA]">Choose how and when you receive system alerts, maintenance notices, and VPS status updates.</p>
          </div>

          <div className="space-y-4 pt-2">
            {[
              { label: 'Email Notifications', desc: 'Receive invoice, billing, and backup reports via email.', val: emailNotifs, setVal: setEmailNotifs },
              { label: 'In-App Notifications', desc: 'Real-time toast notifications for deployment and operation status.', val: inAppNotifs, setVal: setInAppNotifs },
              { label: 'Maintenance Alerts', desc: 'Advance warnings for cluster node maintenance and reboots.', val: maintenanceAlerts, setVal: setMaintenanceAlerts },
              { label: 'VPS Status Notifications', desc: 'Instant alerts when virtual machines reboot, stop, or encounter high CPU.', val: vpsStatusAlerts, setVal: setVpsStatusAlerts },
            ].map((item, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
                <div className="space-y-0.5 max-w-lg">
                  <div className="text-sm font-bold text-white">{item.label}</div>
                  <div className="text-xs text-[#A1A1AA]">{item.desc}</div>
                </div>

                <button
                  onClick={() => item.setVal(!item.val)}
                  className={`w-12 h-6 rounded-full transition-colors relative p-1 cursor-pointer ${
                    item.val ? 'bg-[#8B5CF6]' : 'bg-white/10'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    item.val ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            {notifSuccess && (
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Notification preferences saved!</span>
              </div>
            )}
            <div className="ml-auto">
              <button
                onClick={handleSaveNotifications}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 cursor-pointer hover:opacity-90"
              >
                Save Preferences
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* TAB 4: PREFERENCES */}
      {activeTab === 'preferences' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-6"
        >
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#22D3EE]" /> System & Dashboard Preferences
            </h3>
            <p className="text-xs text-[#A1A1AA]">Customize timezones, date formats, languages, and dashboard default views.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div className="space-y-2">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Timezone</label>
              <select
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option>UTC (Coordinated Universal Time)</option>
                <option>America/New_York (EST/EDT)</option>
                <option>Europe/London (GMT/BST)</option>
                <option>Asia/Singapore (SGT)</option>
                <option>Asia/Tokyo (JST)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option>English (US)</option>
                <option>Spanish (ES)</option>
                <option>German (DE)</option>
                <option>Japanese (JA)</option>
                <option>French (FR)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Date Format</label>
              <select
                value={dateFormat}
                onChange={(e) => setDateFormat(e.target.value)}
                className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option value="YYYY-MM-DD">YYYY-MM-DD (2026-08-01)</option>
                <option value="DD/MM/YYYY">DD/MM/YYYY (01/08/2026)</option>
                <option value="MM/DD/YYYY">MM/DD/YYYY (08/01/2026)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Default Landing Page</label>
              <select
                value={defaultLanding}
                onChange={(e) => setDefaultLanding(e.target.value)}
                className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option value="dashboard">My Cloud Dashboard</option>
                <option value="vms">Virtual Machines List</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            {prefSuccess && (
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Preferences updated successfully!</span>
              </div>
            )}
            <div className="ml-auto">
              <button
                onClick={handleSavePreferences}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 cursor-pointer hover:opacity-90"
              >
                Save Preferences
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Avatar Cropper Modal Simulation */}
      <AnimatePresence>
        {showAvatarModal && tempImage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/40 bg-[#080A12] space-y-6 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-bold text-white font-sans">Crop & Adjust Avatar</h3>
                <button
                  onClick={() => setShowAvatarModal(false)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A1A1AA] hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-[#8B5CF6] shadow-[0_0_30px_rgba(139,92,246,0.4)] bg-black relative flex items-center justify-center">
                  <img 
                    src={tempImage} 
                    alt="Crop Preview" 
                    className="w-full h-full object-cover transition-transform duration-200"
                    style={{ transform: `scale(${zoomLevel}) rotate(${rotation}deg)` }}
                  />
                </div>

                <div className="flex items-center gap-4 w-full px-4">
                  <ZoomIn className="w-4 h-4 text-[#A1A1AA]" />
                  <input
                    type="range"
                    min="1"
                    max="2"
                    step="0.1"
                    value={zoomLevel}
                    onChange={(e) => setZoomLevel(parseFloat(e.target.value))}
                    className="w-full accent-[#8B5CF6]"
                  />
                  <button
                    onClick={() => setRotation((prev) => (prev + 90) % 360)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white cursor-pointer"
                    title="Rotate 90deg"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => setShowAvatarModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setAvatarUrl(tempImage);
                    setShowAvatarModal(false);
                    setProfileSuccess(true);
                    setTimeout(() => setProfileSuccess(false), 2500);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/20 cursor-pointer hover:opacity-90"
                >
                  Apply & Save Avatar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
