import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionTemplate, useMotionValue } from 'motion/react';
import { 
  Lock, 
  ArrowRight, 
  ShieldCheck, 
  Mail, 
  Key, 
  User, 
  EyeOff, 
  Eye, 
  CheckCircle2, 
  ArrowLeft,
  Sparkles,
  Server,
  Zap,
  Globe,
  Database,
  Cpu,
  Terminal,
  Copy,
  Check
} from 'lucide-react';
import { DvmLogo } from './DvmLogo';

interface LoginViewProps {
  onLogin: (role?: 'admin' | 'user') => void;
}

type AuthMode = 'login' | 'register' | 'forgot' | 'reset';

// --------------------------------------------------------------------------------
// LIVING BACKGROUND WITH PARALLAX MESH & FLOATING PARTICLES
// --------------------------------------------------------------------------------
const LivingBackground = () => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden bg-[#050509]">
      {/* Noise Texture */}
      <div className="absolute inset-0 bg-noise opacity-[0.035] mix-blend-overlay z-20 pointer-events-none" />
      
      {/* Mouse Reactive Ambient Glow */}
      <motion.div
        className="absolute inset-0 z-10 pointer-events-none opacity-60 transition-opacity duration-500"
        style={{
          background: useMotionTemplate`
            radial-gradient(
              650px circle at ${mouseX}px ${mouseY}px,
              rgba(139, 92, 246, 0.16),
              transparent 80%
            )
          `,
        }}
      />

      {/* Aurora Mesh */}
      <div className="absolute inset-0 z-0 blur-[130px] opacity-70">
        <motion.div
          animate={{
            scale: [1, 1.25, 1],
            rotate: [0, 90, 0],
            x: ['-10%', '10%', '-10%'],
            y: ['10%', '-10%', '10%']
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
          className="absolute top-[-10%] left-[-10%] w-[65vw] h-[65vw] rounded-full bg-[#8B5CF6]/30 mix-blend-screen"
        />
        <motion.div
          animate={{
            scale: [1, 1.4, 1],
            rotate: [0, -90, 0],
            x: ['10%', '-10%', '10%'],
            y: ['-10%', '10%', '-10%']
          }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
          className="absolute bottom-[-10%] right-[-10%] w-[70vw] h-[70vw] rounded-full bg-[#22D3EE]/25 mix-blend-screen"
        />
        <motion.div
          animate={{
            scale: [1, 1.15, 1],
            x: ['0%', '20%', '0%'],
            y: ['20%', '0%', '20%']
          }}
          transition={{ duration: 22, repeat: Infinity, ease: 'linear' }}
          className="absolute top-[20%] left-[25%] w-[50vw] h-[50vw] rounded-full bg-[#3B82F6]/25 mix-blend-screen"
        />
      </div>

      {/* Floating Network Particles */}
      {[...Array(24)].map((_, i) => (
        <motion.div
          key={i}
          initial={{
            x: Math.random() * 100 + 'vw',
            y: Math.random() * 100 + 'vh',
            scale: Math.random() * 0.5 + 0.5,
            opacity: Math.random() * 0.4 + 0.1,
          }}
          animate={{
            y: [null, Math.random() * -100 - 50 + 'vh'],
            opacity: [null, Math.random() * 0.8 + 0.2, 0],
          }}
          transition={{
            duration: Math.random() * 20 + 12,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute w-1.5 h-1.5 rounded-full bg-[#C084FC] shadow-[0_0_10px_#C084FC]"
        />
      ))}
    </div>
  );
};

// --------------------------------------------------------------------------------
// PREMIUM FLOATING INPUT COMPONENT
// --------------------------------------------------------------------------------
const FloatingInput = ({ 
  label, 
  icon: Icon, 
  type = 'text', 
  value, 
  onChange, 
  id,
  showPasswordToggle,
  onTogglePassword,
  isPasswordVisible,
  required = true,
  placeholder = ''
}: any) => {
  const [isFocused, setIsFocused] = useState(false);
  const isFilled = value && value.length > 0;

  return (
    <div className="relative group/input mb-5">
      {/* Subtle Focus Aura */}
      <div className={`absolute -inset-0.5 bg-gradient-to-r from-[#8B5CF6] via-[#3B82F6] to-[#22D3EE] rounded-2xl blur-md transition-opacity duration-500 ${isFocused ? 'opacity-40' : 'opacity-0'}`} />
      
      <div className={`relative flex items-center bg-[rgba(10,10,15,0.7)] backdrop-blur-2xl border ${isFocused ? 'border-[#8B5CF6] shadow-[0_0_25px_rgba(139,92,246,0.2)]' : 'border-[rgba(255,255,255,0.08)] group-hover/input:border-[rgba(255,255,255,0.18)]'} rounded-2xl transition-all duration-300`}>
        
        <div className="pl-5 pr-3 text-[#A1A1AA] transition-colors duration-300">
          <Icon className={`w-5 h-5 ${isFocused ? 'text-[#C084FC]' : ''}`} />
        </div>

        <div className="relative w-full h-14">
          <input
            id={id}
            type={type}
            value={value}
            onChange={onChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            required={required}
            placeholder={placeholder}
            className="w-full h-full bg-transparent outline-none text-white text-sm font-semibold pt-3 pb-1 peer"
          />
          <label
            htmlFor={id}
            className={`absolute left-0 cursor-text transition-all duration-300 font-bold ${
              isFocused || isFilled 
                ? 'top-2 text-[10px] text-[#C084FC] uppercase tracking-widest' 
                : 'top-1/2 -translate-y-1/2 text-xs text-[#A1A1AA]'
            }`}
          >
            {label}
          </label>
        </div>

        {showPasswordToggle && (
          <button
            type="button"
            onClick={onTogglePassword}
            className="pr-5 pl-3 text-[#A1A1AA] hover:text-white transition-colors"
          >
            {isPasswordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
};

// --------------------------------------------------------------------------------
// MAGNETIC BUTTON COMPONENT
// --------------------------------------------------------------------------------
const MagneticButton = ({ children, onClick, isLoading, type = 'button', disabled = false }: any) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!buttonRef.current || disabled) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = buttonRef.current.getBoundingClientRect();
    const x = (clientX - (left + width / 2)) * 0.15;
    const y = (clientY - (top + height / 2)) * 0.15;
    setPosition({ x, y });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.button
      ref={buttonRef}
      type={type}
      onClick={onClick}
      disabled={disabled || isLoading}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: 'spring', stiffness: 150, damping: 15, mass: 0.1 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`relative w-full h-14 rounded-2xl overflow-hidden group shadow-[0_10px_30px_rgba(139,92,246,0.3)] ${disabled ? 'opacity-80 cursor-not-allowed' : ''}`}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] opacity-90 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20 transform -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] skew-x-12" />
      
      <div className="relative h-full flex items-center justify-center gap-3 text-white font-bold text-xs uppercase tracking-widest z-10">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-4 w-full px-6"
            >
              <div className="flex-1 h-1 bg-white/20 rounded-full overflow-hidden relative">
                 <motion.div 
                   className="absolute top-0 left-0 bottom-0 w-1/3 bg-white rounded-full"
                   animate={{ x: ['-100%', '300%'] }}
                   transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                 />
              </div>
              <span className="shrink-0 animate-pulse">Authenticating Session</span>
            </motion.div>
          ) : (
            <motion.div
              key="content"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              {children}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.button>
  );
};

// --------------------------------------------------------------------------------
// MAIN COMPONENT
// --------------------------------------------------------------------------------
export const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetCode, setResetCode] = useState('');
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [copiedDefault, setCopiedDefault] = useState(false);

  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: 'No Passcode', color: 'bg-[rgba(255,255,255,0.1)]' };
    let score = 0;
    if (pass.length >= 8) score += 1;
    if (/[A-Z]/.test(pass)) score += 1;
    if (/[0-9]/.test(pass)) score += 1;
    if (/[^A-Za-z0-9]/.test(pass)) score += 1;

    if (score <= 1) return { score: 25, label: 'Weak', color: 'bg-[#EF4444]' };
    if (score === 2) return { score: 50, label: 'Fair', color: 'bg-[#F59E0B]' };
    if (score === 3) return { score: 75, label: 'Strong', color: 'bg-[#22C55E]' };
    return { score: 100, label: 'Enterprise Grade', color: 'bg-[#8B5CF6]' };
  };

  const strength = getPasswordStrength(password);

  // Auto fill default admin credentials helper
  const fillDefaultAdminCredentials = () => {
    setEmail('admin@gmail.com');
    setPassword('admin');
    setCopiedDefault(true);
    setTimeout(() => setCopiedDefault(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      if (mode === 'login' || mode === 'register') {
        setIsSuccess(true);
        setTimeout(() => onLogin(), 1000);
      } else if (mode === 'forgot') {
        setMode('reset');
      } else if (mode === 'reset') {
        setMode('login');
      }
    }, 1800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center font-sans selection:bg-[#8B5CF6]/30 selection:text-[#C084FC] relative overflow-hidden">
      <LivingBackground />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between p-6 sm:p-10 lg:p-12 gap-12 lg:gap-16">
        
        {/* Left Side: Enterprise Branding & Statistics */}
        <div className="flex-1 flex flex-col items-center lg:items-start text-center lg:text-left max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-8"
          >
            {/* Live Operational Status Pulse */}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 bg-[rgba(168,85,247,0.1)] border border-[rgba(168,85,247,0.25)] rounded-full text-xs font-bold text-[#D8B4FE] backdrop-blur-md shadow-[0_0_20px_rgba(168,85,247,0.2)]">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-ping" />
              <span>All 12 Datacenter Regions Operational</span>
            </div>

            {/* Main Brand Title & Logo */}
            <div className="space-y-4">
              <div className="flex items-center justify-center lg:justify-start gap-4">
                <DvmLogo variant="icon" size={72} withGlow={true} animated={true} />
                <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black tracking-tighter text-white">
                  DVM <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C084FC] via-[#3B82F6] to-[#22D3EE]">Panel v1</span>
                </h1>
              </div>

              <p className="text-lg text-[#A1A1AA] font-medium leading-relaxed max-w-xl">
                Next-Generation Enterprise Virtualization Engine. Orchestrate high-density KVM cloud infrastructure with precision, isolation, and zero-latency control.
              </p>
            </div>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-4 rounded-2xl bg-[rgba(10,10,15,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-md space-y-1.5 text-left">
                <div className="flex items-center gap-2 text-[#22D3EE]">
                  <Zap className="w-4 h-4" />
                  <span className="text-xs font-bold font-sans text-white">Real-Time Sync</span>
                </div>
                <p className="text-[11px] text-[#A1A1AA] font-medium leading-tight">Instant Proxmox & QEMU hypervisor telemetry.</p>
              </div>

              <div className="p-4 rounded-2xl bg-[rgba(10,10,15,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-md space-y-1.5 text-left">
                <div className="flex items-center gap-2 text-[#8B5CF6]">
                  <Terminal className="w-4 h-4" />
                  <span className="text-xs font-bold font-sans text-white">Zero-Trust Terminal</span>
                </div>
                <p className="text-[11px] text-[#A1A1AA] font-medium leading-tight">Isolated web SSH & SSHX peer tunnels.</p>
              </div>

              <div className="p-4 rounded-2xl bg-[rgba(10,10,15,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-md space-y-1.5 text-left">
                <div className="flex items-center gap-2 text-[#3B82F6]">
                  <Globe className="w-4 h-4" />
                  <span className="text-xs font-bold font-sans text-white">High Availability</span>
                </div>
                <p className="text-[11px] text-[#A1A1AA] font-medium leading-tight">Clustered failover and NVMe snapshots.</p>
              </div>
            </div>

            {/* Live Metrics Counter Bar */}
            <div className="pt-4 border-t border-[rgba(255,255,255,0.06)] grid grid-cols-3 gap-6 text-center lg:text-left">
              <div>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">99.99%</div>
                <div className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-wider">Uptime SLA</div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-black text-[#22D3EE] font-mono">&lt; 1ms</div>
                <div className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-wider">Hypervisor Ping</div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-black text-[#8B5CF6] font-mono">256-Bit</div>
                <div className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-wider">AES Encryption</div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right Side: Floating Glassmorphism Auth Card */}
        <div className="w-full max-w-[480px] relative perspective-1000 shrink-0">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, rotateX: 4 }}
            animate={{ opacity: 1, scale: 1, rotateX: 0 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            {/* Ambient Card Outer Glow */}
            <div className="absolute -inset-1 bg-gradient-to-b from-[#8B5CF6]/30 via-[#3B82F6]/20 to-[#22D3EE]/30 rounded-[2.5rem] blur-xl" />
            
            <div className="relative bg-[rgba(10,13,22,0.85)] backdrop-blur-3xl rounded-[2.5rem] border border-[rgba(255,255,255,0.12)] p-8 sm:p-10 shadow-[0_30px_70px_rgba(0,0,0,0.85)] overflow-hidden">
              <div className="absolute inset-0 bg-noise opacity-[0.03] mix-blend-overlay pointer-events-none" />

              {/* Success Overlay */}
              <AnimatePresence>
                {isSuccess && (
                  <motion.div 
                    initial={{ opacity: 0, backdropFilter: 'blur(0px)' }}
                    animate={{ opacity: 1, backdropFilter: 'blur(20px)' }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-50 bg-[rgba(10,13,22,0.9)] flex flex-col items-center justify-center p-6 text-center"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', damping: 15 }}
                      className="w-20 h-20 bg-gradient-to-br from-[#22C55E] to-[#10B981] rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(34,197,94,0.4)] mb-6"
                    >
                      <CheckCircle2 className="w-10 h-10 text-white stroke-[3]" />
                    </motion.div>
                    <h3 className="text-2xl font-black text-white tracking-tight">Access Granted</h3>
                    <p className="text-[#A1A1AA] text-sm mt-2 font-medium">Initializing secure hypervisor session...</p>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Mode Toggle (Login/Register) */}
              {(mode === 'login' || mode === 'register') && (
                <div className="flex bg-[rgba(255,255,255,0.03)] p-1.5 rounded-2xl mb-6 relative z-10 border border-[rgba(255,255,255,0.05)] shadow-inner">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className={`flex-1 py-3 text-[11px] font-bold uppercase tracking-widest rounded-xl transition-all duration-300 ${
                      mode === 'login' 
                        ? 'bg-[rgba(255,255,255,0.12)] text-white shadow-md border border-[rgba(255,255,255,0.1)]' 
                        : 'text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('register')}
                    className={`flex-1 py-3 text-[11px] font-bold uppercase tracking-widest rounded-xl transition-all duration-300 ${
                      mode === 'register' 
                        ? 'bg-[rgba(255,255,255,0.12)] text-white shadow-md border border-[rgba(255,255,255,0.1)]' 
                        : 'text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    Register
                  </button>
                </div>
              )}

              {/* Title Section */}
              <div className="mb-6 relative z-10">
                <h2 className="text-3xl font-black text-white tracking-tight mb-2 font-sans">
                  {mode === 'login' && 'Welcome Back'}
                  {mode === 'register' && 'Create Account'}
                  {mode === 'forgot' && 'Reset Passcode'}
                  {mode === 'reset' && 'New Passcode'}
                </h2>
                <p className="text-[#A1A1AA] text-xs font-medium leading-relaxed">
                  {mode === 'login' && 'Enter your credentials to manage your virtual cloud instances.'}
                  {mode === 'register' && 'Provision your master super administrator account.'}
                  {mode === 'forgot' && 'We will send a recovery token to your registered email.'}
                  {mode === 'reset' && 'Enter the token and your new secure passcode.'}
                </p>
              </div>



              {/* Form */}
              <form onSubmit={handleSubmit} className="relative z-10">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={mode}
                    initial={{ opacity: 0, filter: 'blur(10px)', y: 10 }}
                    animate={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
                    exit={{ opacity: 0, filter: 'blur(10px)', y: -10 }}
                    transition={{ duration: 0.3 }}
                  >
                    {mode === 'register' && (
                      <FloatingInput
                        id="name"
                        label="Full Name / Handle"
                        icon={User}
                        value={name}
                        onChange={(e: any) => setName(e.target.value)}
                      />
                    )}

                    {(mode === 'login' || mode === 'register' || mode === 'forgot') && (
                      <FloatingInput
                        id="email"
                        label="Administrator Email"
                        icon={Mail}
                        type="email"
                        value={email}
                        onChange={(e: any) => setEmail(e.target.value)}
                      />
                    )}

                    {mode === 'reset' && (
                      <FloatingInput
                        id="resetCode"
                        label="6-Digit Recovery Token"
                        icon={Key}
                        value={resetCode}
                        onChange={(e: any) => setResetCode(e.target.value)}
                      />
                    )}

                    {(mode === 'login' || mode === 'register' || mode === 'reset') && (
                      <div className="relative">
                        <FloatingInput
                          id="password"
                          label={mode === 'reset' ? "New Secure Passcode" : "Passcode"}
                          icon={Lock}
                          type={showPassword ? 'text' : 'password'}
                          value={password}
                          onChange={(e: any) => setPassword(e.target.value)}
                          showPasswordToggle
                          isPasswordVisible={showPassword}
                          onTogglePassword={() => setShowPassword(!showPassword)}
                        />
                        
                        {/* Password Strength Indicator */}
                        {(mode === 'register' || mode === 'reset') && password && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            className="mb-5 -mt-2 space-y-2 px-1"
                          >
                            <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                              <span className="text-[#A1A1AA]">Security Level</span>
                              <span className={strength.color.replace('bg-', 'text-')}>{strength.label}</span>
                            </div>
                            <div className="h-1.5 w-full bg-[rgba(255,255,255,0.05)] rounded-full overflow-hidden">
                              <div 
                                className={`h-full ${strength.color} transition-all duration-500 shadow-[0_0_10px_currentColor]`}
                                style={{ width: `${strength.score}%` }}
                              />
                            </div>
                          </motion.div>
                        )}
                      </div>
                    )}

                    {mode === 'register' && (
                      <FloatingInput
                        id="confirmPassword"
                        label="Confirm Passcode"
                        icon={ShieldCheck}
                        type={showPassword ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e: any) => setConfirmPassword(e.target.value)}
                        showPasswordToggle
                        isPasswordVisible={showPassword}
                        onTogglePassword={() => setShowPassword(!showPassword)}
                      />
                    )}

                  </motion.div>
                </AnimatePresence>

                {/* Footer Links */}
                <div className="flex items-center justify-between mt-1 mb-6 h-6">
                  {mode === 'login' ? (
                    <button
                      type="button"
                      onClick={() => setMode('forgot')}
                      className="text-xs font-semibold text-[#8B5CF6] hover:text-[#C084FC] transition-colors tracking-wide"
                    >
                      Forgot Passcode?
                    </button>
                  ) : (mode === 'forgot' || mode === 'reset') ? (
                    <button
                      type="button"
                      onClick={() => setMode('login')}
                      className="text-xs font-semibold text-[#A1A1AA] hover:text-white transition-colors flex items-center gap-1.5 group/back"
                    >
                      <ArrowLeft className="w-3.5 h-3.5 group-hover/back:-translate-x-1 transition-transform" /> Back to Sign In
                    </button>
                  ) : <div />}
                </div>

                <MagneticButton type="submit" isLoading={isLoading}>
                  {mode === 'login' && <>Authenticate Session <ArrowRight className="w-4 h-4 ml-1" /></>}
                  {mode === 'register' && <>Provision Master Account <ArrowRight className="w-4 h-4 ml-1" /></>}
                  {mode === 'forgot' && <>Send Recovery Link <Mail className="w-4 h-4 ml-1" /></>}
                  {mode === 'reset' && <>Update Passcode <CheckCircle2 className="w-4 h-4 ml-1" /></>}
                </MagneticButton>

              </form>

              {/* Demo Mode Quick Role Switcher */}
              {mode === 'login' && (
                <div className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.06)] text-center relative z-10">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-[#A1A1AA] mb-3">
                    Instant Demo Environment Role
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => onLogin('admin')}
                      className="py-2.5 px-4 bg-[rgba(139,92,246,0.12)] hover:bg-[rgba(139,92,246,0.25)] text-[#D8B4FE] border border-[rgba(139,92,246,0.25)] hover:border-[rgba(139,92,246,0.5)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 group/demo"
                    >
                      <ShieldCheck className="w-4 h-4 group-hover/demo:scale-110 transition-transform" /> Super Admin
                    </button>
                    <button
                      type="button"
                      onClick={() => onLogin('user')}
                      className="py-2.5 px-4 bg-[rgba(59,130,246,0.12)] hover:bg-[rgba(59,130,246,0.25)] text-[#93C5FD] border border-[rgba(59,130,246,0.25)] hover:border-[rgba(59,130,246,0.5)] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 group/demo"
                    >
                      <User className="w-4 h-4 group-hover/demo:scale-110 transition-transform" /> Customer
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
