import React from 'react';
import { motion } from 'motion/react';
import { Server, Cpu, HardDrive, Activity, Zap, RefreshCw } from 'lucide-react';

interface DashboardSkeletonProps {
  type?: 'full' | 'metrics' | 'vms' | 'table';
  count?: number;
}

export const ShimmerBox: React.FC<{
  className?: string;
  style?: React.CSSProperties;
}> = ({ className = '', style }) => (
  <div
    style={style}
    className={`relative overflow-hidden bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.05)] rounded-xl ${className}`}
  >
    <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-[rgba(139,92,246,0.18)] to-transparent" />
  </div>
);

export const DashboardHeroSkeleton: React.FC = () => {
  return (
    <div className="relative overflow-hidden rounded-[2.5rem] glass-card p-8 lg:p-12 border border-[rgba(255,255,255,0.08)] space-y-8">
      {/* Background ambient glow simulation */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#8B5CF6]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-[#22D3EE]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="space-y-3 max-w-xl w-full">
          <ShimmerBox className="w-48 h-7 rounded-full" />
          <ShimmerBox className="w-full sm:w-96 h-10 rounded-2xl" />
          <ShimmerBox className="w-3/4 h-4 rounded-lg" />
        </div>

        <ShimmerBox className="w-40 h-12 rounded-2xl shrink-0" />
      </div>

      {/* Hero 6-box counter grid skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-6 border-t border-[rgba(255,255,255,0.06)] relative z-10">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] space-y-2">
            <ShimmerBox className="w-20 h-3 rounded-md" />
            <ShimmerBox className="w-14 h-7 rounded-lg" />
            <ShimmerBox className="w-24 h-2.5 rounded-md" />
          </div>
        ))}
      </div>
    </div>
  );
};

export const DashboardMetricsSkeleton: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {[
        { label: 'Total vCPUs Allocated', icon: Cpu, color: 'purple' },
        { label: 'Total Memory Provisioned', icon: Activity, color: 'blue' },
        { label: 'ZFS NVMe Disk Pool', icon: HardDrive, color: 'cyan' },
        { label: 'Active Cluster Health', icon: Zap, color: 'emerald' },
      ].map((item, idx) => (
        <div
          key={idx}
          className="relative overflow-hidden glass-card rounded-[2rem] p-6 space-y-4 border border-[rgba(255,255,255,0.06)] shadow-xl"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-[rgba(139,92,246,0.1)] border border-[rgba(139,92,246,0.2)]">
                <item.icon className="w-5 h-5 text-[#8B5CF6] animate-pulse" />
              </div>
              <ShimmerBox className="w-28 h-4 rounded-lg" />
            </div>
            <ShimmerBox className="w-12 h-5 rounded-full" />
          </div>

          <div className="space-y-2">
            <ShimmerBox className="w-24 h-9 rounded-xl" />
            <ShimmerBox className="w-36 h-3 rounded-md" />
          </div>

          <div className="pt-2">
            <ShimmerBox className="w-full h-2 rounded-full" />
          </div>
        </div>
      ))}
    </div>
  );
};

export const VmCardSkeleton: React.FC<{ count?: number }> = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[...Array(count)].map((_, i) => (
        <div
          key={i}
          className="glass-card rounded-[2rem] p-6 space-y-6 relative overflow-hidden border border-[rgba(255,255,255,0.06)] shadow-xl"
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <ShimmerBox className="w-20 h-6 rounded-full" />
            <ShimmerBox className="w-24 h-6 rounded-full" />
          </div>

          {/* Name & IP */}
          <div className="space-y-2">
            <ShimmerBox className="w-3/4 h-6 rounded-xl" />
            <div className="flex items-center justify-between">
              <ShimmerBox className="w-28 h-4 rounded-md" />
              <ShimmerBox className="w-16 h-4 rounded-md" />
            </div>
          </div>

          {/* Meter Bars */}
          <div className="space-y-3 bg-[rgba(0,0,0,0.4)] p-4 rounded-2xl border border-[rgba(255,255,255,0.03)]">
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <ShimmerBox className="w-20 h-3 rounded" />
                <ShimmerBox className="w-10 h-3 rounded" />
              </div>
              <ShimmerBox className="w-full h-2 rounded-full" />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between">
                <ShimmerBox className="w-20 h-3 rounded" />
                <ShimmerBox className="w-10 h-3 rounded" />
              </div>
              <ShimmerBox className="w-full h-2 rounded-full" />
            </div>
          </div>

          {/* Action Footer Buttons */}
          <div className="flex items-center gap-2 pt-2 border-t border-[rgba(255,255,255,0.05)]">
            <ShimmerBox className="flex-1 h-9 rounded-xl" />
            <ShimmerBox className="w-9 h-9 rounded-xl shrink-0" />
            <ShimmerBox className="w-9 h-9 rounded-xl shrink-0" />
          </div>
        </div>
      ))}
    </div>
  );
};

export const VmTableSkeleton: React.FC<{ rows?: number }> = ({ rows = 5 }) => {
  return (
    <div className="glass-card rounded-[2rem] p-6 overflow-hidden border border-[rgba(255,255,255,0.06)] shadow-xl">
      <div className="flex items-center justify-between pb-6 border-b border-[rgba(255,255,255,0.06)]">
        <ShimmerBox className="w-48 h-8 rounded-xl" />
        <div className="flex items-center gap-3">
          <ShimmerBox className="w-24 h-8 rounded-xl" />
          <ShimmerBox className="w-24 h-8 rounded-xl" />
        </div>
      </div>

      <div className="divide-y divide-[rgba(255,255,255,0.04)]">
        {[...Array(rows)].map((_, i) => (
          <div key={i} className="py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1">
              <ShimmerBox className="w-4 h-4 rounded shrink-0" />
              <ShimmerBox className="w-10 h-10 rounded-xl shrink-0" />
              <div className="space-y-1 flex-1">
                <ShimmerBox className="w-40 h-4 rounded-lg" />
                <ShimmerBox className="w-24 h-3 rounded-md" />
              </div>
            </div>

            <ShimmerBox className="w-28 h-6 rounded-full hidden sm:block" />
            <ShimmerBox className="w-32 h-3 rounded-full hidden md:block" />
            <ShimmerBox className="w-32 h-3 rounded-full hidden lg:block" />

            <div className="flex items-center gap-2">
              <ShimmerBox className="w-8 h-8 rounded-lg" />
              <ShimmerBox className="w-8 h-8 rounded-lg" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const NodeListSkeleton: React.FC<{ count?: number }> = ({ count = 3 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="glass-card rounded-[2rem] p-6 space-y-6 relative overflow-hidden border border-[rgba(255,255,255,0.06)] shadow-xl">
          <div className="flex items-center justify-between">
            <ShimmerBox className="w-32 h-6 rounded-xl" />
            <ShimmerBox className="w-20 h-6 rounded-full" />
          </div>
          <div className="space-y-2">
            <ShimmerBox className="w-48 h-5 rounded-lg" />
            <ShimmerBox className="w-32 h-3.5 rounded-md" />
          </div>
          <div className="space-y-3 bg-[rgba(0,0,0,0.4)] p-4 rounded-2xl border border-[rgba(255,255,255,0.03)]">
            <div className="space-y-1.5">
              <div className="flex justify-between"><ShimmerBox className="w-16 h-3 rounded" /><ShimmerBox className="w-12 h-3 rounded" /></div>
              <ShimmerBox className="w-full h-2 rounded-full" />
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between"><ShimmerBox className="w-16 h-3 rounded" /><ShimmerBox className="w-12 h-3 rounded" /></div>
              <ShimmerBox className="w-full h-2 rounded-full" />
            </div>
          </div>
          <div className="flex justify-between pt-2 border-t border-[rgba(255,255,255,0.05)]">
            <ShimmerBox className="w-28 h-8 rounded-xl" />
            <ShimmerBox className="w-20 h-8 rounded-xl" />
          </div>
        </div>
      ))}
    </div>
  );
};

export const AnalyticsSkeleton: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glass-card p-6 rounded-[2rem] space-y-3 border border-[rgba(255,255,255,0.06)]">
            <ShimmerBox className="w-28 h-4 rounded-md" />
            <ShimmerBox className="w-20 h-8 rounded-xl" />
            <ShimmerBox className="w-full h-1.5 rounded-full" />
          </div>
        ))}
      </div>
      <div className="glass-card p-6 rounded-[2rem] space-y-4 border border-[rgba(255,255,255,0.06)]">
        <ShimmerBox className="w-48 h-6 rounded-xl" />
        <ShimmerBox className="w-full h-64 rounded-2xl" />
      </div>
    </div>
  );
};

export const LogsListSkeleton: React.FC<{ rows?: number }> = ({ rows = 6 }) => {
  return (
    <div className="glass-card rounded-[2rem] p-6 space-y-4 border border-[rgba(255,255,255,0.06)]">
      <div className="flex justify-between items-center pb-4 border-b border-[rgba(255,255,255,0.06)]">
        <ShimmerBox className="w-40 h-6 rounded-xl" />
        <ShimmerBox className="w-24 h-8 rounded-xl" />
      </div>
      <div className="space-y-3">
        {[...Array(rows)].map((_, i) => (
          <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.04)]">
            <div className="flex items-center gap-3">
              <ShimmerBox className="w-8 h-8 rounded-lg shrink-0" />
              <div className="space-y-1">
                <ShimmerBox className="w-48 h-4 rounded-md" />
                <ShimmerBox className="w-24 h-3 rounded-sm" />
              </div>
            </div>
            <ShimmerBox className="w-16 h-5 rounded-full" />
          </div>
        ))}
      </div>
    </div>
  );
};

export const DashboardFullSkeleton: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-8 pb-12"
    >
      {/* Brand Header Shimmer */}
      <DashboardHeroSkeleton />

      {/* Metrics Row Shimmer */}
      <DashboardMetricsSkeleton />

      {/* VM List Cards Shimmer */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <ShimmerBox className="w-56 h-7 rounded-xl" />
          <ShimmerBox className="w-32 h-5 rounded-lg" />
        </div>
        <VmCardSkeleton count={6} />
      </div>
    </motion.div>
  );
};
