import React, { useState, useEffect } from 'react';
import { 
  X, 
  Terminal, 
  Play, 
  Square, 
  RotateCw, 
  Camera, 
  HardDrive, 
  Network, 
  Shield, 
  Cpu, 
  Activity, 
  Clock, 
  Copy, 
  Check, 
  Save, 
  Trash2,
  AlertCircle,
  FileText,
  Sparkles,
  CalendarDays
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VMInstance, VMSnapshot } from '../types';
import { PremiumProgressBar } from './PremiumProgressBar';

interface VMDetailModalProps {
  vm: VMInstance | null;
  onClose: () => void;
  onOpenConsole: (vm: VMInstance) => void;
  onVMAction: (vmId: string, action: 'start' | 'stop' | 'reboot' | 'pause' | 'delete') => void;
  snapshots: VMSnapshot[];
  onCreateSnapshot: (vmId: string, name: string) => void;
}

export const VMDetailModal: React.FC<VMDetailModalProps> = ({
  vm,
  onClose,
  onOpenConsole,
  onVMAction,
  snapshots,
  onCreateSnapshot,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'snapshots' | 'network' | 'disks' | 'settings'>('overview');
  const [snapshotName, setSnapshotName] = useState('');
  const [copiedIp, setCopiedIp] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (vm) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [vm, onClose]);

  if (!vm) return null;

  const vmSnapshots = snapshots.filter((s) => s.vmId === vm.id);

  const handleCopyIp = () => {
    navigator.clipboard.writeText(vm.ipAddress);
    setCopiedIp(true);
    setTimeout(() => setCopiedIp(false), 2000);
  };

  const handleTakeSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!snapshotName.trim()) return;
    onCreateSnapshot(vm.id, snapshotName);
    setSnapshotName('');
  };

  // Expiry calculation
  let remainingDays = 0;
  let statusColor = 'text-gray-400';
  let statusBg = 'bg-gray-400/10 border-gray-400/20';
  let statusText = 'Unknown';
  let isExpired = false;
  
  if (vm.expiryDate) {
    const expiry = new Date(vm.expiryDate).getTime();
    const now = Date.now();
    const diff = expiry - now;
    remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (remainingDays > 15) {
      statusColor = 'text-[#10B981]';
      statusBg = 'bg-[#10B981]/10 border-[#10B981]/20';
      statusText = 'Active';
    } else if (remainingDays > 7) {
      statusColor = 'text-[#FBBF24]';
      statusBg = 'bg-[#FBBF24]/10 border-[#FBBF24]/20';
      statusText = 'Expiring Soon';
    } else if (remainingDays > 3) {
      statusColor = 'text-[#F59E0B]';
      statusBg = 'bg-[#F59E0B]/10 border-[#F59E0B]/20';
      statusText = 'Warning';
    } else if (remainingDays > 0) {
      statusColor = 'text-[#EF4444]';
      statusBg = 'bg-[#EF4444]/10 border-[#EF4444]/20';
      statusText = 'Critical';
    } else {
      statusColor = 'text-gray-400';
      statusBg = 'bg-gray-400/10 border-gray-400/20';
      statusText = 'Expired';
      remainingDays = 0;
      isExpired = true;
    }
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl overflow-y-auto">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className="glass-card rounded-[2.5rem] w-full max-w-5xl max-h-[90vh] flex flex-col shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] my-auto overflow-hidden relative"
        >
          {/* Subtle gradient glow behind modal header */}
          <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-[#8B5CF6]/10 via-[#3B82F6]/10 to-transparent pointer-events-none" />

          {/* Modal Header */}
          <div className="p-8 pb-6 border-b border-[rgba(255,255,255,0.05)] flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#A855F7]/20 to-[#3B82F6]/20 border border-[#A855F7]/30 flex items-center justify-center font-mono text-xl font-bold text-[#C084FC] shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                {vm.vmid}
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-2xl font-black text-white tracking-wide font-sans">{vm.name}</h2>
                  <span className={`text-[10px] font-sans tracking-widest uppercase font-bold px-3 py-1.5 rounded-full shadow-sm border ${
                    vm.status === 'running' 
                      ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20' 
                      : 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20'
                  }`}>
                    {vm.status.toUpperCase()}
                  </span>
                </div>
                <p className="text-sm text-[#A1A1AA] mt-1.5 font-sans tracking-wide">
                  {vm.osName} &bull; Hypervisor Node: {vm.node}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {vm.status === 'running' && (
                <motion.button
                  whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(139,92,246,0.4)' }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onOpenConsole(vm)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white text-[11px] font-bold uppercase tracking-widest rounded-xl transition-all shadow-[0_5px_15px_-5px_rgba(168,85,247,0.5)] border border-[rgba(255,255,255,0.1)]"
                >
                  <Terminal className="w-4 h-4" />
                  <span>Launch Console</span>
                </motion.button>
              )}
              <button
                onClick={onClose}
                className="p-3 text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)] rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Quick Hardware Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 px-8 py-5 bg-[rgba(0,0,0,0.3)] border-b border-[rgba(255,255,255,0.05)] text-sm font-sans tracking-wide relative z-10 shadow-inner">
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">IPv4 Address</span>
              <div className="flex items-center gap-2 font-mono font-bold text-[#C084FC]">
                <span>{vm.ipAddress}</span>
                <button onClick={handleCopyIp} className="text-[#A1A1AA] hover:text-[#C084FC] transition-colors">
                  {copiedIp ? <Check className="w-4 h-4 text-[#10B981] stroke-[3]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">vCPU Allocation</span>
              <div className="font-sans font-bold text-[#C084FC]">{vm.vcpu} Cores</div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">Memory Capacity</span>
              <div className="font-sans font-bold text-[#C084FC]">{vm.ramGB} GB RAM</div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">Storage Volume</span>
              <div className="font-sans font-bold text-[#10B981]">{vm.diskGB} GB NVMe</div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 px-8 py-2 border-b border-[rgba(255,255,255,0.05)] bg-[#050509] overflow-x-auto custom-scrollbar relative z-10">
            {[
              { id: 'overview', label: 'Overview', icon: Activity },
              { id: 'snapshots', label: `Snapshots (${vmSnapshots.length})`, icon: Camera },
              { id: 'network', label: 'Networking', icon: Network },
              { id: 'disks', label: 'Storage', icon: HardDrive },
              { id: 'settings', label: 'Settings', icon: Shield },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 py-3 px-5 text-[11px] font-bold uppercase tracking-widest font-sans rounded-xl transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-[#A855F7]/10 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                      : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Content Body */}
          <div className="p-8 flex-1 overflow-y-auto space-y-8 custom-scrollbar relative z-10">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Expiry Card */}
                {vm.expiryDate && (
                  <div className="p-6 bg-[rgba(0,0,0,0.4)] rounded-[1.5rem] border border-[rgba(255,255,255,0.05)] shadow-inner relative overflow-hidden group">
                    <div className="absolute -inset-10 bg-gradient-to-r from-transparent via-[rgba(255,255,255,0.02)] to-transparent skew-x-12 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
                      
                      <div className="flex items-center gap-6">
                        {/* Countdown Ring */}
                        <div className="relative w-20 h-20 shrink-0">
                          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="6" />
                            <motion.circle 
                              cx="50" cy="50" r="45" fill="none" 
                              stroke="currentColor" strokeWidth="6" 
                              strokeLinecap="round" 
                              className={statusColor}
                              strokeDasharray={2 * Math.PI * 45}
                              initial={{ strokeDashoffset: 2 * Math.PI * 45 }}
                              animate={{ strokeDashoffset: 2 * Math.PI * 45 * (1 - Math.min(remainingDays / 30, 1)) }}
                              transition={{ duration: 1.5, ease: "easeOut" }}
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className={`text-xl font-black tracking-tight ${statusColor}`}>{remainingDays}</span>
                            <span className="text-[8px] font-bold uppercase tracking-widest text-[#A1A1AA] mt-0.5">Days</span>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <h3 className="text-white font-bold tracking-wide font-sans text-lg">Subscription Expiry</h3>
                            <span className={`text-[9px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border ${statusBg} ${statusColor}`}>
                              {statusText}
                            </span>
                          </div>
                          <div className="text-sm font-sans tracking-wide text-[#A1A1AA] flex items-center gap-4">
                            <div className="flex items-center gap-1.5"><CalendarDays className="w-4 h-4 text-[#C084FC]" /> Expires: {new Date(vm.expiryDate).toLocaleDateString()}</div>
                            <div className="hidden sm:block w-1 h-1 rounded-full bg-[rgba(255,255,255,0.1)]" />
                            <div className="hidden sm:flex items-center gap-1.5"><RotateCw className="w-4 h-4 text-[#3B82F6]" /> Auto-renew: Off</div>
                          </div>
                        </div>
                      </div>

                      <button className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-[#A855F7] to-[#3B82F6] hover:from-[#C084FC] hover:to-[#60A5FA] text-white font-bold text-[11px] uppercase tracking-widest rounded-xl transition-all shadow-[0_0_15px_rgba(168,85,247,0.4)] whitespace-nowrap">
                        Renew Now
                      </button>

                    </div>
                  </div>
                )}

                {/* Real-time Meters */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-6 bg-[rgba(0,0,0,0.4)] rounded-[1.5rem] border border-[rgba(255,255,255,0.05)] shadow-inner relative overflow-hidden group">
                    <PremiumProgressBar value={vm.cpuUsagePct} label="vCPU Utilization" className="relative z-10" />
                  </div>

                  <div className="p-6 bg-[rgba(0,0,0,0.4)] rounded-[1.5rem] border border-[rgba(255,255,255,0.05)] shadow-inner relative overflow-hidden group">
                     <PremiumProgressBar value={vm.ramUsagePct} label="RAM Utilization" className="relative z-10" />
                  </div>

                  <div className="p-6 bg-[rgba(0,0,0,0.4)] rounded-[1.5rem] border border-[rgba(255,255,255,0.05)] shadow-inner relative overflow-hidden group">
                    <PremiumProgressBar value={vm.diskUsagePct} label="Storage Capacity" className="relative z-10" />
                  </div>
                </div>

                {/* System Specs Table */}
                <div className="glass-panel rounded-[1.5rem] p-6 space-y-4 shadow-inner">
                  <h3 className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-[#3B82F6]" /> Instance Profile
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-sans tracking-wide">
                    <div className="flex justify-between py-3 border-b border-[rgba(255,255,255,0.05)]">
                      <span className="text-[#A1A1AA]">Hypervisor Kernel</span>
                      <span className="font-mono text-[#E4E4E7] text-xs">Linux 6.8.0-kvm</span>
                    </div>
                    <div className="flex justify-between py-3 border-b border-[rgba(255,255,255,0.05)]">
                      <span className="text-[#A1A1AA]">Virtual Machine ID</span>
                      <span className="font-mono text-[#C084FC] font-bold text-xs">{vm.vmid}</span>
                    </div>
                    <div className="flex justify-between py-3 border-b border-[rgba(255,255,255,0.05)]">
                      <span className="text-[#A1A1AA]">Automated Snapshots</span>
                      <span className="font-sans text-[#10B981] font-bold">{vm.autoBackup ? 'Enabled' : 'Disabled'}</span>
                    </div>
                    <div className="flex justify-between py-3 border-b border-[rgba(255,255,255,0.05)]">
                      <span className="text-[#A1A1AA]">Provisioned At</span>
                      <span className="font-mono text-[#E4E4E7] text-xs">{vm.createdTime}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'snapshots' && (
              <div className="space-y-6">
                {/* Create Snapshot Form */}
                <form onSubmit={handleTakeSnapshot} className="glass-panel rounded-[1.5rem] p-5 flex gap-4 shadow-inner relative z-10">
                  <input
                    type="text"
                    value={snapshotName}
                    onChange={(e) => setSnapshotName(e.target.value)}
                    placeholder="Snapshot label (e.g. 'pre-upgrade-v2.0')"
                    className="flex-1 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.1)] rounded-xl px-5 py-3 text-sm text-white placeholder-[#A1A1AA] font-sans tracking-wide outline-none focus:border-[#A855F7]/50 transition-all shadow-inner"
                  />
                  <button
                    type="submit"
                    className="px-6 py-3 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs uppercase tracking-widest rounded-xl shadow-[0_5px_15px_-5px_rgba(139,92,246,0.5)] whitespace-nowrap transition-all"
                  >
                    Take Snapshot
                  </button>
                </form>

                {/* Snapshots Table */}
                <div className="glass-panel rounded-[1.5rem] overflow-hidden shadow-inner relative z-10">
                  <table className="w-full text-left text-sm font-sans tracking-wide">
                    <thead className="bg-[rgba(0,0,0,0.5)] text-[#A1A1AA] uppercase font-bold text-[10px] tracking-widest border-b border-[rgba(255,255,255,0.05)]">
                      <tr>
                        <th className="p-4">Snapshot Name</th>
                        <th className="p-4">Size</th>
                        <th className="p-4">Type</th>
                        <th className="p-4">Created At</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[rgba(255,255,255,0.05)] text-[#E4E4E7]">
                      {vmSnapshots.map((snp) => (
                        <tr key={snp.id} className="hover:bg-[rgba(255,255,255,0.03)] transition-colors">
                          <td className="p-4 font-bold text-[#C084FC]">{snp.name}</td>
                          <td className="p-4 text-[#A1A1AA]">{(snp.sizeMB / 1024).toFixed(2)} GB</td>
                          <td className="p-4"><span className="uppercase text-[10px] font-bold text-[#A855F7] bg-[#A855F7]/10 px-2 py-1 rounded">{snp.type}</span></td>
                          <td className="p-4 text-[#A1A1AA] text-xs font-mono">{snp.createdAt}</td>
                          <td className="p-4 text-right">
                            <button className="px-4 py-2 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-white rounded-lg text-xs font-bold uppercase tracking-widest transition-colors border border-[rgba(255,255,255,0.1)]">
                              Rollback
                            </button>
                          </td>
                        </tr>
                      ))}
                      {vmSnapshots.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-10 text-center text-[#A1A1AA] italic font-sans text-sm">
                            No snapshots stored for this VM instance yet.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'network' && (
              <div className="space-y-4 text-sm font-sans tracking-wide">
                <div className="p-6 glass-panel rounded-[1.5rem] space-y-4 shadow-inner relative z-10">
                  <div className="font-bold text-white uppercase tracking-widest text-xs flex items-center gap-2"><Network className="w-4 h-4 text-[#A855F7]" /> Network Interface vmbr0</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[#A1A1AA] text-xs font-mono">
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">Bridge: vmbr0 (Public SDN)</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">MAC Address: 52:54:00:81:a2:9c</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)] text-[#C084FC]">IPv4 CIDR: {vm.ipAddress}/24</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">Bandwidth Limit: 10 Gbps Unlimited</div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'disks' && (
              <div className="space-y-4 text-sm font-sans tracking-wide">
                <div className="p-6 glass-panel rounded-[1.5rem] space-y-4 shadow-inner relative z-10">
                  <div className="font-bold text-white uppercase tracking-widest text-xs flex items-center gap-2"><HardDrive className="w-4 h-4 text-[#10B981]" /> Block Storage Device</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[#A1A1AA] text-xs font-mono">
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">Bus: VirtIO SCSI</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">Storage Pool: local-zfs (ZFS)</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)] text-[#10B981]">Allocated Size: {vm.diskGB} GB</div>
                    <div className="bg-[rgba(0,0,0,0.5)] p-3 rounded-xl border border-[rgba(255,255,255,0.05)]">Format: Raw block device</div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6 relative z-10">
                <div className="p-6 glass-panel rounded-[1.5rem] space-y-6 shadow-inner">
                  <h4 className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans">Power & State Controls</h4>
                  <div className="flex flex-wrap gap-4">
                    <button
                      onClick={() => onVMAction(vm.id, 'start')}
                      disabled={vm.status === 'running'}
                      className="flex items-center gap-2 px-5 py-2.5 bg-[#10B981]/10 hover:bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/20 hover:border-[#10B981]/50 font-bold text-xs uppercase tracking-widest rounded-xl disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                    >
                      <Play className="w-4 h-4" /> Start Instance
                    </button>
                    <button
                      onClick={() => onVMAction(vm.id, 'reboot')}
                      className="flex items-center gap-2 px-5 py-2.5 bg-[#F59E0B]/10 hover:bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/20 hover:border-[#F59E0B]/50 font-bold text-xs uppercase tracking-widest rounded-xl transition-all"
                    >
                      <RotateCw className="w-4 h-4" /> Soft Reboot
                    </button>
                    <button
                      onClick={() => onVMAction(vm.id, 'stop')}
                      className="flex items-center gap-2 px-5 py-2.5 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#E4E4E7] border border-[rgba(255,255,255,0.1)] hover:border-[rgba(255,255,255,0.2)] font-bold text-xs uppercase tracking-widest rounded-xl transition-all"
                    >
                      <Square className="w-4 h-4" /> ACPI Shutdown
                    </button>
                  </div>
                </div>

                <div className="p-6 bg-rose-500/5 border border-rose-500/20 rounded-[1.5rem] space-y-4 shadow-inner">
                  <h4 className="text-[11px] font-bold text-rose-400 uppercase tracking-widest font-sans flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" /> Danger Zone
                  </h4>
                  <p className="text-sm text-[#A1A1AA] font-sans tracking-wide leading-relaxed">
                    Permanently destroy this virtual machine instance. This action cannot be undone. Associated ZFS volumes, backups, and network allocations will be completely purged from the hypervisor node.
                  </p>
                  <button
                    onClick={() => {
                      onVMAction(vm.id, 'delete');
                      onClose();
                    }}
                    className="flex items-center justify-center sm:justify-start gap-2 px-6 py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-widest rounded-xl shadow-[0_5px_15px_-5px_rgba(225,29,72,0.5)] transition-all"
                  >
                    <Trash2 className="w-4 h-4" /> Destroy Virtual Machine
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
