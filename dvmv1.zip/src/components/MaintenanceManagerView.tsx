import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Wrench, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Lock, 
  Unlock, 
  Save, 
  RefreshCw 
} from 'lucide-react';
import { motion } from 'motion/react';

export const MaintenanceManagerView: React.FC = () => {
  const [maintenanceActive, setMaintenanceActive] = useState(false);
  const [startTime, setStartTime] = useState('2026-08-03T01:00');
  const [endTime, setEndTime] = useState('2026-08-03T03:00');
  const [message, setMessage] = useState('DVM Panel is currently undergoing scheduled enterprise cluster maintenance. Administrator access remains active.');
  const [allowAdminBypass, setAllowAdminBypass] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#F59E0B]/15 via-[#8B5CF6]/15 to-transparent rounded-full blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F59E0B]/20 border border-[#F59E0B]/40 text-[#FCD34D] text-[10px] font-mono font-bold tracking-widest uppercase">
              <Wrench className="w-3 h-3 text-[#F59E0B]" /> Cluster Maintenance Mode & Lockout
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Maintenance Manager
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Enable maintenance mode across the cluster to display custom system banners or lockout non-admin user sessions during upgrades.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setMaintenanceActive(!maintenanceActive)}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer shadow-lg ${
                maintenanceActive 
                  ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-white shadow-amber-500/30' 
                  : 'bg-white/10 hover:bg-white/15 text-white border border-white/10'
              }`}
            >
              {maintenanceActive ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              <span>{maintenanceActive ? 'Maintenance Active (Disable)' : 'Enable Maintenance Mode'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-white/10 space-y-6">
        <form onSubmit={handleSave} className="space-y-6 max-w-3xl">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/5">
            <div className="space-y-1">
              <div className="text-sm font-bold text-white font-sans">Maintenance Lockout State</div>
              <div className="text-xs text-[#A1A1AA]">When active, non-admin users attempting to access the panel will see the maintenance screen.</div>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-mono font-bold uppercase ${
              maintenanceActive ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
            }`}>
              {maintenanceActive ? 'Locked Out' : 'Normal Operation'}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Scheduled Start Time</label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-[#A1A1AA] uppercase">Scheduled End Time</label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono text-[#A1A1AA] uppercase">Custom Maintenance Banner Message</label>
            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6] resize-none"
            />
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-black/40 border border-white/5">
            <input
              type="checkbox"
              id="bypass"
              checked={allowAdminBypass}
              onChange={(e) => setAllowAdminBypass(e.target.checked)}
              className="w-4 h-4 accent-[#8B5CF6] rounded"
            />
            <label htmlFor="bypass" className="text-xs text-white cursor-pointer font-medium">
              Allow Administrators to bypass maintenance screen using signed session tokens
            </label>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            {savedSuccess && (
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Maintenance settings updated successfully!</span>
              </div>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 cursor-pointer hover:opacity-90"
              >
                <Save className="w-4 h-4" />
                <span>Save Maintenance Config</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
