import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { useTheme } from '../context/ThemeContext';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  pulseSpeed: number;
}

interface CircuitLine {
  path: { x: number; y: number }[];
  currentProgress: number;
  speed: number;
  color: string;
  width: number;
}

export const FuturisticBackground: React.FC = () => {
  const { theme } = useTheme();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: -1000, y: -1000, targetX: -1000, targetY: -1000 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = e.clientX;
      mouseRef.current.targetY = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initNetwork();
    };

    window.addEventListener('resize', handleResize);

    // Color helpers based on hex/theme
    const hexToRgb = (hex: string) => {
      const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
      const fullHex = hex.replace(shorthandRegex, (_, r, g, b) => r + r + g + g + b + b);
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(fullHex);
      return result
        ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16),
          }
        : { r: 139, g: 92, b: 246 };
    };

    const primaryRgb = hexToRgb(theme.primaryColor);
    const secondaryRgb = hexToRgb(theme.secondaryColor);
    const accentRgb = hexToRgb(theme.accentColor);

    const colorPalette = [
      `rgba(${primaryRgb.r}, ${primaryRgb.g}, ${primaryRgb.b}, `,
      `rgba(${secondaryRgb.r}, ${secondaryRgb.g}, ${secondaryRgb.b}, `,
      `rgba(${accentRgb.r}, ${accentRgb.g}, ${accentRgb.b}, `,
    ];

    // Initialize nodes and circuits
    let nodes: { x: number; y: number; vx: number; vy: number; radius: number; baseAlpha: number; pulse: number }[] = [];
    let circuits: CircuitLine[] = [];

    const nodeCountMap = { low: 25, medium: 45, high: 75 };
    const nodeCount = nodeCountMap[theme.particleDensity] || 45;

    const initNetwork = () => {
      nodes = [];
      for (let i = 0; i < nodeCount; i++) {
        nodes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.4 * theme.bgAnimationSpeed,
          vy: (Math.random() - 0.5) * 0.4 * theme.bgAnimationSpeed,
          radius: Math.random() * 2 + 1,
          baseAlpha: Math.random() * 0.5 + 0.2,
          pulse: Math.random() * Math.PI * 2,
        });
      }

      // Generate grid-based circuit paths
      circuits = [];
      const circuitCount = Math.floor(nodeCount / 3);
      for (let i = 0; i < circuitCount; i++) {
        const path: { x: number; y: number }[] = [];
        let currX = Math.random() * width;
        let currY = Math.random() * height;
        path.push({ x: currX, y: currY });

        const steps = Math.floor(Math.random() * 3) + 3;
        for (let s = 0; s < steps; s++) {
          const isHorizontal = Math.random() > 0.5;
          const delta = (Math.random() - 0.5) * 200 + 50;
          if (isHorizontal) {
            currX += delta;
          } else {
            currY += delta;
          }
          path.push({ x: currX, y: currY });
        }

        circuits.push({
          path,
          currentProgress: Math.random(),
          speed: (Math.random() * 0.003 + 0.001) * theme.bgAnimationSpeed,
          color: colorPalette[i % colorPalette.length],
          width: Math.random() * 1.5 + 0.5,
        });
      }
    };

    initNetwork();

    let lastTime = performance.now();

    const render = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      // Smooth mouse damping
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.05;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.05;

      ctx.clearRect(0, 0, width, height);

      if (!theme.enableBgAnimations) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      const globalAlphaFactor = (theme.glowIntensity / 100) * (theme.bgBrightness / 100);

      // Draw Circuit Lines & Flowing Packets if enabled
      if (theme.enableFloatingLines) {
        circuits.forEach(circuit => {
          circuit.currentProgress += circuit.speed;
          if (circuit.currentProgress > 1) circuit.currentProgress = 0;

          // Draw faint path
          ctx.beginPath();
          ctx.moveTo(circuit.path[0].x, circuit.path[0].y);
          for (let p = 1; p < circuit.path.length; p++) {
            ctx.lineTo(circuit.path[p].x, circuit.path[p].y);
          }
          ctx.strokeStyle = `${circuit.color}${0.08 * globalAlphaFactor})`;
          ctx.lineWidth = circuit.width;
          ctx.stroke();

          // Calculate packet position along polyline path
          let totalLen = 0;
          const segLens: number[] = [];
          for (let p = 0; p < circuit.path.length - 1; p++) {
            const dx = circuit.path[p + 1].x - circuit.path[p].x;
            const dy = circuit.path[p + 1].y - circuit.path[p].y;
            const len = Math.hypot(dx, dy);
            segLens.push(len);
            totalLen += len;
          }

          if (totalLen > 0) {
            let targetDist = circuit.currentProgress * totalLen;
            let currentDist = 0;
            let packetX = circuit.path[0].x;
            let packetY = circuit.path[0].y;

            for (let p = 0; p < segLens.length; p++) {
              if (currentDist + segLens[p] >= targetDist) {
                const ratio = (targetDist - currentDist) / segLens[p];
                packetX = circuit.path[p].x + (circuit.path[p + 1].x - circuit.path[p].x) * ratio;
                packetY = circuit.path[p].y + (circuit.path[p + 1].y - circuit.path[p].y) * ratio;
                break;
              }
              currentDist += segLens[p];
            }

            // Draw glowing data packet
            const glowGradient = ctx.createRadialGradient(packetX, packetY, 0, packetX, packetY, 8);
            glowGradient.addColorStop(0, `${circuit.color}${0.8 * globalAlphaFactor})`);
            glowGradient.addColorStop(1, `${circuit.color}0)`);

            ctx.beginPath();
            ctx.arc(packetX, packetY, 8, 0, Math.PI * 2);
            ctx.fillStyle = glowGradient;
            ctx.fill();

            ctx.beginPath();
            ctx.arc(packetX, packetY, 2, 0, Math.PI * 2);
            ctx.fillStyle = '#FFFFFF';
            ctx.fill();
          }
        });
      }

      // Render Nodes & Mesh Connections
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];

        // Move node
        node.x += node.vx;
        node.y += node.vy;

        // Bounce boundaries
        if (node.x < 0 || node.x > width) node.vx *= -1;
        if (node.y < 0 || node.y > height) node.vy *= -1;

        // Pulse
        node.pulse += dt * 2 * theme.bgAnimationSpeed;
        const currentAlpha = Math.min(
          1,
          (node.baseAlpha + Math.sin(node.pulse) * 0.2) * globalAlphaFactor
        );

        // Distance to mouse (interactive light)
        const dxMouse = mouseRef.current.x - node.x;
        const dyMouse = mouseRef.current.y - node.y;
        const mouseDist = Math.hypot(dxMouse, dyMouse);
        const mouseGlow = mouseDist < 200 ? (1 - mouseDist / 200) * 0.4 : 0;

        // Draw node
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius + (mouseGlow > 0 ? 1 : 0), 0, Math.PI * 2);
        ctx.fillStyle = `${colorPalette[i % colorPalette.length]}${Math.min(1, currentAlpha + mouseGlow)})`;
        ctx.fill();

        // Connect nearby nodes
        for (let j = i + 1; j < nodes.length; j++) {
          const other = nodes[j];
          const dx = other.x - node.x;
          const dy = other.y - node.y;
          const dist = Math.hypot(dx, dy);

          if (dist < 150) {
            const lineAlpha = (1 - dist / 150) * 0.15 * globalAlphaFactor;
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(other.x, other.y);
            ctx.strokeStyle = `${colorPalette[i % colorPalette.length]}${lineAlpha})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [
    theme.primaryColor,
    theme.secondaryColor,
    theme.accentColor,
    theme.glowIntensity,
    theme.bgAnimationSpeed,
    theme.particleDensity,
    theme.enableBgAnimations,
    theme.enableFloatingLines,
    theme.bgBrightness,
  ]);

  const auroraOpacity = (theme.auroraIntensity / 100) * (theme.bgBrightness / 100) * 0.4;

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none bg-[#030305]">
      {/* Custom Background Image if active */}
      {theme.bgStyle === 'customImage' && theme.customBgImage && (
        <div 
          className="absolute inset-0 transition-all duration-500"
          style={{
            backgroundImage: `url(${theme.customBgImage})`,
            backgroundSize: theme.bgImageDisplay === 'stretch' ? '100% 100%' : theme.bgImageDisplay,
            backgroundPosition: theme.bgImagePosition || 'center',
            backgroundAttachment: theme.bgImageAttachment || 'fixed',
            backgroundRepeat: 'no-repeat',
            filter: `blur(${theme.bgImageBlur || 0}px) brightness(${theme.bgImageBrightness ?? 80}%)`,
            opacity: (theme.bgImageOpacity ?? 100) / 100,
          }}
        />
      )}

      {/* 1. Animated Mesh Aurora Blobs */}
      <div
        className="absolute inset-0 transition-opacity duration-1000"
        style={{ opacity: theme.enableBgAnimations ? 1 : 0.2 }}
      >
        <motion.div
          animate={{
            scale: [1, 1.25, 1],
            x: ['-5%', '5%', '-5%'],
            y: ['-5%', '10%', '-5%'],
            rotate: [0, 45, 0],
          }}
          transition={{
            duration: 22 / theme.bgAnimationSpeed,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute -top-[20%] -left-[10%] w-[60vw] h-[60vw] rounded-full blur-[140px]"
          style={{
            background: `radial-gradient(circle, ${theme.primaryColor} 0%, transparent 65%)`,
            opacity: auroraOpacity,
          }}
        />

        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            x: ['5%', '-5%', '5%'],
            y: ['10%', '-5%', '10%'],
            rotate: [0, -30, 0],
          }}
          transition={{
            duration: 28 / theme.bgAnimationSpeed,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute -bottom-[20%] -right-[10%] w-[65vw] h-[65vw] rounded-full blur-[160px]"
          style={{
            background: `radial-gradient(circle, ${theme.secondaryColor} 0%, transparent 65%)`,
            opacity: auroraOpacity * 0.95,
          }}
        />

        <motion.div
          animate={{
            scale: [0.9, 1.15, 0.9],
            x: ['-10%', '10%', '-10%'],
            y: ['5%', '-10%', '5%'],
          }}
          transition={{
            duration: 25 / theme.bgAnimationSpeed,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute top-[35%] left-[30%] w-[50vw] h-[50vw] rounded-full blur-[150px]"
          style={{
            background: `radial-gradient(circle, ${theme.accentColor} 0%, transparent 65%)`,
            opacity: auroraOpacity * 0.6,
          }}
        />
      </div>

      {/* 2. Interactive HTML5 Canvas Layer (Cyber Network & Circuit Particles) */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* 3. Grid Pattern Overlay with Radial Mask */}
      <div
        className="absolute inset-0 bg-grid-pattern opacity-30 transition-opacity duration-700"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px)
          `,
        }}
      />

      {/* 4. Subtle Film Noise Grain */}
      <div className="absolute inset-0 bg-noise opacity-30 pointer-events-none" />

      {/* 5. Ambient Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_40%,_#030305_100%)] opacity-80" />
    </div>
  );
};
