import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Plus, 
  Bell, 
  Terminal, 
  Cpu, 
  ShieldCheck, 
  Activity, 
  ChevronDown, 
  X,
  Sparkles,
  Command
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CURRENT_USER } from '../data/mockData';
import { DvmLogo } from './DvmLogo';

interface HeaderProps {
  onOpenCreateVM: () => void;
  onOpenInstaller: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenCommandPalette?: () => void;
  userRole?: 'admin' | 'user';
  onToggleUserRole?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreateVM,
  onOpenInstaller,
  searchQuery,
  setSearchQuery,
  onOpenCommandPalette,
  userRole = 'admin',
  onToggleUserRole,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (onOpenCommandPalette) {
          onOpenCommandPalette();
        } else {
          searchInputRef.current?.focus();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onOpenCommandPalette]);

  const notifications = [
    { id: 1, title: 'ZFS Pool Backup Finished', time: '2 mins ago', type: 'success', category: 'Storage' },
    { id: 2, title: 'Node hypervisor-03 rebooted', time: '14 mins ago', type: 'info', category: 'Cluster' },
    { id: 3, title: 'High RAM usage alert on vm-prod-db-01', time: '1 hour ago', type: 'warning', category: 'Alerts' },
  ];

  return (
    <header className="sticky top-0 z-30 w-full glass-nav px-6 lg:px-10 py-5 flex items-center justify-between gap-6 transition-all">
      {/* Middle Command Search Bar */}
      <div className="flex-1 max-w-xl relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-[#8B5CF6]/20 to-[#3B82F6]/20 rounded-2xl blur-sm opacity-0 group-hover:opacity-100 transition duration-500" />
        <div 
          onClick={() => onOpenCommandPalette && onOpenCommandPalette()}
          className="relative w-full cursor-pointer"
        >
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA]" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => onOpenCommandPalette && onOpenCommandPalette()}
            placeholder="Search virtual machines, nodes, IPs, tags... (⌘K)"
            className="w-full bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.08)] rounded-2xl pl-11 pr-14 py-2.5 text-sm text-white placeholder-[#A1A1AA] focus:border-[#8B5CF6]/50 focus:bg-[rgba(255,255,255,0.05)] transition-all font-sans shadow-inner outline-none backdrop-blur-md cursor-pointer"
          />
          {searchQuery ? (
            <button
              onClick={(e) => { e.stopPropagation(); setSearchQuery(''); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-[#A1A1AA] hover:text-white rounded-md transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="absolute right-3 top-1/2 -translate-y-1/2 px-1.5 py-0.5 text-[10px] font-mono text-[#A1A1AA] bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] rounded-md shadow-sm pointer-events-none">
              ⌘K
            </kbd>
          )}
        </div>
      </div>

      {/* Right Controls & Profile */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* 1-Line Installer Button (Admin only) */}
        {userRole === 'admin' && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onOpenInstaller}
            className="hidden sm:flex items-center gap-2.5 px-4 py-2.5 bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.05)] text-[#3B82F6] border border-[#3B82F6]/20 hover:border-[#3B82F6]/40 rounded-2xl text-xs font-semibold transition-all shadow-[0_4px_20px_-5px_rgba(59,130,246,0.15)] group backdrop-blur-md"
            title="Open 1-Line Automated Bash Agent Installer"
          >
            <Terminal className="w-4 h-4 text-[#3B82F6] shrink-0 transition-colors" />
            <span className="hidden lg:inline font-sans tracking-wide">Install Agent</span>
          </motion.button>
        )}

        {/* Primary Deploy VM Button */}
        <motion.button
          whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139, 92, 246, 0.4)' }}
          whileTap={{ scale: 0.98 }}
          onClick={onOpenCreateVM}
          className="flex items-center gap-2.5 px-5 py-2.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] text-white rounded-2xl text-sm font-bold transition-all shadow-[0_4px_20px_-5px_rgba(139,92,246,0.4)] border border-[rgba(255,255,255,0.1)]"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span className="tracking-wide">Deploy VM</span>
        </motion.button>

        {/* Notification Bell Dropdown Toggle */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfileMenu(false);
            }}
            className="relative p-3 bg-[rgba(255,255,255,0.03)] backdrop-blur-md border border-[rgba(255,255,255,0.05)] rounded-2xl text-[#A1A1AA] hover:text-white hover:border-[#8B5CF6]/30 transition-all cursor-pointer shadow-sm hover:shadow-[0_0_15px_rgba(139,92,246,0.15)]"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-[#A855F7] animate-ping" />
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-[#A855F7] shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
          </motion.button>

          {/* Notifications Panel */}
          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 15, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-4 w-80 glass-panel rounded-[1.5rem] p-5 z-50 space-y-4 shadow-[0_20px_50px_rgba(0,0,0,0.8)]"
              >
                <div className="flex items-center justify-between border-b border-[rgba(255,255,255,0.05)] pb-3">
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest font-sans">
                    System Audit Center
                  </h4>
                  <span className="text-[10px] font-sans tracking-wide text-[#22D3EE] bg-[#22D3EE]/10 px-2.5 py-1 rounded-full border border-[#22D3EE]/20">
                    3 Unread
                  </span>
                </div>

                <div className="space-y-2">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-3 rounded-2xl bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.06)] border border-[rgba(255,255,255,0.05)] transition-colors text-xs cursor-pointer flex items-start justify-between"
                    >
                      <div>
                        <div className="font-semibold text-white">{n.title}</div>
                        <div className="text-[10px] text-[#A1A1AA] mt-1.5 font-mono">{n.time}</div>
                      </div>
                      <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-[#8B5CF6]/10 text-[#C084FC] rounded border border-[#8B5CF6]/20">
                        {n.category}
                      </span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* User Profile Menu Pill */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              setShowProfileMenu(!showProfileMenu);
              setShowNotifications(false);
            }}
            className="flex items-center gap-3 p-1.5 pl-3 bg-[rgba(255,255,255,0.03)] rounded-2xl border border-[rgba(255,255,255,0.05)] hover:border-[#22D3EE]/30 transition-all cursor-pointer shadow-sm hover:shadow-[0_0_15px_rgba(34,211,238,0.1)]"
          >
            <div className="hidden sm:block text-right">
              <div className="text-sm font-bold text-white leading-tight tracking-wide">{CURRENT_USER.name}</div>
              <div className="text-[10px] text-[#22D3EE] font-sans tracking-widest uppercase leading-tight mt-0.5">
                {userRole === 'admin' ? 'Root Administrator' : 'Client User'}
              </div>
            </div>

            <div className="relative">
              <img
                src={CURRENT_USER.avatarUrl}
                alt={CURRENT_USER.name}
                className="w-10 h-10 rounded-[12px] object-cover border border-[rgba(255,255,255,0.1)] shadow-inner"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#10B981] border-[2px] border-[#050509] shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
            </div>

            <ChevronDown className="w-4 h-4 text-[#A1A1AA] hidden sm:block mr-1" />
          </motion.button>

          {/* Profile Menu Dropdown */}
          <AnimatePresence>
            {showProfileMenu && (
              <motion.div
                initial={{ opacity: 0, y: 15, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-4 w-64 glass-panel rounded-[1.5rem] p-5 z-50 space-y-4"
              >
                <div className="pb-4 border-b border-[rgba(255,255,255,0.05)]">
                  <div className="text-sm font-bold text-white tracking-wide">{CURRENT_USER.name}</div>
                  <div className="text-[11px] text-[#A1A1AA] font-sans tracking-wide truncate mt-1">{CURRENT_USER.email}</div>
                  <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#22D3EE]/10 border border-[#22D3EE]/20 text-[#22D3EE] text-[10px] font-sans tracking-wide uppercase font-bold">
                    <ShieldCheck className="w-3.5 h-3.5" /> {userRole === 'admin' ? 'Root Administrator' : 'Client User'}
                  </div>
                  {onToggleUserRole && (
                    <button
                      onClick={() => {
                        onToggleUserRole();
                        setShowProfileMenu(false);
                      }}
                      className="mt-3 w-full py-2 px-3 rounded-xl bg-[rgba(255,255,255,0.05)] hover:bg-[#8B5CF6]/20 border border-[rgba(255,255,255,0.1)] text-[#C084FC] hover:text-white text-xs font-bold transition-all text-center"
                    >
                      Switch to {userRole === 'admin' ? 'Client User Portal' : 'Administrator Area'}
                    </button>
                  )}
                </div>

                <div className="space-y-1 text-sm font-medium tracking-wide">
                  <button
                    onClick={() => setShowProfileMenu(false)}
                    className="w-full text-left px-3 py-2.5 rounded-xl text-white hover:bg-[rgba(255,255,255,0.05)] transition-colors"
                  >
                    Account Preferences
                  </button>
                  <button
                    onClick={() => setShowProfileMenu(false)}
                    className="w-full text-left px-3 py-2.5 rounded-xl text-white hover:bg-[rgba(255,255,255,0.05)] transition-colors"
                  >
                    API Keys & Tokens
                  </button>
                  <button
                    onClick={() => setShowProfileMenu(false)}
                    className="w-full text-left px-3 py-2.5 rounded-xl text-[#F43F5E] hover:bg-[#F43F5E]/10 hover:text-[#FDA4AF] transition-colors"
                  >
                    Lock Session
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};
