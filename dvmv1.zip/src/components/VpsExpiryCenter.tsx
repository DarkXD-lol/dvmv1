import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldAlert, 
  Clock, 
  Calendar, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  Server, 
  ExternalLink,
  ChevronRight,
  Zap
} from 'lucide-react';
import { VMInstance } from '../types';

interface VpsExpiryCenterProps {
  vms: VMInstance[];
  onSelectVM: (vm: VMInstance) => void;
  onRenewVM?: (vmId: string) => void;
}

export const VpsExpiryCenter: React.FC<VpsExpiryCenterProps> = ({ vms, onSelectVM, onRenewVM }) => {
  const [filter, setFilter] = useState<'all' | 'today' | '3days' | '7days' | '14days' | 'expired'>('all');
  const [renewedIds, setRenewedIds] = useState<string[]>([]);

  // Calculate remaining days for each VM
  const calculateDaysLeft = (vm: VMInstance) => {
    if (!vm.expiryDate) return 30; // Default fallback
    const exp = new Date(vm.expiryDate).getTime();
    const now = new Date().getTime();
    const diffDays = Math.ceil((exp - now) / (1000 * 3600 * 24));
    return diffDays;
  };

  const vmListWithExpiry = vms.map(vm => ({
    ...vm,
    daysLeft: calculateDaysLeft(vm)
  }));

  const filteredVMs = vmListWithExpiry.filter(vm => {
    if (filter === 'today') return vm.daysLeft <= 1 && vm.daysLeft >= 0;
    if (filter === '3days') return vm.daysLeft <= 3 && vm.daysLeft >= 0;
    if (filter === '7days') return vm.daysLeft <= 7 && vm.daysLeft >= 0;
    if (filter === '14days') return vm.daysLeft <= 14 && vm.daysLeft >= 0;
    if (filter === 'expired') return vm.daysLeft < 0;
    return true;
  });

  const handleRenew = (vmId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenewedIds(prev => [...prev, vmId]);
    if (onRenewVM) onRenewVM(vmId);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-[2.5rem] glass-card p-8 lg:p-10 group transition-all">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#F43F5E]/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F43F5E]/10 border border-[#F43F5E]/20 text-[#FDA4AF] text-xs font-bold uppercase tracking-widest mb-3">
              <ShieldAlert className="w-4 h-4" />
              Instance Lifecycle Protection
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight font-sans">
              VPS Expiry & Renewal Center
            </h1>
            <p className="text-xs text-[#A1A1AA] mt-1.5 max-w-xl font-medium">
              Monitor active subscription cycles, track upcoming billing cutoffs, and ensure 100% service continuity with automated renewal extensions.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.8)] border border-[rgba(255,255,255,0.08)] text-center">
              <div className="text-2xl font-black font-mono text-[#F43F5E]">
                {vmListWithExpiry.filter(v => v.daysLeft <= 7).length}
              </div>
              <div className="text-[10px] text-[#A1A1AA] font-bold uppercase tracking-wider">Expiring in 7 Days</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {[
          { id: 'all', label: 'All Instances', count: vmListWithExpiry.length },
          { id: 'today', label: 'Expiring Today', count: vmListWithExpiry.filter(v => v.daysLeft <= 1 && v.daysLeft >= 0).length },
          { id: '3days', label: '3 Days', count: vmListWithExpiry.filter(v => v.daysLeft <= 3 && v.daysLeft >= 0).length },
          { id: '7days', label: '7 Days', count: vmListWithExpiry.filter(v => v.daysLeft <= 7 && v.daysLeft >= 0).length },
          { id: '14days', label: '14 Days', count: vmListWithExpiry.filter(v => v.daysLeft <= 14 && v.daysLeft >= 0).length },
          { id: 'expired', label: 'Expired', count: vmListWithExpiry.filter(v => v.daysLeft < 0).length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
              filter === tab.id
                ? 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white shadow-md'
                : 'bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.06)] text-[#A1A1AA] hover:text-white'
            }`}
          >
            <span>{tab.label}</span>
            <span className="px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-mono">{tab.count}</span>
          </button>
        ))}
      </div>

      {/* Expiry Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVMs.map((vm) => {
          const isRenewed = renewedIds.includes(vm.id);
          const daysLeft = isRenewed ? vm.daysLeft + 30 : vm.daysLeft;
          const isUrgent = daysLeft <= 3;

          return (
            <motion.div
              key={vm.id}
              whileHover={{ y: -4 }}
              onClick={() => onSelectVM(vm)}
              className={`glass-card rounded-[2rem] p-6 cursor-pointer space-y-5 border transition-all duration-300 relative overflow-hidden ${
                isUrgent ? 'hover:border-[#F43F5E]/50 border-[#F43F5E]/30' : 'hover:border-[#8B5CF6]/40'
              }`}
            >
              {/* Top Status */}
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-[#22D3EE] bg-[#22D3EE]/10 px-3 py-1 rounded-full border border-[#22D3EE]/20">
                  ID: #{vm.vmid}
                </span>

                <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold font-mono ${
                  daysLeft < 0 
                    ? 'bg-[#F43F5E]/15 text-[#F43F5E] border border-[#F43F5E]/30'
                    : isUrgent 
                      ? 'bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 animate-pulse'
                      : 'bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30'
                }`}>
                  <Clock className="w-3 h-3" />
                  {daysLeft < 0 ? 'Expired' : `${daysLeft} Days Left`}
                </span>
              </div>

              {/* VM Name & Specs */}
              <div>
                <h3 className="font-black text-lg text-white font-sans">{vm.name}</h3>
                <p className="text-xs font-mono text-[#A1A1AA] mt-1">{vm.ipAddress} • {vm.osName} • {vm.node}</p>
              </div>

              {/* Progress Indicator */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-mono text-[#A1A1AA]">
                  <span>Cycle Progress</span>
                  <span>{Math.max(0, Math.min(100, Math.round((30 - daysLeft) / 30 * 100)))}% used</span>
                </div>
                <div className="h-2 w-full bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden p-0.5">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      isUrgent ? 'bg-gradient-to-r from-[#F59E0B] to-[#F43F5E]' : 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6]'
                    }`}
                    style={{ width: `${Math.max(5, Math.min(100, (30 - daysLeft) / 30 * 100))}%` }}
                  />
                </div>
              </div>

              {/* Renewal Action */}
              <div className="pt-3 border-t border-[rgba(255,255,255,0.06)] flex items-center justify-between">
                <div className="text-[10px] text-[#A1A1AA] font-mono">
                  Expiry Date: <span className="text-white font-bold">{vm.expiryDate || '2026-08-30'}</span>
                </div>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={(e) => handleRenew(vm.id, e)}
                  disabled={isRenewed}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    isRenewed 
                      ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30 cursor-default'
                      : 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#22D3EE] text-white shadow-md'
                  }`}
                >
                  {isRenewed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <RotateCcw className="w-3.5 h-3.5" />}
                  <span>{isRenewed ? 'Renewed (+30d)' : 'Renew Now'}</span>
                </motion.button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
