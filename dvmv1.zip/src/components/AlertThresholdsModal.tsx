import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Bell, 
  BellOff, 
  Cpu, 
  HardDrive, 
  ShieldAlert, 
  Zap, 
  Check, 
  Settings2, 
  RotateCcw,
  Sliders,
  X,
  Server,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VMInstance, AlertThresholdSettings } from '../types';

interface AlertThresholdsProps {
  settings: AlertThresholdSettings;
  onUpdateSettings: (newSettings: AlertThresholdSettings) => void;
  vms: VMInstance[];
  onTriggerTestAlert?: (vmName: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const AlertThresholdsCard: React.FC<{
  settings: AlertThresholdSettings;
  onOpenModal: () => void;
  breachingVMs: VMInstance[];
  onSimulateLoad?: () => void;
}> = ({ settings, onOpenModal, breachingVMs, onSimulateLoad }) => {
  return (
    <div className="glass-card rounded-[2.5rem] p-6 lg:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group">
      {/* Subtle ambient light glow */}
      <div className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-3xl pointer-events-none transition-colors duration-700 ${
        breachingVMs.length > 0 ? 'bg-[#F43F5E]/15' : 'bg-[#A855F7]/10'
      }`} />
      <div className="absolute inset-0 bg-noise opacity-20 pointer-events-none" />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-xl border ${
              breachingVMs.length > 0 
                ? 'bg-[#F43F5E]/20 border-[#F43F5E]/40 text-[#F43F5E] animate-pulse' 
                : 'bg-[#A855F7]/20 border-[#A855F7]/30 text-[#C084FC]'
            }`}>
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-lg text-white font-sans tracking-wide flex items-center gap-2">
                Alert Thresholds
              </h3>
              <p className="text-xs text-[#A1A1AA] font-medium">Real-time resource limit monitoring</p>
            </div>
          </div>

          <span className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full border ${
            settings.enabled 
              ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/30' 
              : 'bg-[rgba(0,0,0,0.5)] text-[#71717A] border-[rgba(255,255,255,0.1)]'
          }`}>
            {settings.enabled ? 'Active' : 'Disabled'}
          </span>
        </div>

        {/* Current Limits Display */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-2xl p-3.5 flex flex-col justify-between shadow-inner">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#A1A1AA]">
              <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5 text-[#C084FC]" /> CPU Limit</span>
            </div>
            <div className="mt-2 text-2xl font-black font-mono text-[#D8B4FE]">
              {settings.cpuLimitPct}%
            </div>
          </div>

          <div className="bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-2xl p-3.5 flex flex-col justify-between shadow-inner">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#A1A1AA]">
              <span className="flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-[#3B82F6]" /> RAM Limit</span>
            </div>
            <div className="mt-2 text-2xl font-black font-mono text-[#60A5FA]">
              {settings.ramLimitPct}%
            </div>
          </div>
        </div>

        {/* Breaching Status Banner */}
        {breachingVMs.length > 0 ? (
          <div className="mt-4 p-3.5 bg-[#F43F5E]/10 border border-[#F43F5E]/30 rounded-2xl flex items-center justify-between gap-3 text-[#FDA4AF] text-xs font-semibold animate-pulse">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-[#F43F5E] shrink-0" />
              <span><strong>{breachingVMs.length} VM(s)</strong> exceeding limit!</span>
            </div>
            <span className="text-[10px] uppercase tracking-widest font-mono bg-[#F43F5E]/20 px-2 py-0.5 rounded border border-[#F43F5E]/30">
              ALERT
            </span>
          </div>
        ) : (
          <div className="mt-4 p-3 bg-[#10B981]/5 border border-[#10B981]/20 rounded-2xl flex items-center gap-2 text-[#34D399] text-xs font-medium">
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>All active VMs operating within thresholds</span>
          </div>
        )}
      </div>

      <div className="mt-6 flex items-center gap-2 relative z-10">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onOpenModal}
          className="flex-1 py-3 px-4 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs font-sans tracking-wide uppercase rounded-xl border border-[rgba(255,255,255,0.1)] shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] transition-all flex items-center justify-center gap-2"
        >
          <Sliders className="w-4 h-4" />
          <span>Configure Thresholds</span>
        </motion.button>

        {onSimulateLoad && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onSimulateLoad}
            title="Simulate load spikes on a VM to test pulse & alert toast"
            className="p-3 bg-[rgba(255,255,255,0.05)] hover:bg-[#F43F5E]/20 text-[#D4D4D8] hover:text-[#F43F5E] rounded-xl border border-[rgba(255,255,255,0.1)] hover:border-[#F43F5E]/30 transition-colors"
          >
            <Zap className="w-4 h-4" />
          </motion.button>
        )}
      </div>
    </div>
  );
};

export const AlertThresholdsModal: React.FC<AlertThresholdsProps> = ({
  settings,
  onUpdateSettings,
  vms,
  onTriggerTestAlert,
  isOpen = false,
  onClose
}) => {
  const [localSettings, setLocalSettings] = useState<AlertThresholdSettings>(settings);

  if (!isOpen || !onClose) return null;

  const handleSave = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const applyPreset = (cpu: number, ram: number) => {
    setLocalSettings((prev) => ({
      ...prev,
      cpuLimitPct: cpu,
      ramLimitPct: ram,
      enabled: true
    }));
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-xl glass-card rounded-[2.5rem] p-6 lg:p-8 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden"
        >
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-[#A855F7]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute inset-0 bg-noise opacity-20 pointer-events-none" />

          {/* Modal Header */}
          <div className="relative z-10 flex items-center justify-between pb-6 border-b border-[rgba(255,255,255,0.05)]">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#A855F7]/20 to-[#3B82F6]/20 border border-[#A855F7]/30 flex items-center justify-center text-[#C084FC] shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black text-white font-sans tracking-tight">
                  Alert Threshold Settings
                </h2>
                <p className="text-xs text-[#A1A1AA] mt-0.5">
                  Set CPU and RAM consumption triggers for automated alert toasts & card pulses
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-[#A1A1AA] hover:text-white bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] rounded-xl transition-colors border border-[rgba(255,255,255,0.05)]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="relative z-10 space-y-6 pt-6 max-h-[70vh] overflow-y-auto custom-scrollbar pr-1">
            {/* Enable/Disable Toggle Switch */}
            <div className="flex items-center justify-between bg-[rgba(0,0,0,0.5)] p-4 rounded-2xl border border-[rgba(255,255,255,0.05)] shadow-inner">
              <div className="flex items-center gap-3">
                {localSettings.enabled ? (
                  <Bell className="w-5 h-5 text-[#10B981]" />
                ) : (
                  <BellOff className="w-5 h-5 text-[#71717A]" />
                )}
                <div>
                  <span className="text-sm font-bold text-white block">Resource Threshold Monitoring</span>
                  <span className="text-xs text-[#A1A1AA]">Trigger notifications & pulse effects when limits are breached</span>
                </div>
              </div>

              <button
                onClick={() => setLocalSettings((prev) => ({ ...prev, enabled: !prev.enabled }))}
                className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${
                  localSettings.enabled ? 'bg-[#8B5CF6]' : 'bg-[rgba(255,255,255,0.1)]'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                    localSettings.enabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Quick Presets */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold uppercase tracking-widest text-[#A1A1AA] block font-sans">
                Quick Threshold Presets
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'Strict (75/75)', cpu: 75, ram: 75 },
                  { label: 'Standard (80/85)', cpu: 80, ram: 85 },
                  { label: 'Relaxed (90/90)', cpu: 90, ram: 90 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => applyPreset(preset.cpu, preset.ram)}
                    className={`p-3 rounded-xl border text-xs font-bold transition-all font-sans ${
                      localSettings.cpuLimitPct === preset.cpu && localSettings.ramLimitPct === preset.ram
                        ? 'bg-[#A855F7]/20 text-[#D8B4FE] border-[#A855F7]/50 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                        : 'bg-[rgba(0,0,0,0.3)] text-[#A1A1AA] border-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.05)] hover:text-white'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* CPU Threshold Slider */}
            <div className="space-y-3 bg-[rgba(0,0,0,0.5)] p-5 rounded-2xl border border-[rgba(255,255,255,0.05)] shadow-inner">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#C084FC]" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    vCPU Usage Limit
                  </span>
                </div>
                <span className="text-lg font-black font-mono text-[#C084FC] bg-[#A855F7]/10 px-3 py-1 rounded-xl border border-[#A855F7]/20">
                  {localSettings.cpuLimitPct}%
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="98"
                value={localSettings.cpuLimitPct}
                onChange={(e) =>
                  setLocalSettings((prev) => ({ ...prev, cpuLimitPct: Number(e.target.value) }))
                }
                className="w-full accent-[#C084FC] h-2 bg-[rgba(255,255,255,0.05)] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#71717A] font-mono">
                <span>50% (Sensitive)</span>
                <span>80% (Default)</span>
                <span>98% (Critical)</span>
              </div>
            </div>

            {/* RAM Threshold Slider */}
            <div className="space-y-3 bg-[rgba(0,0,0,0.5)] p-5 rounded-2xl border border-[rgba(255,255,255,0.05)] shadow-inner">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#3B82F6]" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    RAM Memory Usage Limit
                  </span>
                </div>
                <span className="text-lg font-black font-mono text-[#60A5FA] bg-[#3B82F6]/10 px-3 py-1 rounded-xl border border-[#3B82F6]/20">
                  {localSettings.ramLimitPct}%
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="98"
                value={localSettings.ramLimitPct}
                onChange={(e) =>
                  setLocalSettings((prev) => ({ ...prev, ramLimitPct: Number(e.target.value) }))
                }
                className="w-full accent-[#3B82F6] h-2 bg-[rgba(255,255,255,0.05)] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#71717A] font-mono">
                <span>50% (Sensitive)</span>
                <span>85% (Default)</span>
                <span>98% (Critical)</span>
              </div>
            </div>

            {/* Test Trigger Option */}
            {onTriggerTestAlert && (
              <div className="pt-2 flex items-center justify-between bg-[#A855F7]/10 border border-[#A855F7]/20 rounded-2xl p-4">
                <div>
                  <span className="text-xs font-bold text-white block">Test Alert System</span>
                  <span className="text-[11px] text-[#A1A1AA]">Dispatch a test high-priority notification to toast feed</span>
                </div>
                <button
                  type="button"
                  onClick={() => onTriggerTestAlert(vms[0]?.name || 'web-prod-01')}
                  className="px-4 py-2 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs rounded-xl shadow-md transition-colors"
                >
                  Fire Test Alert
                </button>
              </div>
            )}
          </div>

          {/* Save / Cancel Footer */}
          <div className="relative z-10 pt-6 mt-4 border-t border-[rgba(255,255,255,0.05)] flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-xs font-bold text-[#A1A1AA] hover:text-white bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] rounded-xl transition-colors font-sans uppercase tracking-wider"
            >
              Cancel
            </button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSave}
              className="px-6 py-2.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] transition-all font-sans border border-[rgba(255,255,255,0.1)]"
            >
              Save Thresholds
            </motion.button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
