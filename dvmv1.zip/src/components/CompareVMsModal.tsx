import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Cpu,
  Activity,
  HardDrive,
  Network,
  Plus,
  Trash2,
  Check,
  Zap,
  TrendingUp,
  Server,
  Layers,
  ArrowRightLeft
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { VMInstance } from '../types';
import { useTheme } from '../context/ThemeContext';

interface CompareVMsModalProps {
  isOpen: boolean;
  onClose: () => void;
  vms: VMInstance[];
  initialSelectedIds?: string[];
}

// Preset distinct neon color palette for multi-instance lines
const VM_COLORS = [
  { name: 'Purple', hex: '#8B5CF6', glow: 'rgba(139,92,246,0.5)', badge: 'bg-[#8B5CF6]/20 text-[#D8B4FE] border-[#8B5CF6]/40' },
  { name: 'Blue', hex: '#3B82F6', glow: 'rgba(59,130,246,0.5)', badge: 'bg-[#3B82F6]/20 text-[#93C5FD] border-[#3B82F6]/40' },
  { name: 'Cyan', hex: '#22D3EE', glow: 'rgba(34,211,238,0.5)', badge: 'bg-[#22D3EE]/20 text-[#A5F3FC] border-[#22D3EE]/40' },
  { name: 'Emerald', hex: '#10B981', glow: 'rgba(16,185,129,0.5)', badge: 'bg-[#10B981]/20 text-[#A7F3D0] border-[#10B981]/40' },
  { name: 'Amber', hex: '#F59E0B', glow: 'rgba(245,158,11,0.5)', badge: 'bg-[#F59E0B]/20 text-[#FDE68A] border-[#F59E0B]/40' },
];

export const CompareVMsModal: React.FC<CompareVMsModalProps> = ({
  isOpen,
  onClose,
  vms,
  initialSelectedIds = []
}) => {
  const { theme } = useTheme();

  // Selected VMs to compare (default to initialSelectedIds or first 2 VMs)
  const [selectedVmIds, setSelectedVmIds] = useState<string[]>(() => {
    if (initialSelectedIds.length >= 2) return initialSelectedIds;
    if (initialSelectedIds.length === 1 && vms.length > 1) {
      const second = vms.find(v => v.id !== initialSelectedIds[0]);
      return second ? [initialSelectedIds[0], second.id] : [initialSelectedIds[0]];
    }
    return vms.slice(0, 2).map(v => v.id);
  });

  // Active Metric mode: 'cpu' | 'ram' | 'disk' | 'network'
  const [metric, setMetric] = useState<'cpu' | 'ram' | 'disk' | 'network'>('cpu');
  // Timeframe: '15m' | '1h' | '6h' | '24h'
  const [timeframe, setTimeframe] = useState<'15m' | '1h' | '6h'>('15m');

  // Simulated live comparative telemetry data
  const [chartData, setChartData] = useState<any[]>([]);

  // Sync selected VM IDs when modal opens with new initialSelectedIds
  useEffect(() => {
    if (isOpen) {
      if (initialSelectedIds.length >= 2) {
        setSelectedVmIds(initialSelectedIds);
      } else if (selectedVmIds.length < 2 && vms.length >= 2) {
        setSelectedVmIds(vms.slice(0, 2).map(v => v.id));
      }
    }
  }, [isOpen, initialSelectedIds]);

  // Generate mock timeseries data for all selected VMs
  useEffect(() => {
    if (!isOpen) return;

    const generateData = () => {
      const selected = vms.filter(v => selectedVmIds.includes(v.id));
      const points = 12;
      const result = [];
      const now = new Date();

      for (let i = points - 1; i >= 0; i--) {
        const timePoint = new Date(now.getTime() - i * 60 * 1000);
        const timeStr = `${timePoint.getHours().toString().padStart(2, '0')}:${timePoint.getMinutes().toString().padStart(2, '0')}`;

        const row: any = { time: timeStr };

        selected.forEach((vm) => {
          // Base metric values with small realistic variance per time tick
          const noise = (Math.sin(i * 0.8) + (Math.random() - 0.5) * 1.5);
          if (metric === 'cpu') {
            row[vm.name] = Math.min(100, Math.max(5, Math.round((vm.cpuUsagePct + noise * 6) * 10) / 10));
          } else if (metric === 'ram') {
            row[vm.name] = Math.min(100, Math.max(10, Math.round((vm.ramUsagePct + noise * 3) * 10) / 10));
          } else if (metric === 'disk') {
            // Disk I/O rate MB/s
            const baseDisk = vm.id.charCodeAt(0) % 30 + 12;
            row[vm.name] = Math.min(250, Math.max(2, Math.round((baseDisk + noise * 12) * 10) / 10));
          } else {
            // Network KB/s
            const baseNet = vm.id.charCodeAt(0) % 400 + 300;
            row[vm.name] = Math.min(2000, Math.max(50, Math.round(baseNet + noise * 120)));
          }
        });

        result.push(row);
      }
      return result;
    };

    setChartData(generateData());

    // Live update tick
    const interval = setInterval(() => {
      setChartData(prev => {
        if (prev.length === 0) return prev;
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
        
        const selected = vms.filter(v => selectedVmIds.includes(v.id));
        const newRow: any = { time: timeStr };

        selected.forEach(vm => {
          const lastVal = prev[prev.length - 1][vm.name] || 50;
          const delta = (Math.random() - 0.5) * 4;
          newRow[vm.name] = Math.min(100, Math.max(2, Math.round((lastVal + delta) * 10) / 10));
        });

        return [...prev.slice(1), newRow];
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isOpen, selectedVmIds, metric, timeframe, vms]);

  if (!isOpen) return null;

  const selectedVMs = vms.filter(v => selectedVmIds.includes(v.id));
  const unselectedVMs = vms.filter(v => !selectedVmIds.includes(v.id));

  const toggleVmSelection = (vmId: string) => {
    if (selectedVmIds.includes(vmId)) {
      if (selectedVmIds.length <= 1) return; // Keep at least one
      setSelectedVmIds(prev => prev.filter(id => id !== vmId));
    } else {
      if (selectedVmIds.length >= 5) return; // Limit to 5
      setSelectedVmIds(prev => [...prev, vmId]);
    }
  };

  // Find VM with highest metric
  const getTopInstance = () => {
    if (selectedVMs.length === 0) return null;
    return [...selectedVMs].sort((a, b) => {
      if (metric === 'cpu') return b.cpuUsagePct - a.cpuUsagePct;
      if (metric === 'ram') return b.ramUsagePct - a.ramUsagePct;
      return b.diskGB - a.diskGB;
    })[0];
  };

  const topInstance = getTopInstance();

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Modal Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-xl"
        />

        {/* Modal Main Dialog Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', stiffness: 350, damping: 30 }}
          className="relative w-full max-w-6xl glass-panel border border-[rgba(255,255,255,0.15)] rounded-[2.5rem] shadow-[0_25px_70px_rgba(0,0,0,0.8)] overflow-hidden z-10 flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 lg:p-8 border-b border-[rgba(255,255,255,0.08)] flex items-center justify-between gap-4 bg-[rgba(10,10,15,0.6)]">
            <div className="flex items-center gap-3.5">
              <div className="p-3 bg-[#A855F7]/15 border border-[#A855F7]/30 rounded-2xl text-[#C084FC] shadow-[0_0_20px_rgba(168,85,247,0.3)]">
                <ArrowRightLeft className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black text-white tracking-wide font-sans flex items-center gap-2">
                  Compare Instance Performance
                  <span className="text-xs px-3 py-1 rounded-full bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 font-mono font-bold">
                    {selectedVMs.length} Selected
                  </span>
                </h2>
                <p className="text-xs text-[#A1A1AA] mt-1 font-medium">
                  Side-by-side telemetry benchmarking and resource allocation matrix
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2.5 rounded-2xl bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.12)] text-[#A1A1AA] hover:text-white transition-all border border-[rgba(255,255,255,0.08)]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-6 lg:p-8 space-y-8 overflow-y-auto custom-scrollbar flex-1">
            {/* Instance Selection Chips Bar */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-[#A1A1AA] uppercase tracking-wider">
                <span>Active Comparison Targets (Max 5)</span>
                <span>Click pill to toggle instance</span>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                {vms.map((vm) => {
                  const isSelected = selectedVmIds.includes(vm.id);
                  const colorIndex = selectedVmIds.indexOf(vm.id);
                  const colorObj = isSelected ? VM_COLORS[colorIndex % VM_COLORS.length] : null;

                  return (
                    <button
                      key={vm.id}
                      onClick={() => toggleVmSelection(vm.id)}
                      className={`px-3.5 py-2 rounded-2xl text-xs font-bold font-sans transition-all flex items-center gap-2 border ${
                        isSelected && colorObj
                          ? `${colorObj.badge} shadow-lg shadow-[${colorObj.hex}]/10`
                          : 'bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.08)] text-[#A1A1AA] border-[rgba(255,255,255,0.06)]'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: isSelected && colorObj ? colorObj.hex : '#52525B' }}
                      />
                      <span>{vm.name}</span>
                      <span className="font-mono text-[10px] opacity-70">({vm.vmid})</span>
                      {isSelected ? (
                        <Check className="w-3.5 h-3.5 ml-1 opacity-80" />
                      ) : (
                        <Plus className="w-3.5 h-3.5 ml-1 opacity-50" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Metric Mode Switcher & Timeframe Controls */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-2 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.06)] rounded-2xl">
              {/* Metric Mode Buttons */}
              <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                {[
                  { id: 'cpu', label: 'CPU Usage (%)', icon: Cpu },
                  { id: 'ram', label: 'RAM Memory (%)', icon: Activity },
                  { id: 'disk', label: 'Disk I/O (MB/s)', icon: HardDrive },
                  { id: 'network', label: 'Network (KB/s)', icon: Network },
                ].map((m) => {
                  const Icon = m.icon;
                  const isActive = metric === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setMetric(m.id as any)}
                      className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                        isActive
                          ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/40 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                          : 'text-[#A1A1AA] hover:text-white border border-transparent'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{m.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Timeframe selector */}
              <div className="flex items-center gap-1 p-1 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.05)] rounded-xl">
                {(['15m', '1h', '6h'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-3 py-1 text-[11px] font-mono font-bold rounded-lg transition-colors ${
                      timeframe === tf
                        ? 'bg-[rgba(255,255,255,0.15)] text-white'
                        : 'text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Consolidated Comparative Line Chart */}
            <div className="glass-card rounded-[2rem] p-6 space-y-4 border border-[rgba(255,255,255,0.08)] bg-[rgba(10,10,15,0.8)] shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
                  <Activity className="w-4 h-4 text-[#22D3EE] animate-pulse" />
                  <span>Consolidated Real-Time Comparison Stream</span>
                </div>
                {topInstance && (
                  <span className="text-[11px] font-mono text-[#A1A1AA] bg-[rgba(255,255,255,0.05)] px-3 py-1 rounded-full border border-[rgba(255,255,255,0.05)]">
                    Peak Load: <strong className="text-[#F59E0B]">{topInstance.name}</strong> ({topInstance.cpuUsagePct}%)
                  </span>
                )}
              </div>

              {/* Recharts Consolidated Line Chart */}
              <div className="h-[280px] w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 10, right: 30, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
                    <XAxis dataKey="time" stroke="#71717A" fontSize={11} tickLine={false} />
                    <YAxis stroke="#71717A" fontSize={11} tickLine={false} domain={[0, 'auto']} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(10, 10, 15, 0.95)',
                        borderColor: 'rgba(255, 255, 255, 0.15)',
                        borderRadius: '1rem',
                        boxShadow: '0 20px 40px rgba(0,0,0,0.8)',
                        backdropFilter: 'blur(16px)',
                        padding: '12px 16px',
                        color: '#FFFFFF'
                      }}
                      itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                      labelStyle={{ color: '#A1A1AA', fontSize: '11px', fontFamily: 'monospace', marginBottom: '8px' }}
                    />
                    <Legend
                      wrapperStyle={{ paddingTop: '15px', fontSize: '12px', fontWeight: 'bold' }}
                    />
                    {/* Alert Threshold line for % metrics */}
                    {(metric === 'cpu' || metric === 'ram') && (
                      <ReferenceLine y={80} stroke="#F43F5E" strokeDasharray="4 4" label={{ value: 'Warning Limit (80%)', fill: '#F43F5E', fontSize: 10, position: 'insideTopRight' }} />
                    )}

                    {selectedVMs.map((vm, index) => {
                      const colorObj = VM_COLORS[index % VM_COLORS.length];
                      return (
                        <Line
                          key={vm.id}
                          type="monotone"
                          dataKey={vm.name}
                          stroke={colorObj.hex}
                          strokeWidth={2.5}
                          dot={{ r: 3, fill: colorObj.hex, stroke: '#030305', strokeWidth: 1 }}
                          activeDot={{ r: 6, fill: '#FFFFFF', stroke: colorObj.hex, strokeWidth: 2 }}
                        />
                      );
                    })}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Side-by-Side Spec Comparison Grid */}
            <div className="space-y-4">
              <h3 className="text-sm font-black text-white tracking-wide uppercase font-sans flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#A855F7]" />
                Side-by-Side Specification Matrix
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {selectedVMs.map((vm, index) => {
                  const colorObj = VM_COLORS[index % VM_COLORS.length];
                  return (
                    <div
                      key={vm.id}
                      className="glass-card p-5 rounded-[2rem] border border-[rgba(255,255,255,0.08)] hover:border-[#A855F7]/40 space-y-4 relative overflow-hidden group transition-all"
                    >
                      {/* Top colored accent line */}
                      <div
                        className="absolute top-0 left-0 right-0 h-1"
                        style={{ backgroundColor: colorObj.hex }}
                      />

                      {/* VM Title & Status */}
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-bold text-white text-base font-sans">{vm.name}</h4>
                          <span className="text-[11px] text-[#A1A1AA] font-mono">vMID: {vm.vmid} • {vm.node}</span>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                            vm.status === 'running'
                              ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20'
                              : 'bg-gray-800 text-gray-400 border-gray-700'
                          }`}
                        >
                          {vm.status}
                        </span>
                      </div>

                      {/* Specs List */}
                      <div className="space-y-2.5 pt-2 text-xs font-mono border-t border-[rgba(255,255,255,0.05)]">
                        <div className="flex justify-between py-1 border-b border-[rgba(255,255,255,0.03)]">
                          <span className="text-[#A1A1AA] font-sans">Operating System:</span>
                          <span className="text-white font-bold">{vm.osName}</span>
                        </div>

                        <div className="flex justify-between py-1 border-b border-[rgba(255,255,255,0.03)]">
                          <span className="text-[#A1A1AA] font-sans">vCPU Cores:</span>
                          <span className="text-white font-bold">{vm.vcpu} Cores ({vm.cpuUsagePct}% load)</span>
                        </div>

                        <div className="flex justify-between py-1 border-b border-[rgba(255,255,255,0.03)]">
                          <span className="text-[#A1A1AA] font-sans">Memory (RAM):</span>
                          <span className="text-white font-bold">{vm.ramGB} GB ({vm.ramUsagePct}% used)</span>
                        </div>

                        <div className="flex justify-between py-1 border-b border-[rgba(255,255,255,0.03)]">
                          <span className="text-[#A1A1AA] font-sans">Disk Allocation:</span>
                          <span className="text-white font-bold">{vm.diskGB} GB NVMe</span>
                        </div>

                        <div className="flex justify-between py-1 border-b border-[rgba(255,255,255,0.03)]">
                          <span className="text-[#A1A1AA] font-sans">IP Address:</span>
                          <span className="text-[#22D3EE] font-bold">{vm.ipAddress}</span>
                        </div>

                        <div className="flex justify-between py-1">
                          <span className="text-[#A1A1AA] font-sans">Uptime:</span>
                          <span className="text-[#10B981] font-bold">{vm.uptime || '99.98%'}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Footer Action Bar */}
          <div className="p-6 border-t border-[rgba(255,255,255,0.08)] bg-[rgba(10,10,15,0.8)] flex items-center justify-between">
            <span className="text-xs text-[#A1A1AA] font-mono">
              Comparing {selectedVMs.length} instance(s) live.
            </span>

            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs rounded-xl shadow-lg shadow-[#8B5CF6]/20 transition-all"
            >
              Close Benchmark Window
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
