import React, { useState, useEffect } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Activity, Cpu, Network, HardDrive, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

interface ChartPoint {
  time: string;
  cpu: number;
  ram: number;
  networkRx: number;
  networkTx: number;
  diskRead: number;
}

export const MetricsChart: React.FC = () => {
  const [data, setData] = useState<ChartPoint[]>([
    { time: '05:00', cpu: 32, ram: 58, networkRx: 420, networkTx: 680, diskRead: 12 },
    { time: '05:05', cpu: 38, ram: 60, networkRx: 510, networkTx: 740, diskRead: 18 },
    { time: '05:10', cpu: 45, ram: 61, networkRx: 630, networkTx: 890, diskRead: 25 },
    { time: '05:15', cpu: 40, ram: 62, networkRx: 590, networkTx: 810, diskRead: 15 },
    { time: '05:20', cpu: 35, ram: 62, networkRx: 710, networkTx: 1050, diskRead: 20 },
    { time: '05:25', cpu: 42, ram: 63, networkRx: 840, networkTx: 1240, diskRead: 30 },
    { time: '05:30', cpu: 38, ram: 62, networkRx: 790, networkTx: 1180, diskRead: 22 },
    { time: '05:35', cpu: 44, ram: 64, networkRx: 880, networkTx: 1320, diskRead: 28 },
    { time: '05:40', cpu: 36, ram: 62, networkRx: 842, networkTx: 1240, diskRead: 19 },
  ]);

  const [activeMetric, setActiveMetric] = useState<'cpu_ram' | 'network'>('cpu_ram');

  // Real-time jitter telemetry simulation
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;

      setData((prev) => {
        const last = prev[prev.length - 1];
        const newCpu = Math.min(95, Math.max(15, last.cpu + (Math.random() * 8 - 4)));
        const newRam = Math.min(90, Math.max(40, last.ram + (Math.random() * 2 - 1)));
        const newRx = Math.min(1500, Math.max(300, last.networkRx + (Math.random() * 100 - 50)));
        const newTx = Math.min(2000, Math.max(500, last.networkTx + (Math.random() * 120 - 60)));

        const newPoint: ChartPoint = {
          time: timeStr,
          cpu: Math.round(newCpu * 10) / 10,
          ram: Math.round(newRam * 10) / 10,
          networkRx: Math.round(newRx),
          networkTx: Math.round(newTx),
          diskRead: Math.round(Math.random() * 30 + 10),
        };

        return [...prev.slice(1), newPoint];
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="glass-panel border border-white/10/90 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10">
        <div>
          <h3 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C084FC] animate-ping" />
            <Activity className="w-4 h-4 text-[#C084FC]" />
            Live Cluster Telemetry & Bandwidth
          </h3>
          <p className="text-xs text-[#A1A1AA] mt-1">
            Real-time hypervisor resource streaming (3s update frequency)
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[rgba(0,0,0,0.9)] border border-[rgba(255,255,255,0.05)] rounded-2xl self-start sm:self-auto">
          <button
            onClick={() => setActiveMetric('cpu_ram')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              activeMetric === 'cpu_ram'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/40 shadow-lg shadow-[#A855F7]/10'
                : 'text-[#A1A1AA] hover:text-[#E4E4E7]'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-[#C084FC]" />
            <span>CPU & RAM (%)</span>
          </button>
          <button
            onClick={() => setActiveMetric('network')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              activeMetric === 'network'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/40 shadow-lg shadow-[#A855F7]/10'
                : 'text-[#A1A1AA] hover:text-[#E4E4E7]'
            }`}
          >
            <Network className="w-3.5 h-3.5 text-[#C084FC]" />
            <span>Network I/O (Mbps)</span>
          </button>
        </div>
      </div>

      {/* Recharts Canvas */}
      <div className="h-64 sm:h-72 w-full relative z-10">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="ramGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="rxGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="txGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
            <YAxis stroke="#64748b" fontSize={11} tickLine={false} />

            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(8, 11, 20, 0.95)',
                borderColor: 'rgba(51, 65, 85, 0.8)',
                borderRadius: '16px',
                color: '#f8fafc',
                fontSize: '12px',
                boxShadow: '0 25px 35px -5px rgba(0, 0, 0, 0.8)',
              }}
            />

            {activeMetric === 'cpu_ram' ? (
              <>
                <Area
                  type="monotone"
                  dataKey="cpu"
                  name="CPU Load %"
                  stroke="#a855f7"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#cpuGradient)"
                />
                <Area
                  type="monotone"
                  dataKey="ram"
                  name="RAM Usage %"
                  stroke="#8b5cf6"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#ramGradient)"
                />
              </>
            ) : (
              <>
                <Area
                  type="monotone"
                  dataKey="networkRx"
                  name="Network RX (Mbps)"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#rxGradient)"
                />
                <Area
                  type="monotone"
                  dataKey="networkTx"
                  name="Network TX (Mbps)"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#txGradient)"
                />
              </>
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Summary Stats Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-[rgba(255,255,255,0.05)] relative z-10">
        <div className="p-3 rounded-2xl bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.05)]">
          <span className="text-[10px] text-[#A1A1AA] font-semibold uppercase tracking-wider font-mono">
            Avg vCPU Load
          </span>
          <p className="text-base font-extrabold font-mono text-[#C084FC] mt-0.5">
            {data[data.length - 1]?.cpu}%
          </p>
        </div>
        <div className="p-3 rounded-2xl bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.05)]">
          <span className="text-[10px] text-[#A1A1AA] font-semibold uppercase tracking-wider font-mono">
            RAM Allocated
          </span>
          <p className="text-base font-extrabold font-mono text-[#C084FC] mt-0.5">
            {data[data.length - 1]?.ram}%
          </p>
        </div>
        <div className="p-3 rounded-2xl bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.05)]">
          <span className="text-[10px] text-[#A1A1AA] font-semibold uppercase tracking-wider font-mono">
            Ingress (RX)
          </span>
          <p className="text-base font-extrabold font-mono text-[#34D399] mt-0.5">
            {data[data.length - 1]?.networkRx} Mbps
          </p>
        </div>
        <div className="p-3 rounded-2xl bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.05)]">
          <span className="text-[10px] text-[#A1A1AA] font-semibold uppercase tracking-wider font-mono">
            Egress (TX)
          </span>
          <p className="text-base font-extrabold font-mono text-[#60A5FA] mt-0.5">
            {data[data.length - 1]?.networkTx} Mbps
          </p>
        </div>
      </div>
    </div>
  );
};
