import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Server, 
  Cpu, 
  Network, 
  HardDrive, 
  Terminal, 
  Activity, 
  Settings, 
  ShieldAlert, 
  ArrowRight, 
  X, 
  Command,
  Plus,
  RotateCcw,
  Zap,
  Globe
} from 'lucide-react';
import { VMInstance, HypervisorNode, ViewTab } from '../types';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  vms: VMInstance[];
  nodes: HypervisorNode[];
  onSelectTab: (tab: ViewTab) => void;
  onSelectVM: (vm: VMInstance) => void;
  onOpenCreateVM: () => void;
  onOpenInstaller: () => void;
  userRole?: 'admin' | 'user';
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  vms,
  nodes,
  onSelectTab,
  onSelectVM,
  onOpenCreateVM,
  onOpenInstaller,
  userRole = 'admin'
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Quick Action Commands
  const adminActions = [
    { id: 'act-create', title: 'Provision New Virtual Machine', category: 'Actions', icon: Plus, action: () => { onOpenCreateVM(); onClose(); } },
    { id: 'act-install', title: 'Open 1-Line Agent Installer Wizard', category: 'Actions', icon: Terminal, action: () => { onOpenInstaller(); onClose(); } },
    { id: 'nav-dash', title: 'Navigate to Overview Dashboard', category: 'Navigation', icon: Activity, action: () => { onSelectTab('dashboard'); onClose(); } },
    { id: 'nav-vms', title: 'Navigate to Virtual Machines List', category: 'Navigation', icon: Server, action: () => { onSelectTab('vms'); onClose(); } },
    { id: 'nav-nodes', title: 'Navigate to Hypervisor Nodes', category: 'Navigation', icon: Cpu, action: () => { onSelectTab('nodes'); onClose(); } },
    { id: 'nav-[#network]', title: 'Navigate to Network Bridges & VLANs', category: 'Navigation', icon: Network, action: () => { onSelectTab('networking'); onClose(); } },
    { id: 'nav-storage', title: 'Navigate to ZFS & NVMe Storage Pools', category: 'Navigation', icon: HardDrive, action: () => { onSelectTab('storage'); onClose(); } },
    { id: 'nav-expiring', title: 'Navigate to VPS Expiry Center', category: 'Navigation', icon: ShieldAlert, action: () => { onSelectTab('expiring'); onClose(); } },
    { id: 'nav-settings', title: 'Navigate to System Settings', category: 'Navigation', icon: Settings, action: () => { onSelectTab('settings'); onClose(); } },
  ];

  const userActions = [
    { id: 'act-create', title: 'Deploy New VPS Instance', category: 'Actions', icon: Plus, action: () => { onOpenCreateVM(); onClose(); } },
    { id: 'nav-dash', title: 'Navigate to My Cloud Overview', category: 'Navigation', icon: Activity, action: () => { onSelectTab('dashboard'); onClose(); } },
    { id: 'nav-vms', title: 'Navigate to My Virtual Machines', category: 'Navigation', icon: Server, action: () => { onSelectTab('vms'); onClose(); } },
    { id: 'nav-expiring', title: 'Navigate to Expiry Center', category: 'Navigation', icon: ShieldAlert, action: () => { onSelectTab('expiring'); onClose(); } },
    { id: 'nav-settings', title: 'Navigate to Account Settings', category: 'Navigation', icon: Settings, action: () => { onSelectTab('settings'); onClose(); } },
  ];

  const actions = userRole === 'user' ? userActions : adminActions;

  // Matching VMs
  const vmResults = vms
    .filter(vm => 
      vm.name.toLowerCase().includes(query.toLowerCase()) || 
      vm.vmid.toString().includes(query) ||
      vm.ipAddress.includes(query) ||
      vm.osName.toLowerCase().includes(query.toLowerCase())
    )
    .map(vm => ({
      id: `vm-${vm.id}`,
      title: `${vm.name} (VMID: #${vm.vmid})`,
      subtitle: `${vm.ipAddress} • ${vm.osName} • ${vm.node}`,
      category: 'Virtual Machines',
      icon: Server,
      action: () => { onSelectVM(vm); onClose(); }
    }));

  // Matching Nodes (Admin only)
  const nodeResults = userRole === 'user' ? [] : nodes
    .filter(node => 
      node.name.toLowerCase().includes(query.toLowerCase()) || 
      node.ipAddress.includes(query) ||
      node.region.toLowerCase().includes(query.toLowerCase())
    )
    .map(node => ({
      id: `node-${node.id}`,
      title: `${node.name} (${node.region})`,
      subtitle: `${node.ipAddress} • ${node.vmCount} VMs • ${node.status}`,
      category: 'Cluster Nodes',
      icon: Cpu,
      action: () => { onSelectTab('nodes'); onClose(); }
    }));

  const allItems = [
    ...vmResults,
    ...nodeResults,
    ...actions.filter(a => a.title.toLowerCase().includes(query.toLowerCase()))
  ];

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % (allItems.length || 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + allItems.length) % (allItems.length || 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (allItems[selectedIndex]) {
        allItems[selectedIndex].action();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[90] flex items-start justify-center pt-20 px-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#050509]/80 backdrop-blur-xl"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          className="relative w-full max-w-2xl glass-panel rounded-[2rem] border border-[rgba(255,255,255,0.15)] shadow-[0_25px_80px_rgba(0,0,0,0.9)] overflow-hidden z-10"
        >
          {/* Search Header Input */}
          <div className="p-5 border-b border-[rgba(255,255,255,0.08)] bg-[rgba(10,13,22,0.8)] flex items-center gap-4">
            <Search className="w-5 h-5 text-[#C084FC] shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setSelectedIndex(0); }}
              onKeyDown={handleKeyDown}
              placeholder="Search VMs, Nodes, IPs, Settings, or Commands... (Esc to close)"
              className="w-full bg-transparent text-base text-white placeholder-[#A1A1AA] outline-none font-sans font-medium"
            />
            <button
              onClick={onClose}
              className="p-1.5 text-[#A1A1AA] hover:text-white rounded-lg hover:bg-[rgba(255,255,255,0.08)] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Results List */}
          <div className="max-h-[380px] overflow-y-auto p-3 space-y-1 custom-scrollbar">
            {allItems.length === 0 ? (
              <div className="py-12 text-center text-[#A1A1AA] space-y-2">
                <Search className="w-8 h-8 mx-auto opacity-40 text-[#A855F7]" />
                <p className="text-sm font-medium">No matching infrastructure resources found</p>
                <p className="text-xs opacity-60">Try searching for "VM", "node", "ubuntu", or "storage"</p>
              </div>
            ) : (
              allItems.map((item, idx) => {
                const Icon = item.icon;
                const isSelected = idx === selectedIndex;

                return (
                  <button
                    key={item.id}
                    onClick={item.action}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`w-full flex items-center justify-between p-3.5 rounded-2xl transition-all duration-200 text-left ${
                      isSelected 
                        ? 'bg-gradient-to-r from-[#8B5CF6]/25 to-[#3B82F6]/15 border border-[#8B5CF6]/40 text-white shadow-[0_0_20px_rgba(139,92,246,0.15)]' 
                        : 'text-[#A1A1AA] hover:bg-[rgba(255,255,255,0.03)] hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div className={`p-2.5 rounded-xl border ${
                        isSelected 
                          ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-md' 
                          : 'bg-[rgba(255,255,255,0.03)] border-[rgba(255,255,255,0.08)] text-[#A1A1AA]'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white font-sans">{item.title}</div>
                        {(item as any).subtitle && (
                          <div className="text-[10px] text-[#A1A1AA] font-mono mt-0.5">{(item as any).subtitle}</div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[9px] uppercase font-mono font-bold tracking-widest px-2.5 py-1 rounded-md bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.08)] text-[#A1A1AA]">
                        {item.category}
                      </span>
                      <ArrowRight className={`w-4 h-4 transition-transform ${isSelected ? 'translate-x-1 text-[#C084FC]' : 'opacity-0'}`} />
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Footer Shortcuts Guide */}
          <div className="p-3 border-t border-[rgba(255,255,255,0.08)] bg-[rgba(10,13,22,0.6)] flex items-center justify-between text-[10px] text-[#A1A1AA] font-mono">
            <div className="flex items-center gap-3">
              <span><kbd className="px-1.5 py-0.5 bg-[rgba(255,255,255,0.08)] rounded">↑↓</kbd> Navigate</span>
              <span><kbd className="px-1.5 py-0.5 bg-[rgba(255,255,255,0.08)] rounded">↵</kbd> Select</span>
              <span><kbd className="px-1.5 py-0.5 bg-[rgba(255,255,255,0.08)] rounded">esc</kbd> Close</span>
            </div>
            <div className="text-[#C084FC] font-bold">DVM Panel Command Engine</div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
