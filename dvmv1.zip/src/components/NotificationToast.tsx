import React, { useEffect } from 'react';
import { CheckCircle2, AlertTriangle, X, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ToastProps {
  message: string | null;
  type?: 'success' | 'info' | 'error' | 'alert';
  onClose: () => void;
}

export const NotificationToast: React.FC<ToastProps> = ({ message, type = 'success', onClose }) => {
  useEffect(() => {
    if (!message) return;
    const duration = type === 'error' || type === 'alert' ? 5000 : 3500;
    const timer = setTimeout(() => onClose(), duration);
    return () => clearTimeout(timer);
  }, [message, type, onClose]);

  if (!message) return null;

  const isAlert = type === 'error' || type === 'alert';

  return (
    <AnimatePresence>
      <div className="fixed bottom-6 right-6 z-50">
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 350, damping: 25 }}
          className={`flex items-center gap-3 bg-black/95 text-slate-100 px-4 py-3 rounded-2xl shadow-2xl backdrop-blur-2xl ${
            isAlert
              ? 'border border-[#F43F5E]/80 shadow-[0_0_30px_rgba(244,63,94,0.3)] ring-1 ring-[#F43F5E]/50'
              : 'border border-[#A855F7]/50 shadow-[0_0_20px_rgba(168,85,247,0.3)]'
          }`}
        >
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
              isAlert
                ? 'bg-[#F43F5E]/20 border border-[#F43F5E]/50 text-[#F43F5E]'
                : 'bg-[#A855F7]/20 border border-[#A855F7]/40 text-[#C084FC]'
            }`}
          >
            {isAlert ? (
              <AlertTriangle className="w-4 h-4 stroke-[2.5] animate-pulse" />
            ) : (
              <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
            )}
          </div>
          <div className="flex flex-col">
            {isAlert && (
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#F43F5E]">
                High Priority Alert
              </span>
            )}
            <span className="text-xs font-bold font-mono tracking-tight">{message}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#A1A1AA] hover:text-white rounded-lg transition-colors ml-2"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
