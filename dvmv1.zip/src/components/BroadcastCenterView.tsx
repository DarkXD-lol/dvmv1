import React, { useState } from 'react';
import { 
  Megaphone, 
  AlertTriangle, 
  Info, 
  ShieldAlert, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Pin, 
  Calendar, 
  Clock, 
  X,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Announcement {
  id: string;
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'maintenance' | 'critical';
  pinned: boolean;
  date: string;
  author: string;
}

export const BroadcastCenterView: React.FC = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([
    {
      id: 'ann-1',
      title: 'Scheduled Frankfurt Node Upgrade (node-fra-01)',
      message: 'Maintenance window scheduled for August 3rd at 01:00 UTC. Brief 5-minute routing switchover expected for zero downtime migration.',
      severity: 'maintenance',
      pinned: true,
      date: 'Aug 1, 2026',
      author: 'Lead Infrastructure Engineer'
    },
    {
      id: 'ann-2',
      title: 'DVM Panel v1.8 Enterprise Release Notes',
      message: 'New features include global infrastructure mesh mapping, automated ZFS snapshots, and enhanced WebAssembly console tunnels.',
      severity: 'info',
      pinned: false,
      date: 'Jul 28, 2026',
      author: 'Product Security Team'
    }
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<Announcement['severity']>('info');
  const [pinned, setPinned] = useState(false);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) return;

    const newAnn: Announcement = {
      id: `ann-${Date.now()}`,
      title,
      message,
      severity,
      pinned,
      date: 'Just now',
      author: 'Administrator'
    };

    setAnnouncements([newAnn, ...announcements]);
    setTitle('');
    setMessage('');
    setShowCreateModal(false);
  };

  const handleDelete = (id: string) => {
    setAnnouncements(announcements.filter(a => a.id !== id));
  };

  const handleTogglePin = (id: string) => {
    setAnnouncements(announcements.map(a => a.id === id ? { ...a, pinned: !a.pinned } : a));
  };

  return (
    <div className="space-y-6">
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#8B5CF6]/20 via-[#22D3EE]/15 to-transparent rounded-full blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#D8B4FE] text-[10px] font-mono font-bold tracking-widest uppercase">
              <Megaphone className="w-3 h-3 text-[#22D3EE]" /> Global Client Notifications & Alerts
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Broadcast Center
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Broadcast high-priority notices, maintenance schedules, and security advisories to all DVM Panel users instantly.
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 hover:opacity-90 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Publish Announcement</span>
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {announcements.map((item) => (
          <div
            key={item.id}
            className={`glass-card p-6 rounded-[2rem] border transition-all space-y-3 ${
              item.pinned ? 'border-[#8B5CF6]/50 bg-gradient-to-r from-[#8B5CF6]/10 to-transparent' : 'border-white/5'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-xl ${
                  item.severity === 'critical' ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30' :
                  item.severity === 'warning' ? 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30' :
                  item.severity === 'maintenance' ? 'bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/30' :
                  'bg-[#22D3EE]/20 text-[#22D3EE] border border-[#22D3EE]/30'
                }`}>
                  {item.severity === 'critical' ? <ShieldAlert className="w-5 h-5" /> :
                   item.severity === 'warning' ? <AlertTriangle className="w-5 h-5" /> :
                   item.severity === 'maintenance' ? <Clock className="w-5 h-5" /> :
                   <Info className="w-5 h-5" />}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white font-sans">{item.title}</h3>
                    {item.pinned && (
                      <span className="px-2 py-0.5 rounded-full bg-[#8B5CF6]/20 text-[#D8B4FE] border border-[#8B5CF6]/40 text-[9px] font-mono font-bold uppercase">
                        Pinned Notice
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-[#A1A1AA] font-mono mt-0.5">Published by {item.author} • {item.date}</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleTogglePin(item.id)}
                  className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    item.pinned ? 'bg-[#8B5CF6]/20 text-[#D8B4FE] border-[#8B5CF6]/40' : 'bg-white/5 text-[#A1A1AA] border-white/10'
                  }`}
                  title={item.pinned ? 'Unpin' : 'Pin to top'}
                >
                  <Pin className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-[#A1A1AA] hover:text-rose-400 border border-white/10 transition-all cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#E2E8F0] leading-relaxed pl-11">{item.message}</p>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/40 bg-[#080A12] space-y-6 shadow-2xl relative overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-bold text-white font-sans">Publish Broadcast Announcement</h3>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A1A1AA] hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Notice Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Planned Network Upgrade"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Severity Level</label>
                  <select
                    value={severity}
                    onChange={(e) => setSeverity(e.target.value as Announcement['severity'])}
                    className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="info">Information (Blue)</option>
                    <option value="maintenance">Maintenance (Purple)</option>
                    <option value="warning">Warning (Yellow)</option>
                    <option value="critical">Critical (Red)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Message Content</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Write announcement details..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6] resize-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="pinCheck"
                    checked={pinned}
                    onChange={(e) => setPinned(e.target.checked)}
                    className="w-4 h-4 accent-[#8B5CF6] rounded"
                  />
                  <label htmlFor="pinCheck" className="text-xs text-white cursor-pointer font-medium">Pin announcement to top of dashboard</label>
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/20 cursor-pointer hover:opacity-90"
                  >
                    Publish Broadcast
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
