import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Server, 
  Cpu, 
  Network, 
  HardDrive, 
  Terminal, 
  Activity, 
  Settings, 
  ChevronLeft, 
  ChevronRight,
  ShieldAlert,
  Zap,
  Globe,
  Database,
  Layers,
  BarChart3,
  Sparkles,
  Calendar,
  Megaphone,
  Wrench
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { DvmLogo } from './DvmLogo';
import { PremiumProgressBar } from './PremiumProgressBar';

interface SidebarProps {
  activeTab?: string;
  currentTab?: string;
  setActiveTab?: (tab: string) => void;
  onSelectTab?: (tab: string) => void;
  collapsed?: boolean;
  onToggleCollapsed?: () => void;
  vmCount: number;
  nodeCount: number;
  userRole?: 'admin' | 'user';
  onToggleUserRole?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  currentTab,
  setActiveTab,
  onSelectTab,
  collapsed: externalCollapsed,
  onToggleCollapsed,
  vmCount,
  nodeCount,
  userRole = 'admin',
  onToggleUserRole,
}) => {
  const [internalCollapsed, setInternalCollapsed] = useState(false);

  const collapsed = externalCollapsed !== undefined ? externalCollapsed : internalCollapsed;
  const toggleCollapse = onToggleCollapsed || (() => setInternalCollapsed(!internalCollapsed));

  const active = activeTab || currentTab || 'dashboard';
  const handleSelectTab = (tabId: string) => {
    if (setActiveTab) setActiveTab(tabId);
    if (onSelectTab) onSelectTab(tabId);
  };

  const userNavGroups = [
    {
      groupLabel: 'MY CLOUD SERVICES',
      items: [
        { id: 'dashboard', label: 'My Cloud Overview', icon: LayoutDashboard, badge: null },
        { id: 'vms', label: 'My Virtual Machines', icon: Server, badge: vmCount },
        { id: 'expiring', label: 'Expiry Center', icon: ShieldAlert, badge: null },
      ],
    },
    {
      groupLabel: 'SETTINGS & PREFERENCES',
      items: [
        { id: 'settings', label: 'Account & Security', icon: Settings, badge: null },
      ],
    },
  ];

  const adminNavGroups = [
    {
      groupLabel: 'CONTROL CENTER',
      items: [
        { id: 'dashboard', label: 'Cluster Overview', icon: LayoutDashboard, badge: null },
        { id: 'vms', label: 'All Virtual Machines', icon: Server, badge: vmCount },
        { id: 'nodes', label: 'Hypervisor Nodes', icon: Cpu, badge: nodeCount },
        { id: 'global_map', label: 'Global Infrastructure', icon: Globe, badge: null },
      ],
    },
    {
      groupLabel: 'INFRASTRUCTURE',
      items: [
        { id: 'networking', label: 'Network Control', icon: Network, badge: null },
        { id: 'storage', label: 'Storage & ISO Pools', icon: HardDrive, badge: null },
        { id: 'scheduled_tasks', label: 'Scheduled Tasks', icon: Calendar, badge: null },
        { id: 'installer', label: 'Auto-Installer Script', icon: Terminal, badge: null },
      ],
    },
    {
      groupLabel: 'ADMINISTRATION',
      items: [
        { id: 'expiring', label: 'Expiring VPS Center', icon: ShieldAlert, badge: null },
        { id: 'broadcast', label: 'Broadcast Center', icon: Megaphone, badge: null },
        { id: 'maintenance', label: 'Maintenance Manager', icon: Wrench, badge: null },
        { id: 'logs', label: 'Global Audit Trail', icon: Activity, badge: null },
        { id: 'settings', label: 'System Settings', icon: Settings, badge: null },
      ],
    },
  ];

  const navGroups = userRole === 'user' ? userNavGroups : adminNavGroups;

  return (
    <motion.aside
      animate={{ width: collapsed ? 88 : 280 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className="relative z-20 h-full flex flex-col py-6 select-none shrink-0"
    >
      <div className="px-6 mb-8 mt-2 flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <DvmLogo className="w-10 h-10 shrink-0" />
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex flex-col"
              >
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-white tracking-tight">DVM</span>
                  <span className="text-[10px] font-bold font-mono tracking-widest text-[#3B82F6] bg-[#3B82F6]/10 border border-[#3B82F6]/20 rounded-full px-2 py-0.5 shadow-inner uppercase">
                    Pro
                  </span>
                </div>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className="relative flex h-2 w-2 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22D3EE] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#22D3EE] shadow-[0_0_8px_rgba(34,211,238,0.9)]"></span>
                  </span>
                  <span className="text-[#A1A1AA] text-[9px] uppercase font-bold tracking-widest">Cluster Online</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {!collapsed && onToggleUserRole && (
          <button
            onClick={onToggleUserRole}
            className="w-full mt-2 py-2 px-3 rounded-xl bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.08)] border border-[rgba(255,255,255,0.08)] text-[10px] font-mono font-bold uppercase tracking-wider text-[#22D3EE] flex items-center justify-between transition-all"
          >
            <span>Portal Mode:</span>
            <span className="px-2 py-0.5 rounded-full bg-[#22D3EE]/10 border border-[#22D3EE]/20 text-[#22D3EE]">
              {userRole === 'admin' ? 'Administrator' : 'Client User'}
            </span>
          </button>
        )}
      </div>

      {/* Top Navigation Links */}
      <div className="space-y-8 flex-1 overflow-y-auto custom-scrollbar pr-3 pl-3">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-3">
            <AnimatePresence mode="wait">
              {!collapsed && (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="px-4 text-[10px] font-bold text-[#A1A1AA] tracking-[0.2em] font-sans uppercase"
                >
                  {group.groupLabel}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-1.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = active === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`relative w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-[13px] transition-all duration-300 group ${
                      isActive
                        ? 'text-white'
                        : 'text-[#A1A1AA] hover:text-white'
                    } ${collapsed ? 'justify-center' : ''}`}
                    title={collapsed ? item.label : undefined}
                  >
                    {/* Active Background Glow Pill */}
                    {isActive && (
                      <motion.div
                        layoutId="sidebarActiveBg"
                        className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6]/20 to-[#3B82F6]/10 border border-[#8B5CF6]/30 rounded-2xl shadow-[0_0_20px_rgba(139,92,246,0.15)] backdrop-blur-md"
                        transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                      />
                    )}
                    
                    {/* Hover state for inactive */}
                    {!isActive && (
                      <div className="absolute inset-0 bg-white/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    )}

                    <Icon
                      className={`relative z-10 w-5 h-5 shrink-0 transition-all duration-300 ${
                        isActive ? 'text-[#A855F7] drop-shadow-[0_0_10px_rgba(168,85,247,0.8)] scale-110' : 'text-[#A1A1AA] group-hover:text-white'
                      }`}
                    />

                    <AnimatePresence mode="wait">
                      {!collapsed && (
                        <motion.span 
                          initial={{ opacity: 0, width: 0 }}
                          animate={{ opacity: 1, width: 'auto' }}
                          exit={{ opacity: 0, width: 0 }}
                          className="relative z-10 tracking-wide font-semibold whitespace-nowrap overflow-hidden"
                        >
                          {item.label}
                        </motion.span>
                      )}
                    </AnimatePresence>

                    <AnimatePresence mode="wait">
                      {!collapsed && item.badge !== null && (
                        <motion.span
                          initial={{ opacity: 0, scale: 0.5 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.5 }}
                          className={`relative z-10 ml-auto flex items-center justify-center min-w-[24px] h-6 px-2 rounded-lg text-[10px] font-mono tracking-widest font-bold transition-all duration-300 ${
                            isActive
                              ? 'bg-gradient-to-br from-[#8B5CF6] to-[#3B82F6] text-white shadow-[0_0_12px_rgba(139,92,246,0.6)]'
                              : 'bg-white/5 text-[#A1A1AA] group-hover:bg-white/10 group-hover:text-white border border-white/5'
                          }`}
                        >
                          {item.badge}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Live Telemetry & Collapse Control */}
      <div className="space-y-4 pt-6 px-3">
        <AnimatePresence mode="wait">
          {!collapsed && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="p-4 bg-[rgba(255,255,255,0.03)] backdrop-blur-xl border border-[rgba(255,255,255,0.06)] rounded-[1.25rem] space-y-3 relative overflow-hidden group"
            >
              {/* Subtle hover glow on telemetry card */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#22D3EE]/0 to-[#22D3EE]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="flex items-center justify-between text-[11px] font-sans tracking-wide relative z-10 mb-2">
                <span className="text-[#A1A1AA] font-bold flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#22D3EE] animate-pulse shadow-[0_0_10px_rgba(34,211,238,0.8)]" />
                  Cluster Load
                </span>
              </div>

              {/* Mini Progress Line */}
              <div className="relative z-10">
                 <PremiumProgressBar value={38} showValue={true} />
              </div>

              <div className="flex justify-between text-[10px] text-[#A1A1AA] font-mono relative z-10 mt-1">
                <span>18 Cores</span>
                <span>32.8 GB</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Collapse Sidebar Toggle Button */}
        <button
          onClick={toggleCollapse}
          className="w-full flex items-center justify-center gap-2 p-3 rounded-[1.25rem] text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.03)] border border-transparent hover:border-[rgba(255,255,255,0.06)] transition-all cursor-pointer group"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5 group-hover:text-white transition-colors" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span className="text-xs font-semibold tracking-wide uppercase">Collapse</span>
            </>
          )}
        </button>
      </div>
    </motion.aside>
  );
};

