import React, { useState } from 'react';
import { 
  Server, 
  Terminal, 
  Play, 
  Square, 
  RotateCw, 
  Pause, 
  Trash2, 
  MoreVertical, 
  Search, 
  Filter, 
  LayoutGrid, 
  Table as TableIcon,
  Copy,
  Check,
  Cpu,
  HardDrive,
  Activity,
  Globe,
  Tag,
  Sparkles,
  ExternalLink,
  AlertTriangle,
  ArrowRightLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VMInstance, AlertThresholdSettings } from '../types';
import { PremiumProgressBar } from './PremiumProgressBar';
import { CompareVMsModal } from './CompareVMsModal';
import { VmCardSkeleton, VmTableSkeleton } from './DashboardSkeleton';

interface VMListProps {
  vms: VMInstance[];
  onSelectVM: (vm: VMInstance) => void;
  onOpenConsole: (vm: VMInstance) => void;
  onVMAction: (vmId: string, action: 'start' | 'stop' | 'reboot' | 'pause' | 'delete') => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  onOpenCreateVM?: () => void;
  alertThresholds?: AlertThresholdSettings;
  isLoading?: boolean;
}

export const VMList: React.FC<VMListProps> = ({
  vms,
  onSelectVM,
  onOpenConsole,
  onVMAction,
  searchQuery = '',
  setSearchQuery,
  onOpenCreateVM,
  alertThresholds,
  isLoading = false,
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [statusFilter, setStatusFilter] = useState<'all' | 'running' | 'stopped' | 'paused'>('all');
  const [selectedVmIds, setSelectedVmIds] = useState<string[]>([]);
  const [copiedIp, setCopiedIp] = useState<string | null>(null);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        {viewMode === 'grid' ? <VmCardSkeleton count={6} /> : <VmTableSkeleton rows={6} />}
      </motion.div>
    );
  }

  // Filter VMs
  const filteredVMs = vms.filter((vm) => {
    const query = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !query ||
      (vm.name || '').toLowerCase().includes(query) ||
      (vm.ipAddress || '').includes(query) ||
      (vm.vmid ? vm.vmid.toString() : '').includes(query) ||
      (vm.node || '').toLowerCase().includes(query) ||
      (vm.tags || []).some((t) => (t || '').toLowerCase().includes(query));

    const matchesStatus =
      statusFilter === 'all' || vm.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleCopyIp = (e: React.MouseEvent, ip: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(ip);
    setCopiedIp(ip);
    setTimeout(() => setCopiedIp(null), 2000);
  };

  const toggleSelectAll = () => {
    if (selectedVmIds.length === filteredVMs.length) {
      setSelectedVmIds([]);
    } else {
      setSelectedVmIds(filteredVMs.map((v) => v.id));
    }
  };

  const toggleSelectVm = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedVmIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      {/* Search, Status Filters, & View Toggle Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 glass-panel p-4 sm:p-5 rounded-[2rem]">
        {/* Status Pills Filter */}
        <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar pb-2 md:pb-0">
          {[
            { id: 'all', label: `All VMs`, count: vms.length },
            { id: 'running', label: `Running`, count: vms.filter((v) => v.status === 'running').length },
            { id: 'stopped', label: `Stopped`, count: vms.filter((v) => v.status === 'stopped').length },
            { id: 'paused', label: `Paused`, count: vms.filter((v) => v.status === 'paused').length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`px-4 py-2 text-[11px] font-bold uppercase tracking-widest font-sans whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
                statusFilter === tab.id
                  ? 'bg-[#A855F7]/15 text-[#A855F7] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                  : 'bg-[rgba(255,255,255,0.03)] text-[#A1A1AA] border border-transparent hover:bg-[rgba(255,255,255,0.08)] hover:text-white'
              }`}
            >
              <span>{tab.label}</span>
              <span className="opacity-70 font-mono text-xs">({tab.count})</span>
            </button>
          ))}
        </div>

        {/* Right Controls: Compare & View Switcher */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsCompareModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#8B5CF6]/20 to-[#3B82F6]/20 hover:from-[#8B5CF6]/35 hover:to-[#3B82F6]/35 text-[#D8B4FE] border border-[#8B5CF6]/40 hover:border-[#8B5CF6]/70 rounded-2xl font-sans font-bold text-xs transition-all shadow-[0_0_20px_rgba(139,92,246,0.15)] group"
          >
            <ArrowRightLeft className="w-4 h-4 text-[#C084FC] group-hover:rotate-180 transition-transform duration-500" />
            <span>Compare Instances</span>
            {selectedVmIds.length > 0 && (
              <span className="px-2 py-0.5 text-[10px] bg-[#8B5CF6] text-white rounded-full font-mono font-black shadow-sm">
                {selectedVmIds.length}
              </span>
            )}
          </button>

          {/* View Toggle */}
          <div className="flex items-center gap-1 p-1.5 bg-[rgba(0,0,0,0.4)] border border-[rgba(255,255,255,0.05)] rounded-2xl shadow-inner">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-xl transition-all ${
                viewMode === 'grid'
                  ? 'bg-[rgba(255,255,255,0.1)] text-white shadow-sm'
                  : 'text-[#A1A1AA] hover:text-[#E4E4E7]'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-2 rounded-xl transition-all ${
                viewMode === 'table'
                  ? 'bg-[rgba(255,255,255,0.1)] text-white shadow-sm'
                  : 'text-[#A1A1AA] hover:text-[#E4E4E7]'
              }`}
              title="Table View"
            >
              <TableIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Action Bar when items selected */}
      <AnimatePresence>
        {selectedVmIds.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-3 px-5 glass-panel rounded-2xl border border-[#A855F7]/40 flex items-center justify-between gap-4 text-xs font-mono"
          >
            <span className="text-[#C084FC] font-bold">
              {selectedVmIds.length} VM(s) Selected for Bulk Power Ops
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsCompareModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#A855F7]/25 hover:bg-[#A855F7]/40 text-white rounded-xl border border-[#A855F7]/50 font-sans font-bold transition-all shadow-md shadow-[#A855F7]/20 mr-2"
              >
                <ArrowRightLeft className="w-3.5 h-3.5 text-[#D8B4FE]" />
                <span>Compare Selected ({selectedVmIds.length})</span>
              </button>
              <button
                onClick={() => selectedVmIds.forEach((id) => onVMAction(id, 'start'))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#10B981]/20 hover:bg-[#10B981]/30 text-[#10B981] rounded-xl border border-[#10B981]/30 font-sans font-bold transition-colors"
              >
                <Play className="w-3.5 h-3.5" /> Start
              </button>
              <button
                onClick={() => selectedVmIds.forEach((id) => onVMAction(id, 'reboot'))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F59E0B]/20 hover:bg-[#F59E0B]/30 text-[#FBBF24] rounded-xl border border-[#F59E0B]/30 font-sans font-bold transition-colors"
              >
                <RotateCw className="w-3.5 h-3.5" /> Reboot
              </button>
              <button
                onClick={() => selectedVmIds.forEach((id) => onVMAction(id, 'stop'))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F43F5E]/20 hover:bg-[#F43F5E]/30 text-[#FDA4AF] rounded-xl border border-[#F43F5E]/30 font-sans font-bold transition-colors"
              >
                <Square className="w-3.5 h-3.5" /> Stop
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* GRID VIEW */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVMs.map((vm) => {
            const isRunning = vm.status === 'running';
            const isPaused = vm.status === 'paused';
            
            const isCpuAlert = Boolean(alertThresholds?.enabled && isRunning && vm.cpuUsagePct >= (alertThresholds?.cpuLimitPct ?? 80));
            const isRamAlert = Boolean(alertThresholds?.enabled && isRunning && vm.ramUsagePct >= (alertThresholds?.ramLimitPct ?? 85));
            const isBreaching = isCpuAlert || isRamAlert;

            return (
              <motion.div
                key={vm.id}
                whileHover={{ y: -5, scale: 1.02 }}
                onClick={() => onSelectVM(vm)}
                className={`glass-card rounded-[2rem] p-6 cursor-pointer flex flex-col justify-between space-y-6 group relative overflow-hidden transition-all hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.5)] ${
                  isBreaching 
                    ? 'border-2 border-[#F43F5E]/80 ring-2 ring-[#F43F5E]/30 shadow-[0_0_35px_rgba(244,63,94,0.35)]' 
                    : 'hover:border-[rgba(255,255,255,0.2)]'
                }`}
              >
                {/* Background Glow Ring on hover or alert */}
                <div className={`absolute -top-16 -right-16 w-48 h-48 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
                  isBreaching ? 'bg-[#F43F5E]/25 animate-pulse' : 'bg-[#A855F7]/10 group-hover:bg-[#A855F7]/20'
                }`} />
                <div className="absolute inset-0 bg-gradient-to-b from-[rgba(255,255,255,0.02)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                {/* Card Header Top */}
                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      {/* Selection Checkbox */}
                      <button
                        onClick={(e) => toggleSelectVm(vm.id, e)}
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all shrink-0 ${
                          selectedVmIds.includes(vm.id)
                            ? 'bg-[#8B5CF6] border-[#8B5CF6] text-white shadow-[0_0_10px_rgba(139,92,246,0.5)]'
                            : 'bg-[rgba(0,0,0,0.4)] border-[rgba(255,255,255,0.2)] hover:border-[#8B5CF6]/60'
                        }`}
                        title="Select for compare or bulk action"
                      >
                        {selectedVmIds.includes(vm.id) && <Check className="w-3.5 h-3.5" />}
                      </button>

                      {/* OS Avatar Badge */}
                      <div className="w-11 h-11 rounded-2xl bg-[rgba(0,0,0,0.4)] border border-[rgba(255,255,255,0.1)] flex items-center justify-center font-sans text-xs font-bold text-white shadow-[0_0_20px_rgba(255,255,255,0.05)] shrink-0 group-hover:border-[#A855F7]/30 transition-colors">
                        {vm.vmid}
                      </div>

                      <div>
                        <h3 className="font-black text-lg text-white tracking-wide group-hover:text-[#A855F7] transition-colors flex items-center gap-2">
                          {vm.name}
                        </h3>
                        <div className="text-[11px] text-[#A1A1AA] font-sans tracking-widest uppercase mt-1 flex items-center gap-2">
                          <span className="font-bold text-[#E4E4E7]">{vm.osName}</span>
                          <span className="opacity-50">•</span>
                          <span className="text-[#A1A1AA]">{vm.node}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1 shrink-0">
                      {/* Status Pill Badge */}
                      <span
                        className={`flex items-center gap-1.5 text-[9px] font-bold font-sans uppercase tracking-widest px-3 py-1.5 rounded-full border ${
                          isRunning
                            ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20 shadow-sm'
                            : isPaused
                            ? 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20 shadow-sm'
                            : 'bg-[rgba(255,255,255,0.05)] text-[#A1A1AA] border-[rgba(255,255,255,0.05)]'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isRunning
                              ? 'bg-[#10B981] animate-pulse'
                              : isPaused
                              ? 'bg-[#F59E0B]'
                              : 'bg-[#A1A1AA]'
                          }`}
                        />
                        {vm.status}
                      </span>

                      {/* Threshold Alert Pill */}
                      {isBreaching && (
                        <span className="flex items-center gap-1 text-[8px] font-extrabold font-sans uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#F43F5E]/20 text-[#FDA4AF] border border-[#F43F5E]/50 shadow-sm">
                          <AlertTriangle className="w-2.5 h-2.5 text-[#FB7185]" /> Limit Exceeded
                        </span>
                      )}
                    </div>
                  </div>

                  {/* IPv4 Address Bar */}
                  <div className="mt-6 pt-4 border-t border-[rgba(255,255,255,0.05)] flex items-center justify-between text-[11px] font-mono font-bold tracking-wide">
                    <span className="text-[#A1A1AA] font-sans uppercase">IPv4 Address</span>
                    <button
                      onClick={(e) => handleCopyIp(e, vm.ipAddress)}
                      className="flex items-center gap-2 text-[#C084FC] font-bold hover:text-[#E9D5FF] bg-[rgba(0,0,0,0.4)] px-3 py-1.5 rounded-xl border border-[rgba(255,255,255,0.05)] shadow-inner transition-colors"
                    >
                      <span>{vm.ipAddress}</span>
                      {copiedIp === vm.ipAddress ? (
                        <Check className="w-3.5 h-3.5 text-[#10B981]" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-[#A1A1AA]" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Resource Meter Gauges */}
                <div className="space-y-4 pt-1 relative z-10">
                  <PremiumProgressBar
                    value={vm.cpuUsagePct}
                    label={`vCPU (${vm.vcpu} Cores)${isCpuAlert ? ' (ALERT)' : ''}`}
                    showValue={true}
                    size="sm"
                  />

                  <PremiumProgressBar
                    value={vm.ramUsagePct}
                    label={`RAM (${vm.ramGB} GB)${isRamAlert ? ' (ALERT)' : ''}`}
                    showValue={true}
                    size="sm"
                  />
                </div>

                {/* Card Footer Quick Power Toolbar */}
                <div className="pt-5 mt-2 border-t border-[rgba(255,255,255,0.05)] flex items-center justify-between gap-2 relative z-10">
                  <div className="flex items-center gap-1.5">
                    {/* Console Button */}
                    {isRunning && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenConsole(vm);
                        }}
                        className="p-2.5 bg-[#A855F7]/10 hover:bg-[#A855F7]/20 text-[#A855F7] hover:text-[#C084FC] rounded-xl transition-all border border-[#A855F7]/20 hover:border-[#A855F7]/50"
                        title="Web Console VNC"
                      >
                        <Terminal className="w-4 h-4" />
                      </button>
                    )}

                    {/* Power Toggle Actions */}
                    {isRunning ? (
                      <>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onVMAction(vm.id, 'reboot');
                          }}
                          className="p-2.5 bg-[#F59E0B]/10 hover:bg-[#F59E0B]/20 text-[#FBBF24] hover:text-[#FCD34D] rounded-xl transition-all border border-[#F59E0B]/20 hover:border-[#F59E0B]/50"
                          title="Soft Reboot VM"
                        >
                          <RotateCw className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onVMAction(vm.id, 'stop');
                          }}
                          className="p-2.5 bg-[#F43F5E]/10 hover:bg-[#F43F5E]/20 text-[#FB7185] hover:text-[#FDA4AF] rounded-xl transition-all border border-[#F43F5E]/20 hover:border-[#F43F5E]/50"
                          title="Power Off VM"
                        >
                          <Square className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onVMAction(vm.id, 'start');
                        }}
                        className="p-2.5 bg-[#10B981]/10 hover:bg-[#10B981]/20 text-[#10B981] hover:text-[#34D399] rounded-xl transition-all border border-[#10B981]/20 hover:border-[#10B981]/50"
                        title="Start VM"
                      >
                        <Play className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Tags Pills */}
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    {vm.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[9px] font-bold font-sans uppercase tracking-widest bg-[rgba(255,255,255,0.05)] text-[#A1A1AA] px-2.5 py-1 rounded-md border border-[rgba(255,255,255,0.05)] truncate"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="glass-panel rounded-[2rem] overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
          <table className="w-full text-left text-sm font-sans tracking-wide">
            <thead className="bg-[rgba(0,0,0,0.4)] text-[#A1A1AA] uppercase font-bold border-b border-[rgba(255,255,255,0.05)] text-[10px] tracking-widest">
              <tr>
                <th className="p-5 w-10">
                  <input
                    type="checkbox"
                    checked={selectedVmIds.length === filteredVMs.length && filteredVMs.length > 0}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.1)] appearance-none checked:bg-[#A855F7] cursor-pointer"
                  />
                </th>
                <th className="p-5">VM ID & Name</th>
                <th className="p-5">Status</th>
                <th className="p-5">IPv4 Address</th>
                <th className="p-5">Hardware Specs</th>
                <th className="p-5">Node Host</th>
                <th className="p-5">CPU / RAM Load</th>
                <th className="p-5 text-right">Power Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(255,255,255,0.05)] text-[#E4E4E7]">
              {filteredVMs.map((vm) => {
                const isSelected = selectedVmIds.includes(vm.id);
                const isRunning = vm.status === 'running';

                return (
                  <tr
                    key={vm.id}
                    onClick={() => onSelectVM(vm)}
                    className={`hover:bg-[rgba(255,255,255,0.03)] cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#A855F7]/10' : ''
                    }`}
                  >
                    <td className="p-5" onClick={(e) => toggleSelectVm(vm.id, e)}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}}
                        className="w-4 h-4 rounded bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.1)] appearance-none checked:bg-[#A855F7] cursor-pointer"
                      />
                    </td>
                    <td className="p-5 font-mono">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-[#A855F7] bg-[#A855F7]/10 px-2 py-1 rounded-md border border-[#A855F7]/20 text-xs">vmid:{vm.vmid}</span>
                        <div>
                          <div className="font-bold text-white font-sans text-sm tracking-wide">{vm.name}</div>
                          <div className="text-[10px] text-[#A1A1AA] font-sans uppercase tracking-widest font-bold mt-0.5">{vm.osName}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-5">
                      <span
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[9px] font-sans uppercase tracking-widest font-bold ${
                          isRunning
                            ? 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 shadow-sm'
                            : 'bg-[rgba(255,255,255,0.05)] text-[#A1A1AA] border border-[rgba(255,255,255,0.05)] shadow-sm'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isRunning ? 'bg-[#10B981] animate-pulse' : 'bg-[#A1A1AA]'
                          }`}
                        />
                        {vm.status}
                      </span>
                    </td>
                    <td className="p-5 font-mono font-bold text-[#C084FC] text-xs">{vm.ipAddress}</td>
                    <td className="p-5 font-mono text-[#A1A1AA] text-[11px] font-bold">
                      {vm.vcpu} vCPU <span className="opacity-50 mx-1">•</span> {vm.ramGB} GB RAM <span className="opacity-50 mx-1">•</span> {vm.diskGB} GB NVMe
                    </td>
                    <td className="p-5 font-mono text-[#A1A1AA] text-xs font-bold">{vm.node}</td>
                    <td className="p-5 font-mono">
                      <div className="space-y-1.5 w-28">
                        <div className="flex justify-between text-[10px] font-sans uppercase tracking-widest font-bold">
                          <span className="text-[#A1A1AA]">CPU</span>
                          <span className="text-[#A855F7] font-mono">{vm.cpuUsagePct}%</span>
                        </div>
                        <div className="w-full bg-[rgba(0,0,0,0.5)] h-1.5 rounded-full overflow-hidden shadow-inner border border-[rgba(255,255,255,0.05)]">
                          <div
                            className="bg-[#A855F7] h-full rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                            style={{ width: `${vm.cpuUsagePct}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="p-5 text-right">
                      <div className="flex items-center justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                        {isRunning && (
                          <button
                            onClick={() => onOpenConsole(vm)}
                            className="p-2 bg-[#A855F7]/10 text-[#A855F7] hover:bg-[#A855F7]/20 hover:text-[#C084FC] border border-[#A855F7]/20 hover:border-[#A855F7]/50 rounded-xl transition-all"
                            title="Web Console VNC"
                          >
                            <Terminal className="w-4 h-4" />
                          </button>
                        )}
                        {isRunning ? (
                          <button
                            onClick={() => onVMAction(vm.id, 'stop')}
                            className="p-2 bg-[#F43F5E]/10 text-[#FB7185] hover:bg-[#F43F5E]/20 hover:text-[#FDA4AF] border border-[#F43F5E]/20 hover:border-[#F43F5E]/50 rounded-xl transition-all"
                            title="Stop VM"
                          >
                            <Square className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => onVMAction(vm.id, 'start')}
                            className="p-2 bg-[#10B981]/10 text-[#10B981] hover:bg-[#10B981]/20 hover:text-[#34D399] border border-[#10B981]/20 hover:border-[#10B981]/50 rounded-xl transition-all"
                            title="Start VM"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Compare Instances Telemetry Benchmark Modal */}
      <CompareVMsModal
        isOpen={isCompareModalOpen}
        onClose={() => setIsCompareModalOpen(false)}
        vms={vms}
        initialSelectedIds={selectedVmIds}
      />
    </div>
  );
};
