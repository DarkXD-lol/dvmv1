import React, { useState } from 'react';
import { Network, Shield, Plus, Check, ShieldCheck, Wifi, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { NetworkInterface, FirewallRule } from '../types';
import { INITIAL_NETWORKS, INITIAL_FIREWALL_RULES } from '../data/mockData';
import { VmCardSkeleton, VmTableSkeleton } from './DashboardSkeleton';

interface NetworkingViewProps {
  isLoading?: boolean;
}

export const NetworkingView: React.FC<NetworkingViewProps> = ({ isLoading = false }) => {
  const [networks, setNetworks] = useState<NetworkInterface[]>(INITIAL_NETWORKS);
  const [firewallRules, setFirewallRules] = useState<FirewallRule[]>(INITIAL_FIREWALL_RULES);
  const [activeTab, setActiveTab] = useState<'networks' | 'firewall'>('networks');

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <VmCardSkeleton count={3} />
      </motion.div>
    );
  }

  const toggleRule = (id: string) => {
    setFirewallRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 glass-panel p-6 lg:p-8 rounded-[2.5rem] shadow-xl">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <Network className="w-6 h-6 text-[#A855F7] drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
            Virtual Networks & SDN Firewall
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
            Software-defined networking (Open vSwitch, Linux Bridge, VXLAN, eBPF Firewall)
          </p>
        </div>

        <div className="flex items-center p-1.5 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] shadow-inner">
          <button
            onClick={() => setActiveTab('networks')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all font-sans tracking-wide uppercase ${
              activeTab === 'networks'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
            }`}
          >
            Subnets & Bridges ({networks.length})
          </button>
          <button
            onClick={() => setActiveTab('firewall')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all font-sans tracking-wide uppercase ${
              activeTab === 'firewall'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
            }`}
          >
            Firewall Rules ({firewallRules.length})
          </button>
        </div>
      </div>

      {activeTab === 'networks' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {networks.map((net) => (
            <motion.div
              key={net.id}
              whileHover={{ y: -4, scale: 1.01 }}
              className="group glass-card rounded-[1.5rem] p-6 flex flex-col justify-between space-y-4 hover:shadow-[0_15px_40px_-10px_rgba(0,0,0,0.5)] transition-all duration-500"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[rgba(255,255,255,0.03)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="flex items-start justify-between relative z-10">
                <div>
                  <h3 className="font-black text-lg text-white tracking-wide">{net.name}</h3>
                  <div className="text-xs text-[#A1A1AA] mt-1 font-mono">Bridge: {net.bridge}</div>
                </div>
                <span className="text-[10px] font-bold font-sans tracking-widest px-3 py-1.5 rounded-full bg-[#A855F7]/10 text-[#C084FC] border border-[#A855F7]/20 uppercase shadow-sm">
                  {net.type}
                </span>
              </div>

              <div className="space-y-3 text-[11px] font-mono text-[#D4D4D8] pt-3 border-t border-[rgba(255,255,255,0.05)] relative z-10">
                <div className="flex justify-between items-center">
                  <span className="text-[#A1A1AA] uppercase font-sans tracking-widest font-bold">Subnet CIDR</span>
                  <span className="text-[#D8B4FE] font-bold">{net.subnetCIDR}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#A1A1AA] uppercase font-sans tracking-widest font-bold">Gateway</span>
                  <span>{net.gateway}</span>
                </div>
                {net.vlanId && (
                  <div className="flex justify-between items-center">
                    <span className="text-[#A1A1AA] uppercase font-sans tracking-widest font-bold">VLAN Tag</span>
                    <span className="text-[#C084FC] font-bold">VLAN {net.vlanId}</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-[#A1A1AA] uppercase font-sans tracking-widest font-bold">DHCP Server</span>
                  <span className="text-[#10B981] font-bold">{net.dhcpEnabled ? 'Active' : 'Disabled'}</span>
                </div>
              </div>

              {/* IP Utilization Bar */}
              <div className="space-y-2 pt-3 relative z-10">
                <div className="flex justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA]">
                  <span>IP Pool Allocation</span>
                  <span className="text-[#E4E4E7]">
                    {net.usedIPs} / {net.totalIPs} Used
                  </span>
                </div>
                <div className="w-full bg-[rgba(0,0,0,0.4)] h-1.5 rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
                  <div
                    className="bg-gradient-to-r from-[#A855F7] to-[#3B82F6] h-full rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)] transition-all duration-500"
                    style={{ width: `${(net.usedIPs / net.totalIPs) * 100}%` }}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        /* Firewall Matrix Table */
        <div className="glass-panel rounded-3xl overflow-hidden border border-[rgba(255,255,255,0.1)] shadow-2xl">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[rgba(0,0,0,0.4)] text-[#A1A1AA] uppercase font-bold border-b border-[rgba(255,255,255,0.05)]">
              <tr>
                <th className="p-4">Rule ID</th>
                <th className="p-4">Direction</th>
                <th className="p-4">Action</th>
                <th className="p-4">Protocol & Port</th>
                <th className="p-4">Source CIDR</th>
                <th className="p-4">Description</th>
                <th className="p-4 text-right">Enabled</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(255,255,255,0.05)] text-[#E4E4E7]">
              {firewallRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-[rgba(255,255,255,0.03)] transition-colors">
                  <td className="p-4 font-bold text-[#C084FC]">{rule.id}</td>
                  <td className="p-4 uppercase text-[11px] font-bold text-[#D4D4D8]">
                    {rule.direction}
                  </td>
                  <td className="p-4">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        rule.action === 'ACCEPT'
                          ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/30'
                          : 'bg-[#F43F5E]/20 text-[#F43F5E] border border-[#F43F5E]/30'
                      }`}
                    >
                      {rule.action}
                    </span>
                  </td>
                  <td className="p-4 font-bold text-[#D8B4FE]">
                    {rule.protocol} • {rule.portRange}
                  </td>
                  <td className="p-4 text-[#D4D4D8]">{rule.sourceCIDR}</td>
                  <td className="p-4 text-[#A1A1AA] font-sans">{rule.description}</td>
                  <td className="p-4 text-right">
                    <input
                      type="checkbox"
                      checked={rule.enabled}
                      onChange={() => toggleRule(rule.id)}
                      className="w-4 h-4 accent-[#C084FC] rounded cursor-pointer bg-[rgba(255,255,255,0.1)] border-[rgba(255,255,255,0.2)]"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
