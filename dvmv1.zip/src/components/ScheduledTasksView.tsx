import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  Plus, 
  RefreshCw, 
  Terminal, 
  ShieldCheck, 
  Trash2, 
  Edit3, 
  Check, 
  X,
  Camera,
  HardDrive,
  Shield,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ScheduledTask {
  id: string;
  name: string;
  type: 'Snapshot' | 'Backup' | 'SSL Renewal' | 'Health Check' | 'Security Scan';
  target: string;
  schedule: string;
  nextRun: string;
  lastStatus: 'success' | 'failed' | 'running' | 'pending';
  lastRunTime: string;
  enabled: boolean;
  logs: string[];
}

export const ScheduledTasksView: React.FC = () => {
  const [tasks, setTasks] = useState<ScheduledTask[]>([
    {
      id: 'task-1',
      name: 'Daily ZFS Snapshot - Production Web',
      type: 'Snapshot',
      target: 'vm-prod-ubuntu-01 (ID: 101)',
      schedule: 'Every day at 02:00 UTC',
      nextRun: 'Today at 02:00 UTC',
      lastStatus: 'success',
      lastRunTime: '10 hours ago',
      enabled: true,
      logs: [
        '[02:00:01] Initializing scheduled ZFS snapshot job...',
        '[02:00:02] Freezing guest I/O buffers for vm-prod-ubuntu-01...',
        '[02:00:03] Creating atomic ZFS dataset snapshot @ snap-daily-2026-08-01',
        '[02:00:04] Snapshot completed successfully. Size: 1.42 GB.'
      ]
    },
    {
      id: 'task-2',
      name: 'Weekly Offsite S3 Backup',
      type: 'Backup',
      target: 'Cluster All Storage Pools',
      schedule: 'Every Sunday at 04:30 UTC',
      nextRun: 'In 2 days (Sunday)',
      lastStatus: 'success',
      lastRunTime: '5 days ago',
      enabled: true,
      logs: [
        '[04:30:00] Starting weekly offsite cluster backup job...',
        '[04:30:12] Encrypting ZFS stream payload with AES-256...',
        '[04:30:45] Uploading encrypted chunk archive to S3 Frankfurt bucket...',
        '[04:32:10] Backup verification checksum passed. Integrity OK.'
      ]
    },
    {
      id: 'task-3',
      name: 'Automated Let\'s Encrypt SSL Renewal',
      type: 'SSL Renewal',
      target: 'dvm.cloud-engine.internal',
      schedule: 'Every 60 days at midnight',
      nextRun: 'In 14 days',
      lastStatus: 'success',
      lastRunTime: '46 days ago',
      enabled: true,
      logs: [
        '[00:00:01] Checking TLS certificate expiry for dvm.cloud-engine...',
        '[00:00:02] Certificate valid for 14 more days. Renewal pending threshold.'
      ]
    },
    {
      id: 'task-4',
      name: 'Hypervisor Node Health & SMART Check',
      type: 'Health Check',
      target: 'All 5 Cluster Nodes',
      schedule: 'Every 6 hours',
      nextRun: 'In 2 hours 15 mins',
      lastStatus: 'success',
      lastRunTime: '3 hours ago',
      enabled: true,
      logs: [
        '[06:00:00] Polling SMART disk health for NVMe RAID pools...',
        '[06:00:02] All NVMe wear levels nominal (< 4%). Node temps normal.'
      ]
    }
  ]);

  const [selectedTask, setSelectedTask] = useState<ScheduledTask | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTaskName, setNewTaskName] = useState('');
  const [newTaskType, setNewTaskType] = useState<ScheduledTask['type']>('Snapshot');
  const [newTaskSchedule, setNewTaskSchedule] = useState('Daily at 03:00 UTC');

  const handleToggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, enabled: !t.enabled } : t));
  };

  const handleRunNow = (id: string) => {
    setTasks(tasks.map(t => {
      if (t.id === id) {
        return {
          ...t,
          lastStatus: 'running',
          logs: [`[${new Date().toLocaleTimeString()}] Manually triggered execution started...`, ...t.logs]
        };
      }
      return t;
    }));

    setTimeout(() => {
      setTasks(prev => prev.map(t => {
        if (t.id === id) {
          return {
            ...t,
            lastStatus: 'success',
            lastRunTime: 'Just now',
            logs: [`[${new Date().toLocaleTimeString()}] Task execution completed successfully.`, ...t.logs]
          };
        }
        return t;
      }));
    }, 2000);
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskName) return;

    const newTask: ScheduledTask = {
      id: `task-${Date.now()}`,
      name: newTaskName,
      type: newTaskType,
      target: 'Default Target VPS / Node',
      schedule: newTaskSchedule,
      nextRun: 'Tomorrow at 03:00 UTC',
      lastStatus: 'pending',
      lastRunTime: 'Never',
      enabled: true,
      logs: [`[${new Date().toLocaleTimeString()}] Task registered in cron scheduler.`]
    };

    setTasks([newTask, ...tasks]);
    setNewTaskName('');
    setShowCreateModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#8B5CF6]/20 via-[#22D3EE]/15 to-transparent rounded-full blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#D8B4FE] text-[10px] font-mono font-bold tracking-widest uppercase">
              <Calendar className="w-3 h-3 text-[#22D3EE]" /> Automated Job Scheduler & Cron Engine
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Scheduled Tasks & Backups
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Manage automated snapshots, offsite backups, SSL certificate renewals, and hypervisor health cron jobs with real-time logs.
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/25 hover:opacity-90 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Scheduled Task</span>
          </button>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-4">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="glass-card p-6 rounded-[2rem] border border-white/5 hover:border-[#8B5CF6]/30 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-6 group"
          >
            <div className="flex items-start gap-4">
              <div className={`p-3.5 rounded-2xl shrink-0 mt-1 ${
                task.type === 'Snapshot' ? 'bg-[#8B5CF6]/20 text-[#C084FC] border border-[#8B5CF6]/30' :
                task.type === 'Backup' ? 'bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/30' :
                'bg-[#22D3EE]/20 text-[#22D3EE] border border-[#22D3EE]/30'
              }`}>
                {task.type === 'Snapshot' ? <Camera className="w-6 h-6" /> :
                 task.type === 'Backup' ? <HardDrive className="w-6 h-6" /> :
                 <Shield className="w-6 h-6" />}
              </div>

              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="text-base font-bold text-white font-sans">{task.name}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                    task.lastStatus === 'success' ? 'bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40' :
                    task.lastStatus === 'running' ? 'bg-[#3B82F6]/20 text-[#3B82F6] border border-[#3B82F6]/40 animate-pulse' :
                    'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40'
                  }`}>
                    {task.lastStatus}
                  </span>
                  {!task.enabled && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-white/5 text-[#A1A1AA] border border-white/10 uppercase">
                      Disabled
                    </span>
                  )}
                </div>

                <div className="text-xs text-[#A1A1AA] flex flex-wrap items-center gap-4 font-mono">
                  <span>Target: <strong className="text-white">{task.target}</strong></span>
                  <span>•</span>
                  <span>Schedule: <strong className="text-white">{task.schedule}</strong></span>
                  <span>•</span>
                  <span>Next Run: <strong className="text-[#22D3EE]">{task.nextRun}</strong></span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 lg:pt-0 border-t lg:border-t-0 border-white/5">
              <button
                onClick={() => setSelectedTask(task)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-all border border-white/10 cursor-pointer"
              >
                <Terminal className="w-3.5 h-3.5 text-[#22D3EE]" />
                <span>View Run Logs</span>
              </button>

              <button
                onClick={() => handleRunNow(task.id)}
                disabled={task.lastStatus === 'running'}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/30 text-[#D8B4FE] text-xs font-bold transition-all border border-[#8B5CF6]/40 cursor-pointer disabled:opacity-50"
              >
                <Play className={`w-3.5 h-3.5 ${task.lastStatus === 'running' ? 'animate-spin' : ''}`} />
                <span>{task.lastStatus === 'running' ? 'Running...' : 'Run Now'}</span>
              </button>

              <button
                onClick={() => handleToggleTask(task.id)}
                className={`px-3 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border ${
                  task.enabled 
                    ? 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/30 hover:bg-[#22C55E]/20' 
                    : 'bg-white/5 text-[#A1A1AA] border-white/10 hover:bg-white/10'
                }`}
              >
                {task.enabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Task Execution Logs Modal */}
      <AnimatePresence>
        {selectedTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-2xl p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/40 bg-[#080A12] space-y-6 shadow-2xl relative overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="space-y-1">
                  <div className="text-xs font-mono text-[#22D3EE] uppercase">Execution Log Viewer</div>
                  <h3 className="text-lg font-bold text-white font-sans">{selectedTask.name}</h3>
                </div>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A1A1AA] hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-mono text-[#A1A1AA]">Last Run: {selectedTask.lastRunTime} • Status: <span className="text-[#22C55E] font-bold">{selectedTask.lastStatus}</span></div>
                
                <div className="p-4 rounded-2xl bg-black/80 border border-white/10 font-mono text-xs text-[#22D3EE] space-y-2 max-h-64 overflow-y-auto">
                  {selectedTask.logs.map((log, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-[#8B5CF6]">&gt;</span>
                      <span className="text-slate-300">{log}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setSelectedTask(null)}
                  className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  Close Logs
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Create Scheduled Task Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/40 bg-[#080A12] space-y-6 shadow-2xl relative overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-bold text-white font-sans">Create Scheduled Automation Job</h3>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A1A1AA] hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateTask} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Task Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Weekly Database Snapshot"
                    value={newTaskName}
                    onChange={(e) => setNewTaskName(e.target.value)}
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Job Type</label>
                  <select
                    value={newTaskType}
                    onChange={(e) => setNewTaskType(e.target.value as ScheduledTask['type'])}
                    className="w-full px-4 py-3 bg-[#080A12] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="Snapshot">ZFS Snapshot</option>
                    <option value="Backup">Offsite Backup</option>
                    <option value="SSL Renewal">SSL Renewal</option>
                    <option value="Health Check">Hypervisor Health Check</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#A1A1AA] uppercase">Cron Schedule</label>
                  <input
                    type="text"
                    value={newTaskSchedule}
                    onChange={(e) => setNewTaskSchedule(e.target.value)}
                    className="w-full px-4 py-3 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/20 cursor-pointer hover:opacity-90"
                  >
                    Save & Schedule Job
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
