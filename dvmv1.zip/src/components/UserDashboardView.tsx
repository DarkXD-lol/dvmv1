import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Server, 
  Cpu, 
  Activity, 
  HardDrive, 
  Play, 
  Square, 
  RotateCcw, 
  Terminal, 
  Plus, 
  ShieldCheck, 
  Zap,
  CheckCircle2,
  Clock,
  Layers,
  BarChart3,
  Key,
  ShieldAlert,
  Calendar,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { VMInstance, ActivityLog } from '../types';
import { PremiumProgressBar } from './PremiumProgressBar';
import { MyResourcesSection } from './MyResourcesSection';
import { ResourceAnalyticsView } from './ResourceAnalyticsView';
import { VpsExpiryCenter } from './VpsExpiryCenter';
import { LiveActivityTimeline } from './LiveActivityTimeline';
import { DashboardFullSkeleton, VmCardSkeleton, DashboardMetricsSkeleton } from './DashboardSkeleton';

interface UserDashboardViewProps {
  vms: VMInstance[];
  logs?: ActivityLog[];
  onSelectVM: (vm: VMInstance) => void;
  onOpenConsole: (vm: VMInstance) => void;
  onOpenCreateVM: () => void;
  onVMAction: (vmId: string, action: 'start' | 'stop' | 'reboot' | 'pause' | 'delete') => void;
  onRenewVM?: (vmId: string) => void;
  isLoading?: boolean;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  vms,
  logs = [],
  onSelectVM,
  onOpenConsole,
  onOpenCreateVM,
  onVMAction,
  onRenewVM,
  isLoading = false
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'resources' | 'analytics' | 'expiry' | 'activity'>('overview');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleTriggerRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1200);
  };

  if (isLoading || isRefreshing) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <DashboardFullSkeleton />
      </motion.div>
    );
  }

  const runningVMs = vms.filter((v) => v.status === 'running');
  const stoppedVMs = vms.filter((v) => v.status === 'stopped');
  const suspendedVMs = vms.filter((v) => v.status === 'suspended');
  const expiringVMs = vms.filter((v) => {
    if (!v.expiryDate) return false;
    const exp = new Date(v.expiryDate).getTime();
    const diff = exp - Date.now();
    return diff / (1000 * 3600 * 24) <= 7;
  });

  const totalBackups = vms.filter(v => v.autoBackup).length;
  const totalSnapshots = vms.length * 3;
  const sshKeysGenerated = 4;
  const sshxKeysGenerated = 12;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="space-y-8 pb-12"
    >
      {/* "My Cloud" Hero Overview Header */}
      <div className="relative overflow-hidden rounded-[2.5rem] glass-card p-8 lg:p-12 group transition-all duration-700 border border-[rgba(255,255,255,0.08)]">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#8B5CF6]/15 rounded-full blur-[120px] pointer-events-none group-hover:bg-[#8B5CF6]/25 transition-all duration-1000" />
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-[#22D3EE]/15 rounded-full blur-[100px] pointer-events-none group-hover:bg-[#22D3EE]/20 transition-all duration-1000" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.1)] text-xs font-bold font-sans uppercase tracking-widest text-[#22D3EE] mb-4 shadow-sm backdrop-blur-md">
              <ShieldCheck className="w-4 h-4 text-[#22D3EE]" />
              My Cloud Portal • Isolated Client Vault
            </div>
            <h1 className="text-3xl lg:text-4xl font-black text-white tracking-tight font-sans">
              My Cloud Infrastructure Overview
            </h1>
            <p className="text-sm text-[#A1A1AA] mt-2 max-w-xl font-medium leading-relaxed">
              Real-time telemetry, aggregated compute capacity, automated ZFS snapshots, and instant SSH / Web console access.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleTriggerRefresh}
              className="px-4 py-3.5 bg-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.08)] text-[#22D3EE] font-bold text-xs uppercase tracking-wider rounded-2xl border border-[#22D3EE]/30 transition-all flex items-center gap-2 backdrop-blur-md"
              title="Refresh Telemetry & View Shimmer Skeleton Loading State"
            >
              <RefreshCw className="w-4 h-4 animate-spin-slow" />
              <span>Refresh</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139,92,246,0.5)' }}
              whileTap={{ scale: 0.98 }}
              onClick={onOpenCreateVM}
              className="px-6 py-3.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] text-white font-bold text-xs uppercase tracking-wider rounded-2xl shadow-[0_5px_25px_-5px_rgba(139,92,246,0.5)] transition-all flex items-center gap-2.5 border border-[rgba(255,255,255,0.15)]"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              Deploy New VPS
            </motion.button>
          </div>
        </div>


        {/* Hero Section Animated Counters Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mt-8 pt-8 border-t border-[rgba(255,255,255,0.06)] relative z-10">
          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">Total VPS</div>
            <div className="text-2xl font-black font-mono text-white mt-1">{vms.length}</div>
            <div className="text-[9px] text-[#22D3EE] font-mono mt-1">{runningVMs.length} Running</div>
          </div>

          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">Running VPS</div>
            <div className="text-2xl font-black font-mono text-[#10B981] mt-1">{runningVMs.length}</div>
            <div className="text-[9px] text-[#10B981] font-mono mt-1">100% SLA Health</div>
          </div>

          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">Stopped / Suspended</div>
            <div className="text-2xl font-black font-mono text-[#F59E0B] mt-1">{stoppedVMs.length + suspendedVMs.length}</div>
            <div className="text-[9px] text-[#A1A1AA] font-mono mt-1">Standby Mode</div>
          </div>

          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">Expiring Soon</div>
            <div className="text-2xl font-black font-mono text-[#F43F5E] mt-1">{expiringVMs.length}</div>
            <div className="text-[9px] text-[#F43F5E] font-mono mt-1">&lt; 7 Days Remaining</div>
          </div>

          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">Backups / Snapshots</div>
            <div className="text-2xl font-black font-mono text-[#C084FC] mt-1">{totalBackups + totalSnapshots}</div>
            <div className="text-[9px] text-[#C084FC] font-mono mt-1">ZFS Raid-10</div>
          </div>

          <div className="p-4 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.05)] backdrop-blur-md">
            <div className="text-[10px] font-bold text-[#A1A1AA] uppercase tracking-wider">SSH & SSHX Tunnels</div>
            <div className="text-2xl font-black font-mono text-[#3B82F6] mt-1">{sshKeysGenerated + sshxKeysGenerated}</div>
            <div className="text-[9px] text-[#3B82F6] font-mono mt-1">Encrypted Peer P2P</div>
          </div>
        </div>
      </div>

      {/* Internal Navigation Sub-tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-[rgba(10,13,22,0.8)] border border-[rgba(255,255,255,0.08)] rounded-2xl backdrop-blur-xl overflow-x-auto custom-scrollbar">
        {[
          { id: 'overview', label: 'My VPS Instances', icon: Server },
          { id: 'resources', label: 'Combined Resources', icon: Layers },
          { id: 'analytics', label: 'Resource Analytics', icon: BarChart3 },
          { id: 'expiry', label: 'Expiry & Renewals', icon: ShieldAlert },
          { id: 'activity', label: 'Live Audit Log', icon: Activity },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white shadow-lg'
                  : 'text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Sub-tab 1: My VPS Cards Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Aggregated Quick Metrics Row */}
          <MyResourcesSection vms={vms} />

          <div className="pt-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black text-white font-sans tracking-wide">
                Your Virtual Server Instances
              </h2>
              <span className="text-xs font-mono text-[#A1A1AA]">
                {vms.length} server{vms.length === 1 ? '' : 's'} provisioned
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vms.map((vm) => {
                const isRunning = vm.status === 'running';

                return (
                  <motion.div
                    key={vm.id}
                    whileHover={{ y: -6, scale: 1.01 }}
                    onClick={() => onSelectVM(vm)}
                    className="glass-card hover:border-[#8B5CF6]/40 rounded-[2rem] p-6 cursor-pointer flex flex-col justify-between space-y-6 relative overflow-hidden transition-all duration-500 group shadow-xl"
                  >
                    <div className="absolute top-0 right-0 w-36 h-36 bg-[#22D3EE]/5 rounded-full blur-2xl group-hover:bg-[#22D3EE]/15 transition-all pointer-events-none" />

                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-[10px] font-mono font-bold tracking-widest text-[#22D3EE] bg-[#22D3EE]/10 px-3 py-1 rounded-full border border-[#22D3EE]/20 shadow-inner">
                          ID: #{vm.vmid}
                        </span>
                        <span className={`flex items-center gap-1.5 text-[9px] font-bold font-sans uppercase tracking-widest px-3 py-1 rounded-full border shadow-inner ${
                          isRunning 
                            ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20' 
                            : 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full shadow-sm ${isRunning ? 'bg-[#10B981] animate-pulse' : 'bg-[#F59E0B]'}`} />
                          {vm.status}
                        </span>
                      </div>

                      <h3 className="font-black text-lg text-white group-hover:text-[#A855F7] transition-colors">
                        {vm.name}
                      </h3>
                      <div className="text-xs font-mono text-[#A1A1AA] mt-1 flex items-center justify-between">
                        <span>{vm.ipAddress}</span>
                        <span className="text-[10px] text-[#A1A1AA] uppercase font-sans tracking-wider font-bold">{vm.osName}</span>
                      </div>
                    </div>

                    <div className="space-y-3 bg-[rgba(0,0,0,0.4)] p-4 rounded-2xl border border-[rgba(255,255,255,0.03)] shadow-inner">
                      <PremiumProgressBar
                        value={vm.cpuUsagePct}
                        label={`vCPU (${vm.vcpu} Cores)`}
                        showValue={true}
                        size="sm"
                      />

                      <PremiumProgressBar
                        value={vm.ramUsagePct}
                        label={`RAM (${vm.ramGB} GB)`}
                        showValue={true}
                        size="sm"
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-[rgba(255,255,255,0.05)]" onClick={(e) => e.stopPropagation()}>
                      {isRunning ? (
                        <button
                          onClick={() => onVMAction(vm.id, 'stop')}
                          className="flex-1 py-2.5 px-3 bg-[rgba(255,255,255,0.03)] hover:bg-[#F43F5E]/20 text-[#A1A1AA] hover:text-[#F43F5E] font-bold text-xs rounded-xl border border-[rgba(255,255,255,0.05)] transition-all flex items-center justify-center gap-1.5"
                        >
                          <Square className="w-3.5 h-3.5" /> Stop
                        </button>
                      ) : (
                        <button
                          onClick={() => onVMAction(vm.id, 'start')}
                          className="flex-1 py-2.5 px-3 bg-[#10B981]/20 hover:bg-[#10B981]/30 text-[#10B981] font-bold text-xs rounded-xl border border-[#10B981]/30 transition-all flex items-center justify-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5" /> Start
                        </button>
                      )}

                      <button
                        onClick={() => onVMAction(vm.id, 'reboot')}
                        className="p-2.5 bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.1)] text-[#A1A1AA] hover:text-white rounded-xl border border-[rgba(255,255,255,0.05)] transition-all"
                        title="Reboot"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onOpenConsole(vm)}
                        className="p-2.5 bg-[#22D3EE]/20 hover:bg-[#22D3EE]/30 text-[#22D3EE] rounded-xl border border-[#22D3EE]/30 transition-all"
                        title="Web VNC Terminal Console"
                      >
                        <Terminal className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Combined Resources */}
      {activeTab === 'resources' && <MyResourcesSection vms={vms} />}

      {/* Sub-tab 3: Resource Analytics */}
      {activeTab === 'analytics' && <ResourceAnalyticsView />}

      {/* Sub-tab 4: Expiry Center */}
      {activeTab === 'expiry' && <VpsExpiryCenter vms={vms} onSelectVM={onSelectVM} onRenewVM={onRenewVM} />}

      {/* Sub-tab 5: Live Activity Timeline */}
      {activeTab === 'activity' && <LiveActivityTimeline logs={logs} />}
    </motion.div>
  );
};
