import React, { useState } from 'react';
import { BrandSystemView } from './BrandSystemView';
import { 
  Settings, 
  Key, 
  ShieldCheck, 
  Users, 
  Check, 
  Copy, 
  Plus, 
  Trash2,
  Sliders,
  Sparkles,
  Palette,
  RotateCcw,
  Zap,
  Activity,
  Layers,
  Image,
  Type,
  Sun,
  Moon,
  Wind,
  Layout,
  Download,
  Upload,
  Save,
  CopyCheck,
  Eye,
  SlidersHorizontal,
  Lock,
  ShieldAlert,
  Clock,
  Sparkle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CURRENT_USER } from '../data/mockData';
import { useTheme, PRESET_THEMES, ThemeConfig } from '../context/ThemeContext';

interface SettingsViewProps {
  userRole?: 'admin' | 'user';
}

export const SettingsView: React.FC<SettingsViewProps> = ({ userRole = 'admin' }) => {
  const [activeTab, setActiveTab] = useState<'appearance' | 'api' | 'security' | 'team'>('appearance');
  const [appearanceSubTab, setAppearanceSubTab] = useState<'brand' | 'colors' | 'glow' | 'background' | 'typography' | 'ambient' | 'animation' | 'layout' | 'management'>('brand');
  
  const { 
    theme, 
    savedThemes, 
    updateTheme, 
    applyPreset, 
    resetTheme, 
    saveCustomTheme, 
    deleteCustomTheme, 
    importThemeJSON, 
    exportThemeJSON 
  } = useTheme();

  const [newThemeName, setNewThemeName] = useState('');
  const [importJsonText, setImportJsonText] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [copiedExport, setCopiedExport] = useState(false);

  const [apiKeys, setApiKeys] = useState([
    { id: 'key-1', name: 'Terraform Automation Agent', token: 'dvm_live_pk_9a82b3c10f84...', created: '2026-06-12' },
    { id: 'key-2', name: 'Ansible Deployment Pipeline', token: 'dvm_live_pk_88f21e09923a...', created: '2026-07-01' },
  ]);
  const [copiedKey, setCopiedKey] = useState('');

  const copyToken = (tok: string) => {
    navigator.clipboard.writeText(tok);
    setCopiedKey(tok);
    setTimeout(() => setCopiedKey(''), 2000);
  };

  const presetSwatches = [
    { label: 'Neon Purple', value: '#8B5CF6' },
    { label: 'Electric Blue', value: '#3B82F6' },
    { label: 'Neon Cyan', value: '#22D3EE' },
    { label: 'Emerald Green', value: '#10B981' },
    { label: 'Amber Gold', value: '#F59E0B' },
    { label: 'Rose Pink', value: '#F43F5E' },
    { label: 'Cyber Yellow', value: '#EAB308' },
    { label: 'Deep Indigo', value: '#6366F1' },
  ];

  const fonts = [
    'Plus Jakarta Sans',
    'Inter',
    'Geist',
    'Poppins',
    'Manrope',
    'Outfit',
    'Space Grotesk',
    'Sora',
    'IBM Plex Sans'
  ];

  const backgroundStyles = [
    { id: 'aurora', label: 'Aurora Background', icon: Wind },
    { id: 'solid', label: 'Solid Color', icon: Layers },
    { id: 'gradient', label: 'Gradient Mesh', icon: Palette },
    { id: 'mesh', label: 'Animated Mesh', icon: Sparkles },
    { id: 'particles', label: 'Floating Particles', icon: Zap },
    { id: 'circuit', label: 'Circuit Network', icon: Activity },
    { id: 'neonLines', label: 'Neon Lines', icon: Sliders },
    { id: 'glass', label: 'Glassmorphism Blur', icon: Layout },
    { id: 'waves', label: 'Animated Waves', icon: Wind },
    { id: 'starfield', label: 'Starfield Space', icon: Sparkles },
    { id: 'customImage', label: 'Custom Background Image', icon: Image },
  ];

  const glowTargetKeys: Array<{ key: keyof ThemeConfig['glowTargets']; label: string }> = [
    { key: 'buttons', label: 'Buttons & Action Trigger Nodes' },
    { key: 'cards', label: 'Glass Containers & Cards' },
    { key: 'sidebar', label: 'Navigation Sidebar Border' },
    { key: 'charts', label: 'Data Charts & Performance Bars' },
    { key: 'progressBars', label: 'System Resource Progress Bars' },
    { key: 'notifications', label: 'Toast & System Notifications' },
    { key: 'dialogs', label: 'Modals & Floating Dialogs' },
    { key: 'inputs', label: 'Form Input Highlights' },
    { key: 'logo', label: 'Brand Emblem & Header Logo' },
    { key: 'icons', label: 'Status & Category Icons' },
    { key: 'activeNav', label: 'Active Navigation Indicator' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 glass-panel p-6 lg:p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-[#8B5CF6]/20 via-[#22D3EE]/20 to-transparent rounded-full blur-[100px] pointer-events-none" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#D8B4FE] text-[10px] font-mono uppercase font-bold tracking-widest flex items-center gap-1.5">
              <ShieldCheck className="w-3 h-3 text-[#3B82F6]" /> Administrator Customization Center
            </span>
          </div>
          <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <Palette className="w-7 h-7 text-[#8B5CF6] drop-shadow-[0_0_12px_rgba(139,92,246,0.8)]" />
            Appearance & Personalization Engine
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-1.5 font-medium tracking-wide">
            Real-time theme engine, ambient glow dynamics, backgrounds, typography, animations & RBAC configuration
          </p>
        </div>

        {userRole === 'admin' && (
          <div className="relative z-10 flex items-center gap-3">
            <button
              onClick={resetTheme}
              className="flex items-center gap-2 px-4 py-2.5 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#E4E4E7] text-xs font-bold uppercase tracking-wider rounded-xl transition-all border border-[rgba(255,255,255,0.1)] cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
            </button>
          </div>
        )}
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex items-center gap-2 p-1.5 glass-panel !shadow-none rounded-[1.25rem] overflow-x-auto">
        {[
          { id: 'appearance', label: 'Appearance & Personalization', icon: Palette, adminOnly: true },
          { id: 'api', label: 'API Keys & Webhooks', icon: Key, adminOnly: false },
          { id: 'security', label: 'Security & 2FA', icon: ShieldCheck, adminOnly: false },
          { id: 'team', label: 'Team Members & RBAC', icon: Users, adminOnly: false },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 py-3 px-5 text-[11px] uppercase tracking-widest font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-[#8B5CF6]/30 to-[#3B82F6]/30 text-white border border-[#8B5CF6]/40 shadow-[0_0_20px_rgba(139,92,246,0.25)]'
                  : 'border border-transparent text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.03)]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.adminOnly && (
                <span className="ml-1 px-1.5 py-0.5 rounded text-[9px] bg-[#8B5CF6]/20 text-[#D8B4FE] border border-[#8B5CF6]/30">
                  ADMIN
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Tab 1: Appearance & Personalization */}
      {activeTab === 'appearance' && (
        userRole !== 'admin' ? (
          /* RBAC Access Denied for Non-Admins */
          <div className="glass-card p-12 rounded-[2.5rem] border border-[#F43F5E]/30 bg-[rgba(10,13,22,0.85)] text-center max-w-xl mx-auto my-8 space-y-4">
            <Lock className="w-12 h-12 text-[#F43F5E] mx-auto" />
            <h3 className="text-xl font-bold text-white">403 Forbidden Access</h3>
            <p className="text-xs text-[#A1A1AA]">
              Only Super Administrators and Root Administrators have authorization to modify panel appearance, CSS variables, and global themes.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Sub-Navigation Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-[rgba(0,0,0,0.4)] border border-[rgba(255,255,255,0.05)] rounded-2xl overflow-x-auto">
              {[
                { id: 'brand', label: 'Brand & Logo System', icon: Sparkles },
                { id: 'colors', label: 'Theme Colors', icon: Palette },
                { id: 'glow', label: 'Glow Effects', icon: Sparkles },
                { id: 'background', label: 'Backgrounds', icon: Image },
                { id: 'typography', label: 'Typography', icon: Type },
                { id: 'ambient', label: 'Ambient Effects', icon: Wind },
                { id: 'animation', label: 'Animations', icon: Zap },
                { id: 'layout', label: 'Panel Layout', icon: Layout },
                { id: 'management', label: 'Theme Presets & Export', icon: Save },
              ].map((sub) => {
                const Icon = sub.icon;
                const isSelected = appearanceSubTab === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setAppearanceSubTab(sub.id as any)}
                    className={`flex items-center gap-2 py-2.5 px-4 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-[#8B5CF6] text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]'
                        : 'text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </div>

            {/* SUB TAB: BRAND & LOGO SYSTEM */}
            {appearanceSubTab === 'brand' && <BrandSystemView />}

            {/* LIVE PREVIEW BANNER (For Theme Colors / Glow / Backgrounds) */}
            {appearanceSubTab !== 'brand' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-4 shadow-2xl relative overflow-hidden border border-[#8B5CF6]/30">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 font-mono">
                  <Eye className="w-4 h-4 text-[#22D3EE]" /> Real-Time Live Component Preview
                </h3>
                <span className="text-[10px] font-mono text-[#22D3EE] bg-[#22D3EE]/10 px-2.5 py-0.5 rounded-full border border-[#22D3EE]/20 uppercase">
                  Instant Feedback Active
                </span>
              </div>

              {/* Preview Canvas */}
              <div 
                className="p-6 rounded-2xl border border-[rgba(255,255,255,0.08)] space-y-4 transition-all duration-300"
                style={{
                  backgroundColor: theme.cardColor,
                  borderColor: theme.borderColor,
                  borderRadius: `${theme.borderRadius}px`
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="text-base font-bold text-white flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: theme.primaryColor }} />
                      Hypervisor Node Cluster 01
                    </div>
                    <div className="text-xs text-[#A1A1AA]">Active instance preview with custom styling</div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      className="px-4 py-2 text-xs font-bold text-white rounded-xl transition-all shadow-lg cursor-pointer"
                      style={{
                        backgroundColor: theme.primaryColor,
                        boxShadow: theme.enableGlow && theme.glowTargets.buttons ? `0 0 ${theme.glowBlur}px ${theme.primaryColor}80` : 'none'
                      }}
                    >
                      Primary Button
                    </button>
                    <button 
                      className="px-4 py-2 text-xs font-bold text-white rounded-xl transition-all border border-white/10 cursor-pointer"
                      style={{
                        backgroundColor: theme.secondaryColor
                      }}
                    >
                      Secondary
                    </button>
                  </div>
                </div>

                {/* Sample Progress Bars */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-[#A1A1AA]">CPU Allocation</span>
                      <span style={{ color: theme.accentColor }}>68.4%</span>
                    </div>
                    <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden p-0.5">
                      <div 
                        className="h-full rounded-full transition-all duration-500" 
                        style={{ 
                          width: '68%', 
                          backgroundColor: theme.accentColor,
                          boxShadow: theme.enableGlow && theme.glowTargets.progressBars ? `0 0 10px ${theme.accentColor}` : 'none' 
                        }} 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-[#A1A1AA]">Memory Usage</span>
                      <span style={{ color: theme.successColor }}>42.1%</span>
                    </div>
                    <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden p-0.5">
                      <div 
                        className="h-full rounded-full transition-all duration-500" 
                        style={{ 
                          width: '42%', 
                          backgroundColor: theme.successColor,
                          boxShadow: theme.enableGlow && theme.glowTargets.progressBars ? `0 0 10px ${theme.successColor}` : 'none' 
                        }} 
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            )}

            {/* SUB TAB 1: THEME COLORS */}
            {appearanceSubTab === 'colors' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Palette className="w-5 h-5 text-[#8B5CF6]" />
                  Full Color Palette Controls
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    { key: 'primaryColor', label: 'Primary Brand Color' },
                    { key: 'secondaryColor', label: 'Secondary Accent' },
                    { key: 'accentColor', label: 'Cyber Accent' },
                    { key: 'glowColor', label: 'Glow Aura Color' },
                    { key: 'borderColor', label: 'Border Color' },
                    { key: 'successColor', label: 'Success Status Color' },
                    { key: 'warningColor', label: 'Warning Status Color' },
                    { key: 'dangerColor', label: 'Error / Danger Color' },
                    { key: 'sidebarColor', label: 'Sidebar Background' },
                    { key: 'cardColor', label: 'Card / Panel Color' },
                    { key: 'topNavColor', label: 'Top Navigation Color' },
                    { key: 'bgColor', label: 'Main Background Color' },
                    { key: 'textColor', label: 'Main Text Color' },
                  ].map((item) => {
                    const colorVal = (theme as any)[item.key] || '#8B5CF6';
                    return (
                      <div key={item.key} className="p-4 bg-[rgba(0,0,0,0.4)] border border-[rgba(255,255,255,0.06)] rounded-2xl space-y-3">
                        <div className="flex justify-between items-center text-xs font-bold text-[#A1A1AA]">
                          <span>{item.label}</span>
                          <span className="font-mono text-white text-[11px] uppercase">{colorVal}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <input
                            type="color"
                            value={colorVal.startsWith('#') ? colorVal : '#8B5CF6'}
                            onChange={(e) => updateTheme({ [item.key]: e.target.value })}
                            className="w-10 h-10 rounded-xl cursor-pointer bg-transparent border-0 p-0"
                          />
                          <div className="flex gap-1.5 flex-wrap">
                            {presetSwatches.slice(0, 5).map(s => (
                              <button
                                key={s.value}
                                onClick={() => updateTheme({ [item.key]: s.value })}
                                className="w-5 h-5 rounded-md border border-white/20 transition-transform hover:scale-110 cursor-pointer"
                                style={{ backgroundColor: s.value }}
                                title={s.label}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* SUB TAB 2: GLOW EFFECTS */}
            {appearanceSubTab === 'glow' && (
              <div className="space-y-6">
                <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-[#22D3EE]" />
                        Glow Intensity & Dynamics
                      </h3>
                      <p className="text-xs text-[#A1A1AA] mt-1">Configure global neon aura glows and target applications</p>
                    </div>

                    <button
                      onClick={() => updateTheme({ enableGlow: !theme.enableGlow })}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                        theme.enableGlow 
                          ? 'bg-[#10B981]/20 text-[#34D399] border-[#10B981]/40 shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                          : 'bg-white/5 text-[#A1A1AA] border-white/10'
                      }`}
                    >
                      {theme.enableGlow ? 'Glow Enabled' : 'Glow Disabled'}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Glow Intensity Slider */}
                    <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                      <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                        <span>Glow Intensity</span>
                        <span className="font-mono text-[#22D3EE]">{theme.glowIntensity}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={theme.glowIntensity}
                        onChange={(e) => updateTheme({ glowIntensity: Number(e.target.value) })}
                        className="w-full h-2 bg-white/10 accent-[#22D3EE] rounded-lg cursor-pointer"
                      />
                    </div>

                    {/* Glow Blur Slider */}
                    <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                      <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                        <span>Glow Blur Amount</span>
                        <span className="font-mono text-[#8B5CF6]">{theme.glowBlur}px</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={theme.glowBlur}
                        onChange={(e) => updateTheme({ glowBlur: Number(e.target.value) })}
                        className="w-full h-2 bg-white/10 accent-[#8B5CF6] rounded-lg cursor-pointer"
                      />
                    </div>

                    {/* Glow Opacity Slider */}
                    <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                      <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                        <span>Glow Opacity</span>
                        <span className="font-mono text-[#F43F5E]">{theme.glowOpacity}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={theme.glowOpacity}
                        onChange={(e) => updateTheme({ glowOpacity: Number(e.target.value) })}
                        className="w-full h-2 bg-white/10 accent-[#F43F5E] rounded-lg cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Glow Target Checkboxes */}
                  <div className="space-y-4 pt-4 border-t border-white/5">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Apply Glow Effects To:</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {glowTargetKeys.map((item) => {
                        const isChecked = theme.glowTargets[item.key];
                        return (
                          <label
                            key={item.key}
                            className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-medium cursor-pointer transition-all ${
                              isChecked
                                ? 'bg-[#8B5CF6]/10 border-[#8B5CF6]/40 text-white'
                                : 'bg-black/30 border-white/5 text-[#A1A1AA] hover:text-white'
                            }`}
                          >
                            <span>{item.label}</span>
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) =>
                                updateTheme({
                                  glowTargets: { ...theme.glowTargets, [item.key]: e.target.checked }
                                })
                              }
                              className="w-4 h-4 accent-[#8B5CF6] rounded cursor-pointer"
                            />
                          </label>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SUB TAB 3: BACKGROUND CUSTOMIZATION */}
            {appearanceSubTab === 'background' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Image className="w-5 h-5 text-[#3B82F6]" />
                  Background & Wallpaper Engine
                </h3>

                {/* Style Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {backgroundStyles.map((style) => {
                    const Icon = style.icon;
                    const isSelected = theme.bgStyle === style.id;
                    return (
                      <button
                        key={style.id}
                        onClick={() => updateTheme({ bgStyle: style.id as any })}
                        className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                          isSelected
                            ? 'bg-gradient-to-br from-[#8B5CF6]/20 to-[#3B82F6]/20 border-[#8B5CF6] text-white shadow-[0_0_20px_rgba(139,92,246,0.3)]'
                            : 'bg-black/40 border-white/5 text-[#A1A1AA] hover:text-white hover:border-white/20'
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${isSelected ? 'text-[#8B5CF6]' : 'text-[#71717A]'}`} />
                        <span className="text-xs font-bold">{style.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Custom Background Image URL Section */}
                {theme.bgStyle === 'customImage' && (
                  <div className="p-6 bg-black/50 border border-[#8B5CF6]/30 rounded-2xl space-y-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-white uppercase tracking-wider">
                        Direct Background Image URL
                      </label>
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=2000&q=80"
                        value={theme.customBgImage}
                        onChange={(e) => updateTheme({ customBgImage: e.target.value })}
                        className="w-full px-4 py-3 bg-black/60 border border-white/10 rounded-xl text-xs text-white placeholder-[#71717A] focus:outline-none focus:border-[#8B5CF6]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {/* Display Mode */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-[#A1A1AA]">Display Mode</label>
                        <select
                          value={theme.bgImageDisplay}
                          onChange={(e) => updateTheme({ bgImageDisplay: e.target.value as any })}
                          className="w-full bg-black/60 border border-white/10 text-white text-xs rounded-xl px-3 py-2 outline-none"
                        >
                          <option value="cover">Cover</option>
                          <option value="contain">Contain</option>
                          <option value="stretch">Stretch</option>
                        </select>
                      </div>

                      {/* Position */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-[#A1A1AA]">Position</label>
                        <select
                          value={theme.bgImagePosition}
                          onChange={(e) => updateTheme({ bgImagePosition: e.target.value as any })}
                          className="w-full bg-black/60 border border-white/10 text-white text-xs rounded-xl px-3 py-2 outline-none"
                        >
                          <option value="center">Center</option>
                          <option value="top">Top</option>
                          <option value="bottom">Bottom</option>
                        </select>
                      </div>

                      {/* Blur Amount */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                          <span>Blur</span>
                          <span className="font-mono text-white">{theme.bgImageBlur}px</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="50"
                          value={theme.bgImageBlur}
                          onChange={(e) => updateTheme({ bgImageBlur: Number(e.target.value) })}
                          className="w-full h-2 bg-white/10 accent-[#8B5CF6] rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Brightness */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                          <span>Brightness</span>
                          <span className="font-mono text-white">{theme.bgImageBrightness}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={theme.bgImageBrightness}
                          onChange={(e) => updateTheme({ bgImageBrightness: Number(e.target.value) })}
                          className="w-full h-2 bg-white/10 accent-[#22D3EE] rounded-lg cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* SUB TAB 4: TYPOGRAPHY */}
            {appearanceSubTab === 'typography' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Type className="w-5 h-5 text-[#10B981]" />
                  Global Typography Customization
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {fonts.map((f) => {
                    const isSelected = theme.fontFamily === f;
                    return (
                      <button
                        key={f}
                        onClick={() => updateTheme({ fontFamily: f as any })}
                        className={`p-5 rounded-2xl border text-left transition-all cursor-pointer space-y-1 ${
                          isSelected
                            ? 'bg-[#10B981]/15 border-[#10B981] text-white shadow-[0_0_20px_rgba(16,185,129,0.25)]'
                            : 'bg-black/40 border-white/5 text-[#A1A1AA] hover:text-white hover:border-white/20'
                        }`}
                      >
                        <div className="text-base font-bold" style={{ fontFamily: f }}>
                          {f}
                        </div>
                        <div className="text-[10px] text-[#A1A1AA] font-mono">
                          Aa Bb Cc 123 • Sample Display Font
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-white/5">
                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Font Size Scale</span>
                      <span className="font-mono text-[#10B981]">{theme.fontSizeScale}%</span>
                    </div>
                    <input
                      type="range"
                      min="80"
                      max="120"
                      value={theme.fontSizeScale}
                      onChange={(e) => updateTheme({ fontSizeScale: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#10B981] rounded-lg cursor-pointer"
                    />
                  </div>

                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Card Border Radius</span>
                      <span className="font-mono text-[#3B82F6]">{theme.borderRadius}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="36"
                      value={theme.borderRadius}
                      onChange={(e) => updateTheme({ borderRadius: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#3B82F6] rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SUB TAB 5: AMBIENT EFFECTS */}
            {appearanceSubTab === 'ambient' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Wind className="w-5 h-5 text-[#C084FC]" />
                  Ambient Atmospheric Effects
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { id: 'aurora', label: 'Aurora Mesh Blobs' },
                    { id: 'floatingParticles', label: 'Floating Particles' },
                    { id: 'neonLines', label: 'Neon Circuit Paths' },
                    { id: 'circuitNetwork', label: 'Circuit Network Grid' },
                    { id: 'dataFlow', label: 'Data Flow Animation' },
                    { id: 'lightOrbs', label: 'Floating Light Orbs' },
                    { id: 'cursorGlow', label: 'Cursor Interactive Glow' },
                    { id: 'mouseParallax', label: 'Mouse Parallax Depth' },
                    { id: 'glassReflections', label: 'Glass Reflections' },
                    { id: 'fog', label: 'Cyber Fog Layer' },
                    { id: 'noiseTexture', label: 'Film Noise Texture' },
                    { id: 'lightRays', label: 'Top Light Rays' },
                  ].map((eff) => {
                    const active = (theme.ambientEffects as any)?.[eff.id]?.enabled ?? true;
                    return (
                      <div key={eff.id} className="p-4 bg-black/40 border border-white/5 rounded-2xl flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{eff.label}</span>
                        <button
                          onClick={() => {
                            const prevEff = (theme.ambientEffects as any)?.[eff.id] || { enabled: true, intensity: 50 };
                            updateTheme({
                              ambientEffects: {
                                ...theme.ambientEffects,
                                [eff.id]: { ...prevEff, enabled: !prevEff.enabled }
                              }
                            });
                          }}
                          className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                            active ? 'bg-[#8B5CF6]' : 'bg-gray-700'
                          }`}
                        >
                          <div className={`w-5 h-5 rounded-full bg-white transition-transform ${active ? 'translate-x-5' : 'translate-x-0'}`} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* SUB TAB 6: ANIMATIONS */}
            {appearanceSubTab === 'animation' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Zap className="w-5 h-5 text-[#F59E0B]" />
                  Animation & Transition Speeds
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Background Animation Speed */}
                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Background Animation Speed</span>
                      <span className="font-mono text-[#F59E0B]">{theme.bgAnimationSpeed}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.2"
                      max="3.0"
                      step="0.1"
                      value={theme.bgAnimationSpeed}
                      onChange={(e) => updateTheme({ bgAnimationSpeed: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#F59E0B] rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Transition Speed */}
                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Page Transition Speed</span>
                      <span className="font-mono text-[#3B82F6]">{theme.transitionSpeed}s</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="1.0"
                      step="0.05"
                      value={theme.transitionSpeed}
                      onChange={(e) => updateTheme({ transitionSpeed: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#3B82F6] rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SUB TAB 7: PANEL LAYOUT */}
            {appearanceSubTab === 'layout' && (
              <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                  <Layout className="w-5 h-5 text-[#3B82F6]" />
                  Panel Dimensions & Layout Density
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Sidebar Width */}
                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Sidebar Navigation Width</span>
                      <span className="font-mono text-[#3B82F6]">{theme.sidebarWidth}px</span>
                    </div>
                    <input
                      type="range"
                      min="220"
                      max="320"
                      value={theme.sidebarWidth}
                      onChange={(e) => updateTheme({ sidebarWidth: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#3B82F6] rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Glass Blur Strength */}
                  <div className="space-y-2 p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="flex justify-between text-xs font-bold text-[#A1A1AA]">
                      <span>Glassmorphism Blur Strength</span>
                      <span className="font-mono text-[#8B5CF6]">{theme.glassBlurAmount}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="40"
                      value={theme.glassBlurAmount}
                      onChange={(e) => updateTheme({ glassBlurAmount: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 accent-[#8B5CF6] rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SUB TAB 8: THEME MANAGEMENT & EXPORT */}
            {appearanceSubTab === 'management' && (
              <div className="space-y-6">
                <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-6 shadow-xl">
                  <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                    <Save className="w-5 h-5 text-[#10B981]" />
                    Preset Themes & Custom JSON Management
                  </h3>

                  {/* Save Custom Theme */}
                  <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex flex-col sm:flex-row items-center gap-3">
                    <input
                      type="text"
                      placeholder="Custom Theme Name (e.g. Cyberpunk Blue)"
                      value={newThemeName}
                      onChange={(e) => setNewThemeName(e.target.value)}
                      className="flex-1 px-4 py-2.5 bg-black/60 border border-white/10 rounded-xl text-xs text-white placeholder-[#71717A] focus:outline-none"
                    />
                    <button
                      onClick={() => {
                        saveCustomTheme(newThemeName);
                        setNewThemeName('');
                      }}
                      className="px-5 py-2.5 bg-[#10B981] hover:bg-[#059669] text-white text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap"
                    >
                      Save Theme Preset
                    </button>
                  </div>

                  {/* Presets Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                    {Object.entries(PRESET_THEMES).map(([key, item]) => (
                      <button
                        key={key}
                        onClick={() => applyPreset(key)}
                        className="p-4 bg-black/40 hover:bg-white/5 border border-white/10 hover:border-[#8B5CF6]/50 rounded-2xl text-left transition-all cursor-pointer space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-xs">{item.name}</span>
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.config.primaryColor }} />
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.config.secondaryColor }} />
                          </div>
                        </div>
                      </button>
                    ))}

                    {Object.entries(savedThemes).map(([key, item]) => (
                      <div
                        key={key}
                        className="p-4 bg-[#8B5CF6]/10 border border-[#8B5CF6]/30 rounded-2xl flex items-center justify-between text-xs"
                      >
                        <span className="font-bold text-white truncate">{key}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => applyPreset(key)}
                            className="px-2.5 py-1 bg-[#8B5CF6] text-white text-[10px] font-bold rounded-lg cursor-pointer"
                          >
                            Apply
                          </button>
                          <button
                            onClick={() => deleteCustomTheme(key)}
                            className="text-[#71717A] hover:text-[#F43F5E] p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Export & Import JSON */}
                  <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-white/5">
                    <button
                      onClick={() => {
                        const jsonStr = exportThemeJSON();
                        navigator.clipboard.writeText(jsonStr);
                        setCopiedExport(true);
                        setTimeout(() => setCopiedExport(false), 2000);
                      }}
                      className="flex items-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white text-xs font-bold rounded-xl border border-white/10 transition-all cursor-pointer"
                    >
                      {copiedExport ? <CopyCheck className="w-4 h-4 text-[#10B981]" /> : <Download className="w-4 h-4" />}
                      <span>{copiedExport ? 'Theme JSON Copied!' : 'Export Theme JSON'}</span>
                    </button>

                    <button
                      onClick={() => setShowImportModal(true)}
                      className="flex items-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white text-xs font-bold rounded-xl border border-white/10 transition-all cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Import Theme JSON</span>
                    </button>
                  </div>
                </div>

                {/* Scheduled Switching Section */}
                <div className="glass-card rounded-[2rem] p-6 lg:p-8 space-y-4 shadow-xl border border-white/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <Clock className="w-4 h-4 text-[#22D3EE]" /> Scheduled Day/Night Theme Switching
                      </h4>
                      <p className="text-xs text-[#A1A1AA]">Automatically transition presets based on server local time</p>
                    </div>

                    <button
                      onClick={() =>
                        updateTheme({
                          scheduledSwitching: {
                            ...theme.scheduledSwitching,
                            enabled: !theme.scheduledSwitching?.enabled
                          }
                        })
                      }
                      className={`w-12 h-6 rounded-full p-1 transition-colors cursor-pointer ${
                        theme.scheduledSwitching?.enabled ? 'bg-[#22D3EE]' : 'bg-gray-700'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-white transition-transform ${theme.scheduledSwitching?.enabled ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      )}

      {/* Main Tab 2: API Keys */}
      {activeTab === 'api' && (
        <div className="space-y-6">
          <div className="glass-card rounded-[1.5rem] p-6 lg:p-8 space-y-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white tracking-wide">Active API Tokens</h3>
                <p className="text-xs text-[#A1A1AA] mt-1 font-medium tracking-wide font-sans">Use these secret keys to manage VMs programmatically</p>
              </div>
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center gap-2.5 px-5 py-2.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] text-white font-bold text-xs rounded-xl shadow-lg border border-white/10 cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" /> <span className="tracking-wide">Generate New Key</span>
              </motion.button>
            </div>

            <div className="space-y-3 pt-2">
              {apiKeys.map((k) => (
                <div
                  key={k.id}
                  className="p-5 bg-black/50 border border-white/5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-mono shadow-inner hover:border-[#8B5CF6]/30 transition-colors"
                >
                  <div>
                    <span className="font-bold text-white font-sans text-sm tracking-wide">{k.name}</span>
                    <div className="text-[#A1A1AA] text-[11px] mt-1.5">{k.token}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyToken(k.token)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-[#E4E4E7] rounded-xl text-[11px] font-mono transition-colors cursor-pointer"
                    >
                      {copiedKey === k.token ? <Check className="w-3.5 h-3.5 text-[#10B981]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy</span>
                    </button>
                    <button className="p-1.5 text-[#71717A] hover:text-[#F43F5E] transition-colors cursor-pointer">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Tab 3: Security */}
      {activeTab === 'security' && (
        <div className="glass-card rounded-[1.5rem] p-6 space-y-4 shadow-xl">
          <h3 className="text-sm font-bold text-white">Two-Factor Authentication (TOTP)</h3>
          <p className="text-xs text-[#A1A1AA]">
            DVM Panel requires mandatory 2FA security for administrator root accounts.
          </p>
          <div className="flex items-center gap-3 p-4 bg-[#10B981]/10 border border-[#10B981]/20 rounded-2xl text-[#10B981] text-xs font-mono">
            <ShieldCheck className="w-5 h-5 shrink-0" />
            <span>2FA Authenticator App is ACTIVE for {CURRENT_USER.email}</span>
          </div>
        </div>
      )}

      {/* Main Tab 4: Team Members */}
      {activeTab === 'team' && (
        <div className="glass-card rounded-[1.5rem] p-6 space-y-4 shadow-xl">
          <h3 className="text-sm font-bold text-white">Team Members & RBAC Roles</h3>
          <div className="p-4 bg-black/60 border border-white/5 rounded-2xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <img src={CURRENT_USER.avatarUrl} className="w-9 h-9 rounded-xl object-cover" alt="User" />
              <div>
                <div className="font-bold text-white">{CURRENT_USER.name}</div>
                <div className="text-[#A1A1AA] font-mono">{CURRENT_USER.email}</div>
              </div>
            </div>
            <span className="font-mono font-bold text-[#C084FC] bg-[#8B5CF6]/10 px-2.5 py-1 rounded-full border border-[#8B5CF6]/20">
              {CURRENT_USER.role}
            </span>
          </div>
        </div>
      )}

      {/* JSON Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-panel p-6 rounded-3xl max-w-lg w-full space-y-4 border border-white/10"
            >
              <h3 className="text-base font-bold text-white">Import Custom Theme JSON</h3>
              <p className="text-xs text-[#A1A1AA]">Paste exported Theme JSON configuration below:</p>
              <textarea
                rows={8}
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                placeholder='{\n  "primaryColor": "#8B5CF6",\n  "glowIntensity": 85\n}'
                className="w-full p-3 bg-black/60 border border-white/10 rounded-xl text-xs font-mono text-white placeholder-[#71717A] focus:outline-none"
              />
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="px-4 py-2 text-xs font-bold text-[#A1A1AA] hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (importThemeJSON(importJsonText)) {
                      setShowImportModal(false);
                      setImportJsonText('');
                    } else {
                      alert('Invalid JSON schema');
                    }
                  }}
                  className="px-5 py-2 bg-[#8B5CF6] hover:bg-[#A855F7] text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Apply Imported Theme
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

