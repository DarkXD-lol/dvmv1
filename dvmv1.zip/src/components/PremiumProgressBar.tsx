import React from 'react';
import { motion } from 'motion/react';

interface PremiumProgressBarProps {
  value: number; // 0 to 100
  label?: string;
  showValue?: boolean;
  className?: string;
}

export const PremiumProgressBar: React.FC<PremiumProgressBarProps> = ({ value, label, showValue = true, className = '' }) => {
  const safeValue = Math.min(Math.max(value, 0), 100);
  
  let gradientClass = 'from-[#A855F7] to-[#3B82F6]'; // 0-50%
  let shadowClass = 'rgba(168,85,247,0.5)';
  
  if (safeValue > 50 && safeValue <= 80) {
    gradientClass = 'from-[#A855F7] to-[#06B6D4]'; // 50-80%
    shadowClass = 'rgba(6,182,212,0.5)';
  } else if (safeValue > 80 && safeValue <= 90) {
    gradientClass = 'from-[#F59E0B] to-[#EF4444]'; // 80-90% warning
    shadowClass = 'rgba(245,158,11,0.5)';
  } else if (safeValue > 90) {
    gradientClass = 'from-[#EF4444] to-[#B91C1C]'; // >90% danger
    shadowClass = 'rgba(239,68,68,0.5)';
  }

  const isDanger = safeValue > 90;

  return (
    <div className={`w-full ${className}`}>
      {(label || showValue) && (
        <div className="flex items-center justify-between mb-1.5 text-xs">
          {label && <span className="text-[#A1A1AA] font-medium">{label}</span>}
          {showValue && (
            <span className={`font-bold ${isDanger ? 'text-red-400 animate-pulse' : 'text-white'}`}>
              {Math.round(safeValue)}%
            </span>
          )}
        </div>
      )}
      <div className="h-2 w-full bg-[rgba(255,255,255,0.05)] rounded-full overflow-hidden border border-[rgba(255,255,255,0.02)] backdrop-blur-sm relative">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${safeValue}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className={`absolute top-0 left-0 h-full bg-gradient-to-r ${gradientClass} rounded-full`}
          style={{ boxShadow: `0 0 10px ${shadowClass}` }}
        >
          {/* Animated Shine Effect */}
          <motion.div
            initial={{ x: '-100%', opacity: 0 }}
            animate={{ x: '100%', opacity: [0, 0.5, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut', delay: 0.5 }}
            className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white to-transparent opacity-30 skew-x-[-20deg]"
          />
        </motion.div>
        {isDanger && (
           <div className="absolute inset-0 bg-red-500/20 animate-pulse" />
        )}
      </div>
    </div>
  );
};
