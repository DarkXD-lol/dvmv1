import React, { useState, useEffect, useRef } from 'react';
import { X, Terminal, Maximize2, Minimize2, Copy, RefreshCw, Power, Zap, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VMInstance } from '../types';

interface WebConsoleModalProps {
  vm: VMInstance | null;
  onClose: () => void;
}

export const WebConsoleModal: React.FC<WebConsoleModalProps> = ({ vm, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (vm) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [vm, onClose]);

  if (!vm) return null;

  const [lines, setLines] = useState<string[]>([
    `[DVM-VNC-SERIAL] Establishing secure TLS tunnel to ${vm.node} (${vm.ipAddress}:5901)...`,
    `[DVM-VNC-SERIAL] Connected to KVM QEMU guest domain ${vm.vmid} (${vm.name})`,
    `Ubuntu 24.04 LTS ${vm.name} tty1`,
    ``,
    `${vm.name} login: root (automatic SSH key authenticated)`,
    `Last login: ${vm.createdTime} from 10.100.0.1`,
    `Welcome to DVM Cloud Linux Engine!`,
    `Type 'help' or 'top' or 'ip a' or 'systemctl status'.`,
  ]);

  const [inputVal, setInputVal] = useState('');
  const [fullscreen, setFullscreen] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputVal.trim();
    if (!cmd) return;

    const newLines = [...lines, `root@${vm.name}:~# ${cmd}`];

    if (cmd === 'clear') {
      setLines([`root@${vm.name}:~# `]);
      setInputVal('');
      return;
    }

    if (cmd === 'help') {
      newLines.push(
        `Available DVM Agent CLI commands:`,
        `  ip a             - Show network interfaces & assigned IP`,
        `  top / htop       - View live CPU and Memory usage`,
        `  systemctl status - Show active services`,
        `  uname -a         - Print system kernel version`,
        `  reboot           - Reboot virtual machine`,
        `  clear            - Clear terminal screen`
      );
    } else if (cmd === 'ip a' || cmd === 'ifconfig') {
      newLines.push(
        `1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN`,
        `    inet 127.0.0.1/8 scope host lo`,
        `2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP`,
        `    inet ${vm.ipAddress}/24 brd 192.168.10.255 scope global eth0`,
        `    inet6 ${vm.ipv6Address || '2001:db8::1'}/64 scope global`
      );
    } else if (cmd === 'top' || cmd === 'htop') {
      newLines.push(
        `top - 05:44:23 up 14 days,  2:10,  1 user,  load average: 0.18, 0.12, 0.08`,
        `Tasks: 124 total,   1 running, 123 sleeping,   0 stopped,   0 zombie`,
        `%Cpu(s):  ${vm.cpuUsagePct}% us,  1.2% sy,  0.0% ni, 95.8% id,  0.0% wa`,
        `MiB Mem :  ${vm.ramGB * 1024} total,   ${Math.round((vm.ramGB * 1024 * vm.ramUsagePct) / 100)} used,   ${Math.round((vm.ramGB * 1024 * (100 - vm.ramUsagePct)) / 100)} free`,
        `  PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND`,
        ` 1204 root      20   0 1482012 342100  48212 S   4.2   5.8  18:24.12 node`,
        ` 2891 postgres  20   0 2841022 841022 120482 S   2.8  12.4  42:18.04 postgres`
      );
    } else if (cmd === 'uname -a') {
      newLines.push(`Linux ${vm.name} 6.8.0-31-generic #31-Ubuntu SMP PREEMPT_DYNAMIC x86_64 x86_64 GNU/Linux`);
    } else {
      newLines.push(`Command executed: ${cmd}`);
    }

    setLines(newLines);
    setInputVal('');
  };

  const executeShortcut = (cmd: string) => {
    setInputVal(cmd);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xl overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className={`glass-card shadow-[0_30px_60px_-15px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden relative transition-all duration-300 ${
            fullscreen ? 'fixed inset-4 rounded-[2.5rem]' : 'rounded-[2.5rem] w-full max-w-5xl h-[85vh] my-auto'
          }`}
        >
          {/* Subtle gradient glow behind modal header */}
          <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-[#8B5CF6]/10 via-[#22D3EE]/10 to-transparent pointer-events-none" />

          {/* Console Header */}
          <div className="p-6 border-b border-[rgba(255,255,255,0.05)] flex items-center justify-between relative z-10 bg-[rgba(0,0,0,0.4)] shadow-inner">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8B5CF6]/20 to-[#22D3EE]/20 border border-[#8B5CF6]/30 flex items-center justify-center text-[#22D3EE] shrink-0 shadow-[0_0_15px_rgba(139,92,246,0.2)]">
                <Terminal className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <span className="font-black text-xl text-white font-sans tracking-wide">{vm.name}</span>
                  <span className="text-[10px] bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 px-3 py-1.5 rounded-full font-sans uppercase tracking-widest font-bold shadow-sm">
                    VNC DIRECT SERIAL
                  </span>
                </div>
                <span className="text-sm text-[#A1A1AA] font-sans tracking-wide mt-1 block">
                  {vm.ipAddress} &bull; KVM Domain {vm.vmid}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setFullscreen(!fullscreen)}
                className="p-2.5 text-[#A1A1AA] hover:text-white bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] rounded-xl transition-colors"
                title={fullscreen ? 'Restore Window' : 'Fullscreen'}
              >
                {fullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
              <div className="w-px h-6 bg-[rgba(255,255,255,0.1)] mx-1"></div>
              <button onClick={onClose} className="p-2.5 text-[#A1A1AA] hover:text-white bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] rounded-xl transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Shortcuts Bar */}
          <div className="flex items-center gap-2 px-6 py-2 bg-[#050509] border-b border-[rgba(255,255,255,0.05)] font-mono text-xs overflow-x-auto custom-scrollbar relative z-10 shadow-inner">
            <span className="text-[10px] text-[#A1A1AA] font-bold uppercase tracking-widest font-sans mr-2">Quick Macros</span>
            {['help', 'ip a', 'top', 'uname -a', 'clear'].map((sc) => (
              <button
                key={sc}
                onClick={() => executeShortcut(sc)}
                className="px-3 py-1 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#22D3EE] rounded-lg border border-[rgba(255,255,255,0.05)] text-[11px] transition-colors whitespace-nowrap"
              >
                {sc}
              </button>
            ))}
          </div>

          {/* Terminal Body */}
          <div className="p-6 flex-1 bg-[#020305] font-mono text-xs sm:text-sm text-[#D4D4D8] overflow-y-auto space-y-2 selection:bg-[#22D3EE]/30 custom-scrollbar shadow-inner relative z-10">
            {lines.map((line, idx) => (
              <div key={idx} className="whitespace-pre-wrap leading-relaxed font-mono">
                {line.startsWith('root@') ? (
                   <span className="text-[#22D3EE] font-bold">{line.split(' ')[0]} </span>
                ) : null}
                {line.startsWith('root@') ? line.substring(line.indexOf(' ') + 1) : line}
              </div>
            ))}

            {/* Interactive Input Line */}
            <form onSubmit={handleCommand} className="flex items-center gap-2 pt-2 font-mono">
              <span className="text-[#22D3EE] font-bold">root@{vm.name}:~#</span>
              <input
                type="text"
                autoFocus
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="flex-1 bg-transparent text-[#F4F4F5] outline-none font-mono text-sm caret-[#22D3EE]"
                spellCheck={false}
              />
            </form>
            <div ref={terminalEndRef} />
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
