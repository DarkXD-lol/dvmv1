import React, { useState } from 'react';
import { HardDrive, Disc, Upload, CheckCircle2, AlertTriangle, Database, Plus } from 'lucide-react';
import { motion } from 'motion/react';
import { StoragePool } from '../types';
import { INITIAL_STORAGE } from '../data/mockData';
import { VmCardSkeleton } from './DashboardSkeleton';

interface StorageViewProps {
  isLoading?: boolean;
}

export const StorageView: React.FC<StorageViewProps> = ({ isLoading = false }) => {
  const [pools, setPools] = useState<StoragePool[]>(INITIAL_STORAGE);
  const [activeTab, setActiveTab] = useState<'pools' | 'isos'>('pools');

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <VmCardSkeleton count={2} />
      </motion.div>
    );
  }

  const isoImages = [
    { name: 'ubuntu-24.04-live-server-amd64.iso', sizeGB: 2.6, category: 'Linux Server', date: '2026-04-25' },
    { name: 'debian-12.5.0-amd64-netinst.iso', sizeGB: 0.6, category: 'Linux Server', date: '2026-03-10' },
    { name: 'AlmaLinux-9.4-x86_64-dvd.iso', sizeGB: 9.2, category: 'Enterprise Linux', date: '2026-05-15' },
    { name: 'SERVER_EVAL_x64FRE_en-us.iso', sizeGB: 5.4, category: 'Windows Server', date: '2025-11-01' },
    { name: 'archlinux-2026.07.01-x86_64.iso', sizeGB: 1.1, category: 'Arch Linux', date: '2026-07-02' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 glass-panel p-6 lg:p-8 rounded-[2.5rem] shadow-xl">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <HardDrive className="w-6 h-6 text-[#A855F7] drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
            Storage Pools & ISO Vault
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
            ZFS Tank, Ceph Distributed Cluster, NVMe RAID 10, and boot ISO repository
          </p>
        </div>

        <div className="flex items-center p-1.5 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] shadow-inner">
          <button
            onClick={() => setActiveTab('pools')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all font-sans tracking-wide uppercase ${
              activeTab === 'pools'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
            }`}
          >
            Storage Pools ({pools.length})
          </button>
          <button
            onClick={() => setActiveTab('isos')}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all font-sans tracking-wide uppercase ${
              activeTab === 'isos'
                ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
            }`}
          >
            ISO Library ({isoImages.length})
          </button>
        </div>
      </div>

      {activeTab === 'pools' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {pools.map((pool) => {
            const usedPct = Math.round((pool.usedGB / pool.totalGB) * 100);

            return (
              <motion.div
                key={pool.id}
                whileHover={{ y: -4, scale: 1.01 }}
                className="group glass-card rounded-[1.5rem] p-6 flex flex-col justify-between space-y-4 hover:shadow-[0_15px_40px_-10px_rgba(0,0,0,0.5)] transition-all duration-500"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[rgba(255,255,255,0.03)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                <div className="flex items-start justify-between relative z-10">
                  <div>
                    <h3 className="font-black text-lg text-white tracking-wide">{pool.name}</h3>
                    <div className="text-xs text-[#A1A1AA] mt-2 font-mono">
                      Type: <span className="text-[#C084FC] uppercase font-bold">{pool.type}</span> <span className="text-[rgba(255,255,255,0.2)] mx-1">•</span> {pool.node}
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold font-sans uppercase tracking-widest px-3 py-1.5 rounded-full border shadow-sm ${
                      pool.health === 'HEALTH_OK'
                        ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                        : 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20 shadow-[0_0_8px_rgba(245,158,11,0.2)]'
                    }`}
                  >
                    {pool.health}
                  </span>
                </div>

                {/* Storage Progress Meter */}
                <div className="space-y-3 pt-3 border-t border-[rgba(255,255,255,0.05)] relative z-10">
                  <div className="flex justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA]">
                    <span>Total Capacity Utilization</span>
                    <span className="text-[#C084FC]">
                      {(pool.usedGB / 1024).toFixed(1)} / {(pool.totalGB / 1024).toFixed(1)} TB ({usedPct}%)
                    </span>
                  </div>
                  <div className="w-full bg-[rgba(0,0,0,0.4)] h-1.5 rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
                    <div
                      className="bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] h-full rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)] transition-all duration-500"
                      style={{ width: `${usedPct}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-[#A1A1AA] font-mono">
                    <span>Used: {pool.usedGB} GB</span>
                    <span>Free Available: {pool.freeGB} GB</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="glass-panel rounded-3xl overflow-hidden border border-[rgba(255,255,255,0.1)] shadow-2xl">
          <div className="p-4 bg-[rgba(0,0,0,0.6)] border-b border-[rgba(255,255,255,0.05)] flex justify-between items-center">
            <span className="text-xs font-bold text-[#E4E4E7] font-mono">
              Mounted ISO Installation Repository
            </span>
            <button className="flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs rounded-xl shadow-lg shadow-[#8B5CF6]/20 transition-all">
              <Upload className="w-3.5 h-3.5" /> Upload Custom ISO
            </button>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[rgba(0,0,0,0.4)] text-[#A1A1AA] uppercase font-bold border-b border-[rgba(255,255,255,0.05)]">
              <tr>
                <th className="p-4">ISO File Name</th>
                <th className="p-4">Category</th>
                <th className="p-4">Size</th>
                <th className="p-4">Uploaded Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(255,255,255,0.05)] text-[#E4E4E7]">
              {isoImages.map((iso) => (
                <tr key={iso.name} className="hover:bg-[rgba(255,255,255,0.03)] transition-colors">
                  <td className="p-4 font-bold text-[#D8B4FE] flex items-center gap-2">
                    <Disc className="w-4 h-4 text-[#A855F7] shrink-0" />
                    <span>{iso.name}</span>
                  </td>
                  <td className="p-4 text-[#A1A1AA]">{iso.category}</td>
                  <td className="p-4 font-bold">{iso.sizeGB} GB</td>
                  <td className="p-4 text-[#A1A1AA]">{iso.date}</td>
                  <td className="p-4 text-right">
                    <button className="px-3 py-1 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-white rounded-lg text-[11px] font-semibold transition-colors">
                      Mount to VM
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
