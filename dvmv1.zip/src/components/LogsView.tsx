import React, { useState } from 'react';
import { Activity, ShieldAlert, CheckCircle2, AlertTriangle, Terminal, Search, Filter } from 'lucide-react';
import { motion } from 'motion/react';
import { ActivityLog } from '../types';
import { LogsListSkeleton } from './DashboardSkeleton';

interface LogsViewProps {
  logs: ActivityLog[];
  isLoading?: boolean;
}

export const LogsView: React.FC<LogsViewProps> = ({ logs, isLoading = false }) => {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'success' | 'warning' | 'failed'>('all');

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <LogsListSkeleton rows={8} />
      </motion.div>
    );
  }

  const filteredLogs = logs.filter((log) => {
    const q = (search || '').toLowerCase();
    const matchesSearch =
      !q ||
      (log.user || '').toLowerCase().includes(q) ||
      (log.action || '').toLowerCase().includes(q) ||
      (log.target || '').toLowerCase().includes(q) ||
      (log.ipAddress || '').includes(q);

    const matchesStatus = filterStatus === 'all' || log.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 glass-panel p-6 lg:p-8 rounded-[2.5rem] shadow-xl">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <Activity className="w-6 h-6 text-[#A855F7] drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
            System Audit Trail
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
            Immutable security event ledger tracking user actions, VM power states, and agent operations
          </p>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search logs..."
              className="w-full sm:w-56 focus:sm:w-72 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] pl-11 pr-4 py-3 text-sm text-white placeholder-[#71717A] font-sans tracking-wide outline-none focus:border-[#A855F7]/50 transition-all shadow-inner"
            />
          </div>

          <div className="flex items-center gap-1.5 p-1.5 bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] w-full sm:w-auto overflow-x-auto shadow-inner">
            {['all', 'success', 'warning', 'failed'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st as any)}
                className={`px-4 py-2.5 text-[11px] font-bold rounded-xl capitalize transition-all font-sans tracking-widest uppercase whitespace-nowrap ${
                  filterStatus === st
                    ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                    : 'text-[#A1A1AA] hover:text-white border border-transparent hover:bg-[rgba(255,255,255,0.03)]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Logs Matrix Table */}
      <div className="glass-panel rounded-[2rem] overflow-hidden shadow-xl">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left text-sm font-sans whitespace-nowrap">
            <thead className="bg-[rgba(0,0,0,0.4)] text-[#A1A1AA] uppercase font-bold tracking-widest text-[11px] border-b border-[rgba(255,255,255,0.05)] shadow-inner">
              <tr>
                <th className="p-5 pl-6 font-bold">Timestamp</th>
                <th className="p-5 font-bold">Identity</th>
                <th className="p-5 font-bold">Action</th>
                <th className="p-5 font-bold">Target</th>
                <th className="p-5 font-bold">Status</th>
                <th className="p-5 pr-6 text-right font-bold">Client IP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(255,255,255,0.02)] text-[#D4D4D8] font-mono">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-[rgba(255,255,255,0.02)] transition-colors group">
                  <td className="p-5 pl-6 text-[#71717A] text-xs">{log.timestamp}</td>
                  <td className="p-5 font-bold text-white font-sans tracking-wide">{log.user}</td>
                  <td className="p-5 font-bold text-[#C084FC] font-sans tracking-wide">{log.action}</td>
                  <td className="p-5 text-[#A1A1AA] text-xs">{log.target}</td>
                  <td className="p-5">
                    <span
                      className={`inline-flex items-center justify-center px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest font-sans shadow-sm ${
                        log.status === 'success'
                          ? 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 shadow-[0_0_8px_rgba(16,185,129,0.15)]'
                          : log.status === 'warning'
                          ? 'bg-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/20 shadow-[0_0_8px_rgba(245,158,11,0.15)]'
                          : 'bg-[#F43F5E]/10 text-[#F43F5E] border border-[#F43F5E]/20 shadow-[0_0_8px_rgba(244,63,94,0.15)]'
                      }`}
                    >
                      {log.status}
                    </span>
                  </td>
                  <td className="p-5 pr-6 text-right text-[#71717A] text-xs">{log.ipAddress}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
