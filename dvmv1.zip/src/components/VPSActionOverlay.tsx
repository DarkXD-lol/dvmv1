import React, { useState, useEffect } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  Server, 
  Play, 
  Square, 
  RotateCw, 
  Trash2, 
  ShieldCheck, 
  Terminal, 
  Key, 
  Camera, 
  HardDrive, 
  RefreshCw, 
  Check, 
  AlertCircle, 
  Zap,
  Lock,
  Cpu,
  X
} from 'lucide-react';
import { PremiumProgressBar } from './PremiumProgressBar';

export type VPSActionType = 
  | 'start' 
  | 'stop' 
  | 'reboot' 
  | 'pause'
  | 'delete' 
  | 'reinstall' 
  | 'rebuild' 
  | 'backup' 
  | 'snapshot' 
  | 'ssh' 
  | 'sshx' 
  | 'password' 
  | 'powercycle'
  | 'mount_iso';

interface VPSActionOverlayProps {
  isOpen: boolean;
  actionType: VPSActionType | null;
  vmName: string;
  vmid?: number | string;
  onClose: () => void;
  onOpenConsole?: () => void;
}

export const VPSActionOverlay: React.FC<VPSActionOverlayProps> = ({
  isOpen,
  actionType,
  vmName,
  vmid,
  onClose,
  onOpenConsole,
}) => {
  const [progress, setProgress] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [isDone, setIsDone] = useState(false);

  // Configuration map per action type
  const getActionConfig = (type: VPSActionType | null) => {
    switch (type) {
      case 'start':
        return {
          title: 'Powering On Instance',
          icon: Play,
          color: 'from-emerald-500 to-teal-400',
          accentColor: '#10B981',
          steps: [
            'Initiating ACPI boot sequence...',
            'Allocating vCPU and DDR5 ECC Memory...',
            'Binding VirtIO Network Bridge vmbr0...',
            'Attaching ZFS Raw Block Storage Volume...',
            'Guest OS Boot Successful. System Online!'
          ]
        };
      case 'stop':
        return {
          title: 'Graceful ACPI Shutdown',
          icon: Square,
          color: 'from-slate-500 to-amber-500',
          accentColor: '#F59E0B',
          steps: [
            'Sending SIGTERM signal to guest kernel...',
            'Flushing file system write buffers...',
            'Unmounting ZFS storage targets...',
            'Releasing vCPU pass-through locks...',
            'Virtual Machine halted cleanly.'
          ]
        };
      case 'reboot':
        return {
          title: 'Hard Cluster Reboot',
          icon: RotateCw,
          color: 'from-purple-500 to-indigo-500',
          accentColor: '#8B5CF6',
          steps: [
            'Issuing kernel restart command...',
            'Cycling virtual firmware state...',
            'Performing PCI passthrough reset...',
            'Booting Linux guest kernel...',
            'Services active & system online.'
          ]
        };
      case 'reinstall':
      case 'rebuild':
        return {
          title: 'Rebuilding OS Image',
          icon: RefreshCw,
          color: 'from-cyan-500 to-blue-600',
          accentColor: '#06B6D4',
          steps: [
            'Wiping existing root partition...',
            'Unpacking target cloud OS image template...',
            'Configuring cloud-init network interfaces...',
            'Generating host SSH keys and root credentials...',
            'Rebuild complete. System ready.'
          ]
        };
      case 'delete':
        return {
          title: 'Destroying Instance',
          icon: Trash2,
          color: 'from-rose-500 to-red-600',
          accentColor: '#EF4444',
          steps: [
            'Terminating hypervisor process...',
            'Purging network bridge allocations...',
            'Destroying ZFS volume Dataset...',
            'Removing firewall rules & DNS records...',
            'Instance destroyed permanently.'
          ]
        };
      case 'backup':
      case 'snapshot':
        return {
          title: 'Creating ZFS Snapshot',
          icon: Camera,
          color: 'from-purple-500 to-pink-500',
          accentColor: '#EC4899',
          steps: [
            'Freezing I/O state for ZFS consistency...',
            'Taking atomic block-level ZFS snapshot...',
            'Calculating delta block checksums...',
            'Compressing snapshot image payload...',
            'Snapshot created and stored in pool.'
          ]
        };
      case 'ssh':
      case 'sshx':
        return {
          title: 'Generating Web SSH Credentials',
          icon: Key,
          color: 'from-indigo-500 to-purple-500',
          accentColor: '#6366F1',
          steps: [
            'Connecting to hypervisor agent websocket...',
            'Generating ED25519 temporary SSH keypair...',
            'Injecting public key into guest cloud-init...',
            'Opening secure encrypted SSH tunnel...',
            'SSH Session ready for terminal access.'
          ]
        };
      case 'password':
        return {
          title: 'Resetting Root Credentials',
          icon: Lock,
          color: 'from-amber-500 to-orange-500',
          accentColor: '#F97316',
          steps: [
            'Mounting guest shadow partition...',
            'Generating 256-bit entropy password...',
            'Updating root user hash in /etc/shadow...',
            'Unmounting guest filesystem...',
            'Root password reset successfully!'
          ]
        };
      default:
        return {
          title: 'Executing Task',
          icon: Zap,
          color: 'from-purple-500 to-blue-500',
          accentColor: '#8B5CF6',
          steps: [
            'Initializing task runner...',
            'Communicating with node agent...',
            'Verifying resource health...',
            'Applying hypervisor state update...',
            'Task completed successfully.'
          ]
        };
    }
  };

  const config = getActionConfig(actionType);
  const ActionIcon = config.icon;

  useEffect(() => {
    if (!isOpen || !actionType) {
      setProgress(0);
      setCurrentStepIndex(0);
      setLogs([]);
      setIsDone(false);
      return;
    }

    setProgress(0);
    setCurrentStepIndex(0);
    setLogs([`[0.0s] Initializing ${config.title.toLowerCase()} on ${vmName}...`]);
    setIsDone(false);

    const totalSteps = config.steps.length;
    let currentStep = 0;

    const interval = setInterval(() => {
      currentStep += 1;
      const nextProgress = Math.min(100, Math.round((currentStep / totalSteps) * 100));
      setProgress(nextProgress);
      setCurrentStepIndex(Math.min(totalSteps - 1, currentStep - 1));

      const timeStamp = (currentStep * 0.4).toFixed(1);
      const stepText = config.steps[currentStep - 1] || 'Finalizing configuration...';
      
      setLogs((prev) => [...prev, `[${timeStamp}s] ${stepText}`]);

      if (currentStep >= totalSteps) {
        clearInterval(interval);
        setIsDone(true);
      }
    }, 450);

    return () => clearInterval(interval);
  }, [isOpen, actionType]);

  if (!isOpen || !actionType) return null;

  const strokeDashoffset = 283 - (283 * progress) / 100;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: 'spring', stiffness: 350, damping: 28 }}
          className="glass-card rounded-[2.5rem] w-full max-w-2xl p-8 sm:p-10 shadow-[0_30px_90px_rgba(0,0,0,0.9)] relative overflow-hidden text-slate-100"
        >
          {/* Top Ambient Glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-40 bg-[#A855F7]/10 blur-[90px] pointer-events-none" />

          {/* Header Row */}
          <div className="flex items-center justify-between mb-8 relative z-10">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-2xl bg-gradient-to-br ${config.color} text-white shadow-lg`}>
                <ActionIcon className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white tracking-tight font-sans">
                  {config.title}
                </h3>
                <p className="text-xs text-[#A1A1AA] mt-0.5 font-mono">
                  {vmName} {vmid ? `(VMID #${vmid})` : ''}
                </p>
              </div>
            </div>

            {isDone && (
              <button
                onClick={onClose}
                className="p-2 text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.1)] rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Central Progress Ring & Percentage */}
          <div className="flex flex-col items-center justify-center my-6 relative z-10">
            <div className="relative w-36 h-36 flex items-center justify-center mb-6">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  className="text-[rgba(255,255,255,0.05)] stroke-current"
                  strokeWidth="8"
                  fill="transparent"
                />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="45"
                  className="stroke-current"
                  strokeWidth="8"
                  strokeDasharray="283"
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                  style={{ stroke: config.accentColor }}
                  transition={{ ease: 'easeOut', duration: 0.3 }}
                />
              </svg>

              <div className="absolute flex flex-col items-center justify-center text-center">
                {isDone ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                    className="w-12 h-12 rounded-full bg-[#10B981] text-white flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.8)]"
                  >
                    <Check className="w-7 h-7 stroke-[3]" />
                  </motion.div>
                ) : (
                  <>
                    <span className="text-3xl font-black font-mono tracking-tight text-white">
                      {progress}%
                    </span>
                    <span className="text-[9px] font-sans uppercase font-bold text-[#A1A1AA] tracking-widest mt-1">
                      Active Task
                    </span>
                  </>
                )}
              </div>
            </div>

            <div className="w-full max-w-sm mb-4">
               <PremiumProgressBar value={progress} />
            </div>

            {/* Current Step Title */}
            <div className="mt-2 text-center">
              <span className="text-xs font-bold font-sans uppercase tracking-widest text-[#C084FC]">
                {isDone ? 'Operation Complete!' : config.steps[currentStepIndex]}
              </span>
            </div>
          </div>

          {/* Interactive Live Log Output Console */}
          <div className="bg-[rgba(0,0,0,0.6)] rounded-[1.5rem] p-5 border border-[rgba(255,255,255,0.05)] font-mono text-xs text-[#D4D4D8] space-y-2 h-36 overflow-y-auto custom-scrollbar my-6 relative z-10 shadow-inner">
            <div className="text-[10px] uppercase font-bold tracking-widest text-[#71717A] mb-2 border-b border-[rgba(255,255,255,0.05)] pb-2 flex items-center justify-between">
              <span>Hypervisor Live Terminal Stream</span>
              <span className="w-2 h-2 rounded-full bg-[#34D399] animate-ping" />
            </div>
            {logs.map((log, idx) => (
              <div key={idx} className="flex items-center gap-2 text-[#D4D4D8]">
                <span className="text-[#C084FC] shrink-0">&gt;</span>
                <span className="truncate">{log}</span>
              </div>
            ))}
          </div>

          {/* Footer Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[rgba(255,255,255,0.05)] relative z-10">
            {isDone ? (
              <>
                {onOpenConsole && (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      onClose();
                      onOpenConsole();
                    }}
                    className="px-5 py-3 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#E4E4E7] hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-[rgba(255,255,255,0.1)] transition-colors flex items-center gap-2"
                  >
                    <Terminal className="w-4 h-4" /> Open Console
                  </motion.button>
                )}
                <motion.button
                  whileHover={{ scale: 1.02, boxShadow: '0 0 20px rgba(168,85,247,0.4)' }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onClose}
                  className="px-6 py-3 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] transition-all border border-[rgba(255,255,255,0.1)]"
                >
                  Return to Dashboard
                </motion.button>
              </>
            ) : (
              <div className="text-xs text-[#71717A] font-mono flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#A855F7] animate-pulse" />
                Please do not close this window during hypervisor execution...
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
