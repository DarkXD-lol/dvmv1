import React, { useState } from 'react';
import { 
  Globe, 
  Server, 
  Cpu, 
  Activity, 
  Search, 
  Filter, 
  Maximize2, 
  RefreshCw, 
  Terminal, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Layers, 
  Zap, 
  Copy, 
  Check, 
  ExternalLink,
  MapPin,
  Wifi,
  HardDrive,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { HypervisorNode, VMInstance } from '../types';

interface GlobalInfrastructureViewProps {
  nodes: HypervisorNode[];
  vms: VMInstance[];
  onSelectNode?: (nodeId: string) => void;
}

export const GlobalInfrastructureView: React.FC<GlobalInfrastructureViewProps> = ({
  nodes,
  vms,
  onSelectNode
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'online' | 'maintenance' | 'offline'>('all');
  const [selectedNode, setSelectedNode] = useState<HypervisorNode | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const nodeCoordinates: Record<string, { x: number; y: number; country: string; city: string; region: string; provider: string; latency: number }> = {
    'node-sg-01': { x: 78, y: 58, country: 'Singapore', city: 'Singapore', region: 'Southeast Asia', provider: 'Equinix SG1', latency: 4 },
    'node-fra-01': { x: 52, y: 28, country: 'Germany', city: 'Frankfurt', region: 'Europe Central', provider: 'Interxion FRA1', latency: 12 },
    'node-us-east': { x: 28, y: 32, country: 'United States', city: 'Ashburn, VA', region: 'US East', provider: 'Equinix DC2', latency: 24 },
    'node-tyo-01': { x: 86, y: 34, country: 'Japan', city: 'Tokyo', region: 'Asia Pacific', provider: 'TYO Data Center', latency: 18 },
    'node-syd-01': { x: 88, y: 78, country: 'Australia', city: 'Sydney', region: 'Oceania', provider: 'NEXTDC S1', latency: 32 },
  };

  const filteredNodes = nodes.filter(node => {
    const matchesSearch = node.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          node.region.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          node.ipAddress.includes(searchQuery);
    const matchesStatus = statusFilter === 'all' || node.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const onlineCount = nodes.filter(n => n.status === 'online').length;
  const maintenanceCount = nodes.filter(n => n.status === 'maintenance').length;
  const offlineCount = nodes.filter(n => n.status === 'offline').length;
  const totalVmsCount = nodes.reduce((acc, n) => acc + n.vmCount, 0);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const triggerRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  return (
    <div className="space-y-6">
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#3B82F6]/20 via-[#22D3EE]/10 to-transparent rounded-full blur-[100px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/20 border border-[#3B82F6]/40 text-[#93C5FD] text-[10px] font-mono font-bold tracking-widest uppercase">
              <Globe className="w-3 h-3 text-[#22D3EE]" /> Global Hypervisor Mesh & Node Topography
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Global Infrastructure Matrix
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Real-time multi-region clustering, automated geo-routing, and cluster health monitoring across worldwide availability zones.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={triggerRefresh}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-bold transition-all cursor-pointer ${isRefreshing ? 'opacity-70' : ''}`}
            >
              <RefreshCw className={`w-4 h-4 text-[#22D3EE] ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>Sync Nodes</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-6 gap-4">
        {[
          { label: 'Total Nodes', value: nodes.length, icon: Cpu, color: 'text-[#8B5CF6]', bg: 'bg-[#8B5CF6]/10' },
          { label: 'Online Nodes', value: onlineCount, icon: CheckCircle2, color: 'text-[#22C55E]', bg: 'bg-[#22C55E]/10' },
          { label: 'Maintenance', value: maintenanceCount, icon: AlertTriangle, color: 'text-[#F59E0B]', bg: 'bg-[#F59E0B]/10' },
          { label: 'Offline', value: offlineCount, icon: ShieldCheck, color: 'text-[#EF4444]', bg: 'bg-[#EF4444]/10' },
          { label: 'Active VPS', value: totalVmsCount, icon: Server, color: 'text-[#3B82F6]', bg: 'bg-[#3B82F6]/10' },
          { label: 'Global Regions', value: '5 Zones', icon: Globe, color: 'text-[#22D3EE]', bg: 'bg-[#22D3EE]/10' },
        ].map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="glass-card p-4 rounded-2xl border border-white/5 flex items-center gap-4">
              <div className={`p-3 rounded-xl ${stat.bg} ${stat.color} shrink-0`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[10px] font-mono text-[#A1A1AA] uppercase tracking-wider">{stat.label}</div>
                <div className="text-lg font-black text-white font-sans mt-0.5">{stat.value}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="glass-card rounded-[2.5rem] p-6 lg:p-8 space-y-6 relative overflow-hidden border border-white/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#22D3EE]" /> Live World Topology Map
            </h3>
            <span className="px-2.5 py-0.5 rounded-full bg-[#22D3EE]/10 border border-[#22D3EE]/30 text-[#22D3EE] text-[10px] font-mono font-bold">
              60 FPS Mesh Active
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA]" />
              <input
                type="text"
                placeholder="Search node or region..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#8B5CF6] transition-all w-48 sm:w-60"
              />
            </div>

            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
              {(['all', 'online', 'maintenance', 'offline'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                    statusFilter === status 
                      ? 'bg-[#8B5CF6] text-white shadow-md' 
                      : 'text-[#A1A1AA] hover:text-white'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="relative w-full h-[450px] bg-[#03050C] rounded-3xl border border-white/10 overflow-hidden flex items-center justify-center shadow-inner">
          <div className="absolute inset-0 bg-[radial-gradient(#3B82F6_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none" />

          <svg className="absolute inset-0 w-full h-full opacity-25" viewBox="0 0 1000 500" preserveAspectRatio="none">
            <path d="M 120 120 Q 180 80 250 140 T 320 200 T 220 280 T 120 220 Z" fill="#3B82F6" opacity="0.3" />
            <path d="M 280 300 Q 340 320 320 420 T 260 460 T 240 340 Z" fill="#3B82F6" opacity="0.25" />
            <path d="M 480 120 Q 540 100 580 160 T 520 220 T 460 180 Z" fill="#3B82F6" opacity="0.3" />
            <path d="M 480 240 Q 560 260 540 380 T 460 420 T 440 300 Z" fill="#3B82F6" opacity="0.25" />
            <path d="M 600 100 Q 750 80 880 180 T 780 320 T 620 220 Z" fill="#22D3EE" opacity="0.3" />
            <path d="M 800 380 Q 880 360 860 440 T 780 440 Z" fill="#22D3EE" opacity="0.25" />

            <g opacity="0.4">
              <motion.path 
                d="M 520 160 Q 400 100 280 160" 
                stroke="#8B5CF6" 
                strokeWidth="1.5" 
                fill="none" 
                strokeDasharray="4 4"
                animate={{ strokeDashoffset: [0, -32] }}
                transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
              />
              <motion.path 
                d="M 520 160 Q 650 120 780 180" 
                stroke="#22D3EE" 
                strokeWidth="1.5" 
                fill="none" 
                strokeDasharray="4 4"
                animate={{ strokeDashoffset: [0, -32] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
              />
              <motion.path 
                d="M 780 180 Q 830 280 880 380" 
                stroke="#3B82F6" 
                strokeWidth="1.5" 
                fill="none" 
                strokeDasharray="4 4"
                animate={{ strokeDashoffset: [0, -32] }}
                transition={{ duration: 7, repeat: Infinity, ease: 'linear' }}
              />
            </g>
          </svg>

          {filteredNodes.map((node) => {
            const geo = nodeCoordinates[node.id] || { x: 50, y: 50, country: 'Unknown', city: node.region, region: node.region, provider: 'Generic DC', latency: 15 };
            const isSelected = selectedNode?.id === node.id;
            const statusColor = 
              node.status === 'online' ? '#22C55E' : 
              node.status === 'maintenance' ? '#F59E0B' : '#EF4444';

            return (
              <div
                key={node.id}
                className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-10"
                style={{ left: `${geo.x}%`, top: `${geo.y}%` }}
                onClick={() => setSelectedNode(node)}
              >
                <motion.div
                  animate={{ scale: [1, 2.2], opacity: [0.8, 0] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: 'easeOut' }}
                  className="absolute inset-0 rounded-full"
                  style={{ backgroundColor: statusColor, width: 36, height: 36, left: -10, top: -10 }}
                />

                <div className={`relative flex items-center justify-center w-6 h-6 rounded-full bg-[#080A12] border-2 shadow-lg transition-transform group-hover:scale-125 ${
                  isSelected ? 'scale-125 ring-4 ring-[#8B5CF6]/50' : ''
                }`} style={{ borderColor: statusColor }}>
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: statusColor }} />
                </div>

                <div className="absolute left-1/2 -translate-x-1/2 top-8 px-2 py-1 bg-[#080A12]/90 backdrop-blur-md rounded-lg border border-white/10 text-[10px] font-mono text-white whitespace-nowrap shadow-xl pointer-events-none group-hover:scale-105 transition-transform">
                  <div className="font-bold">{node.name}</div>
                  <div className="text-[9px] text-[#A1A1AA]">{geo.city} ({node.vmCount} VMs)</div>
                </div>
              </div>
            );
          })}

          <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/60 backdrop-blur-md p-1.5 rounded-xl border border-white/10 z-20">
            <button className="p-2 hover:bg-white/10 text-white rounded-lg transition-colors cursor-pointer" title="Zoom In">
              <Maximize2 className="w-4 h-4" />
            </button>
            <div className="h-4 w-[1px] bg-white/10" />
            <span className="text-[10px] font-mono text-[#22D3EE] px-2 font-bold">100% Zoom</span>
          </div>
        </div>

        <AnimatePresence>
          {selectedNode && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="glass-card p-6 rounded-3xl border border-[#8B5CF6]/40 bg-gradient-to-br from-[#0D111E] to-[#080A12] space-y-6 relative shadow-2xl"
            >
              <button
                onClick={() => setSelectedNode(null)}
                className="absolute top-6 right-6 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A1A1AA] hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#D8B4FE]">
                    <Cpu className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-lg font-bold text-white font-sans">{selectedNode.name}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                        selectedNode.status === 'online' ? 'bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40' :
                        selectedNode.status === 'maintenance' ? 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40' :
                        'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40'
                      }`}>
                        {selectedNode.status}
                      </span>
                    </div>
                    <div className="text-xs font-mono text-[#A1A1AA] mt-1">
                      {nodeCoordinates[selectedNode.id]?.provider || 'Enterprise Datacenter'} • {nodeCoordinates[selectedNode.id]?.city}, {nodeCoordinates[selectedNode.id]?.country} • IP: {selectedNode.ipAddress}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleCopy(selectedNode.id, 'nodeId')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold border border-white/10 cursor-pointer"
                  >
                    {copiedId === 'nodeId' ? <Check className="w-3.5 h-3.5 text-[#22C55E]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'nodeId' ? 'ID Copied' : 'Copy Node ID'}</span>
                  </button>

                  <button
                    onClick={() => alert(`Opening hypervisor management console for ${selectedNode.name} (${selectedNode.ipAddress}:8443)...`)}
                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold shadow-lg shadow-[#8B5CF6]/20 cursor-pointer hover:opacity-90"
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Open Node Console</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-[#A1A1AA] uppercase">Active VMs</div>
                  <div className="text-xl font-black text-white">{selectedNode.vmCount} Instances</div>
                  <div className="text-[10px] text-[#22D3EE]">Running smoothly</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-[#A1A1AA] uppercase">CPU Load</div>
                  <div className="text-xl font-black text-white">{Math.round((selectedNode.usedVcpu / selectedNode.totalVcpu) * 100)}%</div>
                  <div className="text-[10px] text-[#A1A1AA]">{selectedNode.usedVcpu} / {selectedNode.totalVcpu} vCPUs</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-[#A1A1AA] uppercase">RAM Allocation</div>
                  <div className="text-xl font-black text-white">{Math.round((selectedNode.usedRamGB / selectedNode.totalRamGB) * 100)}%</div>
                  <div className="text-[10px] text-[#A1A1AA]">{selectedNode.usedRamGB} GB / {selectedNode.totalRamGB} GB</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-[#A1A1AA] uppercase">Network Latency</div>
                  <div className="text-xl font-black text-white">{nodeCoordinates[selectedNode.id]?.latency || 14} ms</div>
                  <div className="text-[10px] text-[#22C55E]">Optimal fiber link</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-3 pt-4">
          <h4 className="text-xs font-mono font-bold text-[#A1A1AA] uppercase tracking-wider">All Hypervisor Nodes ({filteredNodes.length})</h4>
          
          <div className="space-y-2">
            {filteredNodes.map((node) => {
              const geo = nodeCoordinates[node.id] || { city: 'Unknown', country: 'Unknown', latency: 15 };
              const cpuPct = Math.round((node.usedVcpu / node.totalVcpu) * 100);
              const ramPct = Math.round((node.usedRamGB / node.totalRamGB) * 100);

              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className="p-4 rounded-2xl bg-black/40 hover:bg-white/[0.04] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full shrink-0 ${
                      node.status === 'online' ? 'bg-[#22C55E] shadow-[0_0_10px_#22C55E]' :
                      node.status === 'maintenance' ? 'bg-[#F59E0B]' : 'bg-[#EF4444]'
                    }`} />
                    <div>
                      <div className="text-sm font-bold text-white font-sans flex items-center gap-2">
                        <span>{node.name}</span>
                        <span className="text-[10px] font-mono text-[#A1A1AA]">({node.ipAddress})</span>
                      </div>
                      <div className="text-xs text-[#A1A1AA] flex items-center gap-3 mt-0.5">
                        <span>📍 {geo.city}, {geo.country}</span>
                        <span>•</span>
                        <span>⚡ {geo.latency}ms latency</span>
                        <span>•</span>
                        <span>🖥 {node.vmCount} VPS</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="hidden md:flex items-center gap-4 text-xs font-mono text-[#A1A1AA]">
                      <div>CPU: <strong className="text-white">{cpuPct}%</strong></div>
                      <div>RAM: <strong className="text-white">{ramPct}%</strong></div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedNode(node);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-all border border-white/10 cursor-pointer"
                    >
                      Manage Node
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
