import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { 
  BarChart3, 
  Cpu, 
  Activity, 
  HardDrive, 
  Wifi, 
  Clock, 
  Zap, 
  RefreshCw 
} from 'lucide-react';

const mockAnalyticsData = [
  { time: '00:00', cpu: 22, ram: 45, diskIo: 120, networkRx: 45, networkTx: 80 },
  { time: '04:00', cpu: 18, ram: 42, diskIo: 90, networkRx: 30, networkTx: 50 },
  { time: '08:00', cpu: 35, ram: 58, diskIo: 240, networkRx: 110, networkTx: 190 },
  { time: '12:00', cpu: 62, ram: 74, diskIo: 480, networkRx: 280, networkTx: 410 },
  { time: '16:00', cpu: 48, ram: 65, diskIo: 310, networkRx: 190, networkTx: 320 },
  { time: '20:00', cpu: 30, ram: 52, diskIo: 180, networkRx: 95, networkTx: 140 },
  { time: '24:00', cpu: 25, ram: 48, diskIo: 140, networkRx: 60, networkTx: 90 },
];

import { AnalyticsSkeleton } from './DashboardSkeleton';

interface ResourceAnalyticsViewProps {
  isLoading?: boolean;
}

export const ResourceAnalyticsView: React.FC<ResourceAnalyticsViewProps> = ({ isLoading = false }) => {
  const [timeframe, setTimeframe] = useState<'1h' | '24h' | '7d' | '30d'>('24h');

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <AnalyticsSkeleton />
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight font-sans flex items-center gap-2.5">
            <BarChart3 className="w-5 h-5 text-[#3B82F6]" />
            <span>Infrastructure Telemetry Analytics</span>
          </h2>
          <p className="text-xs text-[#A1A1AA] mt-1 font-medium">
            Historical CPU, RAM, Disk IOPS, and network bandwidth monitoring over time
          </p>
        </div>

        {/* Timeframe Selector Pills */}
        <div className="flex items-center gap-1.5 p-1.5 bg-[rgba(10,13,22,0.8)] border border-[rgba(255,255,255,0.08)] rounded-2xl backdrop-blur-xl">
          {(['1h', '24h', '7d', '30d'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold uppercase transition-all ${
                timeframe === tf
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white shadow-md'
                  : 'text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)]'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* vCPU & RAM History Area Chart */}
        <div className="glass-card rounded-[2rem] p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#8B5CF6]/15 text-[#C084FC]">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">vCPU & RAM Utilization</h3>
                <p className="text-[10px] text-[#A1A1AA] font-mono">Aggregated Load %</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-mono">
              <span className="flex items-center gap-1.5 text-[#A855F7]">
                <span className="w-2 h-2 rounded-full bg-[#A855F7]" /> vCPU
              </span>
              <span className="flex items-center gap-1.5 text-[#3B82F6]">
                <span className="w-2 h-2 rounded-full bg-[#3B82F6]" /> RAM
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockAnalyticsData}>
                <defs>
                  <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#A855F7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#A855F7" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="ramGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" stroke="#A1A1AA" fontSize={10} tickLine={false} />
                <YAxis stroke="#A1A1AA" fontSize={10} tickLine={false} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0A0D16', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '1rem', color: '#FFF', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="cpu" stroke="#A855F7" strokeWidth={2} fillOpacity={1} fill="url(#cpuGrad)" />
                <Area type="monotone" dataKey="ram" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#ramGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Network Throughput Chart */}
        <div className="glass-card rounded-[2rem] p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#22D3EE]/15 text-[#22D3EE]">
                <Wifi className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Network Bandwidth Throughput</h3>
                <p className="text-[10px] text-[#A1A1AA] font-mono">Mbps (Rx/Tx Rate)</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-mono">
              <span className="flex items-center gap-1.5 text-[#22D3EE]">
                <span className="w-2 h-2 rounded-full bg-[#22D3EE]" /> Rx (In)
              </span>
              <span className="flex items-center gap-1.5 text-[#10B981]">
                <span className="w-2 h-2 rounded-full bg-[#10B981]" /> Tx (Out)
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockAnalyticsData}>
                <defs>
                  <linearGradient id="rxGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22D3EE" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#22D3EE" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="txGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" stroke="#A1A1AA" fontSize={10} tickLine={false} />
                <YAxis stroke="#A1A1AA" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0A0D16', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '1rem', color: '#FFF', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="networkRx" stroke="#22D3EE" strokeWidth={2} fillOpacity={1} fill="url(#rxGrad)" />
                <Area type="monotone" dataKey="networkTx" stroke="#10B981" strokeWidth={2} fillOpacity={1} fill="url(#txGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
