import React from 'react';
import { motion } from 'motion/react';
import { useTheme } from '../context/ThemeContext';

export interface DvmLogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | number;
  variant?: 'icon' | 'primary' | 'horizontal' | 'vertical' | 'compact' | 'monochrome' | 'light' | 'appIcon';
  withGlow?: boolean;
  animated?: boolean;
  interactive?: boolean;
  showSubtitle?: boolean;
  subtitleText?: string;
  onClick?: () => void;
}

export const DvmIconMark: React.FC<{
  size?: number;
  withGlow?: boolean;
  animated?: boolean;
  monochrome?: boolean;
  lightMode?: boolean;
  idPrefix?: string;
}> = ({
  size = 48,
  withGlow = true,
  animated = true,
  monochrome = false,
  lightMode = false,
  idPrefix: customPrefix,
}) => {
  let themePrimary = '#8B5CF6';
  let themeSecondary = '#3B82F6';
  let themeAccent = '#22D3EE';

  try {
    const { theme } = useTheme();
    if (theme) {
      themePrimary = theme.primaryColor || '#8B5CF6';
      themeSecondary = theme.secondaryColor || '#3B82F6';
      themeAccent = theme.accentColor || '#22D3EE';
    }
  } catch (e) {
    // Fallback
  }

  const generatedId = React.useId().replace(/:/g, '');
  const prefix = customPrefix || `dvm_${generatedId}`;

  // Palette overrides for monochrome / light
  const pColor = monochrome ? '#FFFFFF' : lightMode ? '#6D28D9' : themePrimary;
  const sColor = monochrome ? '#CBD5E1' : lightMode ? '#2563EB' : themeSecondary;
  const aColor = monochrome ? '#94A3B8' : lightMode ? '#0284C7' : themeAccent;
  const darkColor = lightMode ? '#F8FAFC' : '#080A12';

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0 select-none group"
      style={{ width: size, height: size }}
    >
      {/* 1. Ambient Breathing Halo Glow */}
      {withGlow && !monochrome && (
        <motion.div
          animate={
            animated
              ? {
                  opacity: [0.4, 0.75, 0.4],
                  scale: [0.92, 1.08, 0.92],
                }
              : { opacity: 0.5 }
          }
          transition={{
            duration: 3.8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute inset-0 rounded-full blur-xl pointer-events-none"
          style={{
            background: `radial-gradient(circle at 45% 45%, ${pColor} 0%, ${aColor} 55%, transparent 80%)`,
            transform: 'scale(1.35)',
          }}
        />
      )}

      {/* 2. Light Sweep Ambient Ring (Hover & Idle) */}
      {animated && !monochrome && (
        <motion.div
          animate={{ rotate: 360 }}
          transition={{
            duration: 16,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute inset-0 rounded-full pointer-events-none opacity-30 group-hover:opacity-70 transition-opacity duration-300"
          style={{
            background: `conic-gradient(from 0deg, transparent 0deg, ${aColor} 90deg, transparent 180deg, ${pColor} 270deg, transparent 360deg)`,
            filter: 'blur(4px)',
            maskImage: 'radial-gradient(circle, transparent 52%, black 68%)',
            WebkitMaskImage: 'radial-gradient(circle, transparent 52%, black 68%)',
          }}
        />
      )}

      {/* 3. Main SVG Precision Vector Icon */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 w-full h-full drop-shadow-[0_4px_16px_rgba(0,0,0,0.4)]"
      >
        {/* Outer Orbital Network Trace */}
        <motion.path
          d="M32 6 C 48 6, 58 16, 58 32 C 58 48, 48 58, 32 58"
          stroke={`url(#${prefix}_orbit_grad)`}
          strokeWidth="1.2"
          strokeDasharray="3 4"
          opacity="0.65"
          animate={animated ? { strokeDashoffset: [0, -28] } : false}
          transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
        />

        {/* Server Rack Vertical Spine Backing Glass */}
        <rect
          x="10"
          y="12"
          width="12"
          height="40"
          rx="4"
          fill={`url(#${prefix}_spine_bg)`}
          opacity="0.8"
        />

        {/* Server Rack Slots & LED Nodes */}
        <g opacity="0.9">
          {/* Blade Slot 1 */}
          <rect x="13" y="16" width="6" height="3" rx="1.5" fill={monochrome ? '#E2E8F0' : '#FFFFFF'} opacity="0.9" />
          <circle cx="20" cy="17.5" r="1" fill={aColor} />

          {/* Blade Slot 2 */}
          <rect x="13" y="24" width="6" height="3" rx="1.5" fill={monochrome ? '#CBD5E1' : pColor} />
          <circle cx="20" cy="25.5" r="1" fill={pColor} />

          {/* Blade Slot 3 */}
          <rect x="13" y="32" width="6" height="3" rx="1.5" fill={monochrome ? '#94A3B8' : sColor} />
          <circle cx="20" cy="33.5" r="1" fill={aColor} />

          {/* Blade Slot 4 */}
          <rect x="13" y="40" width="6" height="3" rx="1.5" fill={monochrome ? '#E2E8F0' : '#FFFFFF'} opacity="0.8" />
          <circle cx="20" cy="41.5" r="1" fill={pColor} />
        </g>

        {/* Outer Cloud Arc / Sweeping 'D' Loop */}
        <path
          d="M22 12 H36 C 48 12, 56 20, 56 32 C 56 44, 48 52, 36 52 H22"
          stroke={`url(#${prefix}_outer_d_stroke)`}
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Outer Cloud Glass Fill Layer */}
        <path
          d="M22 12 H36 C 48 12, 56 20, 56 32 C 56 44, 48 52, 36 52 H22 Z"
          fill={`url(#${prefix}_d_glass_fill)`}
          opacity="0.25"
        />

        {/* Inner Counter Arc (Virtual Machine Container Space) */}
        <path
          d="M22 22 H34 C 41 22, 45 26, 45 32 C 45 38, 41 42, 34 42 H22"
          stroke={`url(#${prefix}_inner_arc_stroke)`}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.85"
        />

        {/* Central Isometric Core VM Gem Node */}
        <g>
          {/* Isometric Diamond Core */}
          <path
            d="M32 25 L39 32 L32 39 L25 32 Z"
            fill={`url(#${prefix}_core_gem)`}
          />
          {/* Top Facet Highlight */}
          <path
            d="M32 25 L39 32 L32 32 Z"
            fill="#FFFFFF"
            opacity="0.35"
          />
          {/* Center Glowing Dot */}
          <motion.circle
            cx="32"
            cy="32"
            r="2"
            fill="#FFFFFF"
            animate={animated ? { r: [1.8, 2.6, 1.8], opacity: [0.8, 1, 0.8] } : false}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          />
        </g>

        {/* Dynamic Node Connections (Live Cloud Infrastructure Nodes) */}
        <motion.circle
          cx="36"
          cy="12"
          r="2.5"
          fill={aColor}
          animate={animated ? { r: [2, 3, 2] } : false}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.circle
          cx="56"
          cy="32"
          r="2.5"
          fill={pColor}
          animate={animated ? { r: [2, 3.2, 2] } : false}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
        />
        <motion.circle
          cx="36"
          cy="52"
          r="2.5"
          fill={sColor}
          animate={animated ? { r: [2, 3, 2] } : false}
          transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut', delay: 0.8 }}
        />

        {/* Glass Highlight Sheen Overlay */}
        <path
          d="M12 12 L44 12 L22 52 Z"
          fill="url(#dvm_glass_sheen)"
          opacity="0.08"
        />

        {/* SVG Definition Gradients */}
        <defs>
          <linearGradient id={`${prefix}_orbit_grad`} x1="32" y1="6" x2="32" y2="58" gradientUnits="userSpaceOnUse">
            <stop stopColor={aColor} />
            <stop offset="0.5" stopColor={pColor} />
            <stop offset="1" stopColor={sColor} />
          </linearGradient>

          <linearGradient id={`${prefix}_spine_bg`} x1="10" y1="12" x2="22" y2="52" gradientUnits="userSpaceOnUse">
            <stop stopColor={pColor} stopOpacity="0.8" />
            <stop offset="1" stopColor={darkColor} stopOpacity="0.9" />
          </linearGradient>

          <linearGradient id={`${prefix}_outer_d_stroke`} x1="10" y1="12" x2="56" y2="52" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFFFF" />
            <stop offset="0.25" stopColor={pColor} />
            <stop offset="0.65" stopColor={sColor} />
            <stop offset="0.9" stopColor={aColor} />
            <stop offset="1" stopColor="#FFFFFF" />
          </linearGradient>

          <linearGradient id={`${prefix}_d_glass_fill`} x1="22" y1="12" x2="56" y2="52" gradientUnits="userSpaceOnUse">
            <stop stopColor={pColor} stopOpacity="0.5" />
            <stop offset="0.5" stopColor={sColor} stopOpacity="0.2" />
            <stop offset="1" stopColor={aColor} stopOpacity="0.4" />
          </linearGradient>

          <linearGradient id={`${prefix}_inner_arc_stroke`} x1="22" y1="22" x2="45" y2="42" gradientUnits="userSpaceOnUse">
            <stop stopColor={aColor} />
            <stop offset="1" stopColor={pColor} />
          </linearGradient>

          <linearGradient id={`${prefix}_core_gem`} x1="25" y1="25" x2="39" y2="39" gradientUnits="userSpaceOnUse">
            <stop stopColor={aColor} />
            <stop offset="0.5" stopColor={pColor} />
            <stop offset="1" stopColor={sColor} />
          </linearGradient>

          <linearGradient id="dvm_glass_sheen" x1="12" y1="12" x2="44" y2="52" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFFFF" stopOpacity="0.9" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export const DvmWordmark: React.FC<{
  monochrome?: boolean;
  lightMode?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  subtitleText?: string;
}> = ({
  monochrome = false,
  lightMode = false,
  size = 'md',
  showSubtitle = true,
  subtitleText = 'CLOUD ENGINE',
}) => {
  const textSizes = {
    sm: { title: 'text-lg', subtitle: 'text-[9px]' },
    md: { title: 'text-2xl', subtitle: 'text-[10px]' },
    lg: { title: 'text-3xl', subtitle: 'text-[11px]' },
    xl: { title: 'text-4xl', subtitle: 'text-xs' },
  }[size];

  const textColor = monochrome ? 'text-white' : lightMode ? 'text-slate-900' : 'text-white';

  return (
    <div className="flex flex-col leading-none select-none font-sans">
      <div className="flex items-center gap-1.5 font-black tracking-tight">
        <span className={`${textSizes.title} ${textColor} font-sans tracking-[0.02em]`}>
          DVM
        </span>
        <span className="px-2 py-0.5 rounded-full text-[9px] font-mono uppercase tracking-widest font-bold bg-gradient-to-r from-[#8B5CF6]/20 to-[#22D3EE]/20 border border-[#8B5CF6]/30 text-[#22D3EE] shadow-inner">
          v1.0
        </span>
      </div>
      {showSubtitle && (
        <span
          className={`${textSizes.subtitle} font-mono font-bold uppercase tracking-[0.25em] text-[#A1A1AA] mt-1 opacity-90`}
        >
          {subtitleText}
        </span>
      )}
    </div>
  );
};

export const DvmLogo: React.FC<DvmLogoProps> = ({
  className = '',
  size = 'md',
  variant = 'primary',
  withGlow = true,
  animated = true,
  interactive = true,
  showSubtitle = true,
  subtitleText,
  onClick,
}) => {
  const pixelSize = typeof size === 'number'
    ? size
    : {
        xs: 24,
        sm: 32,
        md: 40,
        lg: 48,
        xl: 64,
        '2xl': 80,
      }[size];

  const wordmarkSize = typeof size === 'number'
    ? size > 48 ? 'lg' : size < 32 ? 'sm' : 'md'
    : size === '2xl' ? 'xl' : size === 'xl' ? 'lg' : size === 'xs' || size === 'sm' ? 'sm' : 'md';

  const isMonochrome = variant === 'monochrome';
  const isLight = variant === 'light';

  return (
    <motion.div
      onClick={onClick}
      whileHover={
        interactive
          ? {
              scale: 1.03,
              rotate: 1.5,
              transition: { type: 'spring', stiffness: 400, damping: 25 },
            }
          : undefined
      }
      whileTap={interactive ? { scale: 0.97 } : undefined}
      className={`inline-flex items-center gap-3.5 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* Icon */}
      <DvmIconMark
        size={pixelSize}
        withGlow={withGlow}
        animated={animated}
        monochrome={isMonochrome}
        lightMode={isLight}
      />

      {/* Wordmark (if variant includes text) */}
      {variant !== 'icon' && (
        <DvmWordmark
          monochrome={isMonochrome}
          lightMode={isLight}
          size={wordmarkSize}
          showSubtitle={variant !== 'compact' && showSubtitle}
          subtitleText={subtitleText}
        />
      )}
    </motion.div>
  );
};

export const DvmAppIcon: React.FC<{ size?: number; animated?: boolean }> = ({
  size = 64,
  animated = true,
}) => (
  <div
    className="relative inline-flex items-center justify-center shrink-0 rounded-2xl bg-gradient-to-br from-[#0D111E] via-[#080A12] to-[#05070E] p-3 shadow-2xl border border-[#8B5CF6]/30 overflow-hidden group"
    style={{ width: size, height: size }}
  >
    {/* Inner Ambient Glow */}
    <div className="absolute inset-0 bg-gradient-to-br from-[#8B5CF6]/20 via-[#3B82F6]/10 to-[#22D3EE]/20 opacity-60 group-hover:opacity-100 transition-opacity duration-500 blur-lg" />
    {/* Glass Reflection Highlight */}
    <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />
    <DvmIconMark size={size * 0.75} withGlow={true} animated={animated} />
  </div>
);

export const DvmFaviconLogo: React.FC<{ size?: number }> = ({ size = 32 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="32" height="32" rx="8" fill="#080A12" />
    <rect width="32" height="32" rx="8" fill="url(#fav_bg_glow)" opacity="0.3" />
    <rect width="32" height="32" rx="8" stroke="url(#fav_border)" strokeWidth="1.2" opacity="0.6" />
    
    {/* Rack Spine */}
    <rect x="5" y="6" width="6" height="20" rx="2" fill="#8B5CF6" opacity="0.8" />
    <circle cx="8" cy="9" r="0.8" fill="#FFFFFF" />
    <circle cx="8" cy="14" r="0.8" fill="#22D3EE" />
    <circle cx="8" cy="19" r="0.8" fill="#3B82F6" />
    <circle cx="8" cy="23" r="0.8" fill="#FFFFFF" />

    {/* Cloud Arc */}
    <path d="M11 6 H18 C 24 6, 28 10, 28 16 C 28 22, 24 26, 18 26 H11" stroke="url(#fav_arc)" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M11 11 H17 C 20 11, 22 13, 22 16 C 22 19, 20 21, 17 21 H11" stroke="#22D3EE" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
    
    {/* Core Gem */}
    <path d="M16 13 L20 16 L16 19 L12 16 Z" fill="url(#fav_gem)" />

    <defs>
      <linearGradient id="fav_border" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
        <stop stopColor="#8B5CF6" />
        <stop offset="0.5" stopColor="#3B82F6" />
        <stop offset="1" stopColor="#22D3EE" />
      </linearGradient>
      <linearGradient id="fav_arc" x1="11" y1="6" x2="28" y2="26" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.3" stopColor="#8B5CF6" />
        <stop offset="0.7" stopColor="#3B82F6" />
        <stop offset="1" stopColor="#22D3EE" />
      </linearGradient>
      <linearGradient id="fav_gem" x1="12" y1="13" x2="20" y2="19" gradientUnits="userSpaceOnUse">
        <stop stopColor="#22D3EE" />
        <stop offset="1" stopColor="#8B5CF6" />
      </linearGradient>
      <radialGradient id="fav_bg_glow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#8B5CF6" />
        <stop offset="100%" stopColor="#080A12" stopOpacity="0" />
      </radialGradient>
    </defs>
  </svg>
);
