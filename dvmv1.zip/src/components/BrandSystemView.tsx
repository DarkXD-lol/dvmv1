import React, { useState } from 'react';
import { 
  DvmLogo, 
  DvmIconMark, 
  DvmWordmark, 
  DvmFaviconLogo, 
  DvmAppIcon 
} from './DvmLogo';
import { 
  Copy, 
  Check, 
  Sparkles, 
  Palette, 
  Layers, 
  Zap, 
  ShieldCheck, 
  Download, 
  Eye, 
  Sliders, 
  Code, 
  CheckCircle2,
  Server,
  Cloud,
  Cpu,
  Network
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const BrandSystemView: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [testAnimated, setTestAnimated] = useState(true);
  const [testGlow, setTestGlow] = useState(true);
  const [selectedBg, setSelectedBg] = useState<'dark' | 'light' | 'grid'>('dark');
  const [showSvgModal, setShowSvgModal] = useState<string | null>(null);

  const brandColors = [
    { name: 'Neon Purple', hex: '#8B5CF6', role: 'Primary Brand Color', class: 'from-[#8B5CF6] to-[#A855F7]' },
    { name: 'Electric Blue', hex: '#3B82F6', role: 'Secondary Network Accent', class: 'from-[#3B82F6] to-[#60A5FA]' },
    { name: 'Soft Cyan', hex: '#22D3EE', role: 'Cyber Infrastructure Glow', class: 'from-[#22D3EE] to-[#06B6D4]' },
    { name: 'Deep Space', hex: '#080A12', role: 'Primary Dark Canvas', class: 'from-[#080A12] to-[#0D111E]' },
    { name: 'Pure White', hex: '#FFFFFF', role: 'High Contrast Typography', class: 'from-[#FFFFFF] to-[#E2E8F0]' },
  ];

  const logoVariants = [
    {
      id: 'primary',
      title: 'Primary Horizontal Logo',
      subtitle: 'Default brand lockup for top navigation, headers, and marketing',
      render: (
        <DvmLogo 
          variant="primary" 
          size="lg" 
          animated={testAnimated} 
          withGlow={testGlow} 
        />
      ),
      code: `<DvmLogo variant="primary" size="lg" />`,
    },
    {
      id: 'compact',
      title: 'Compact Logo',
      subtitle: 'Space-efficient lockup for collapsed sidebars and mobile bars',
      render: (
        <DvmLogo 
          variant="compact" 
          size="md" 
          animated={testAnimated} 
          withGlow={testGlow} 
        />
      ),
      code: `<DvmLogo variant="compact" size="md" />`,
    },
    {
      id: 'icon',
      title: 'Icon Only Mark',
      subtitle: 'Abstract D icon representing Cloud, Server Rack, VM Core & Network',
      render: (
        <DvmIconMark 
          size={56} 
          animated={testAnimated} 
          withGlow={testGlow} 
        />
      ),
      code: `<DvmIconMark size={56} />`,
    },
    {
      id: 'vertical',
      title: 'Vertical Stacked Logo',
      subtitle: 'Centered lockup for splash screens, app installers, and modals',
      render: (
        <div className="flex flex-col items-center text-center gap-3">
          <DvmIconMark size={64} animated={testAnimated} withGlow={testGlow} />
          <DvmWordmark size="md" showSubtitle={true} subtitleText="CLOUD INFRASTRUCTURE" />
        </div>
      ),
      code: `<DvmLogo variant="vertical" size="xl" />`,
    },
    {
      id: 'monochrome',
      title: 'Monochrome Version',
      subtitle: 'Pure high-contrast vector mark for single-color print or terminal UI',
      render: (
        <DvmLogo 
          variant="monochrome" 
          size="lg" 
          animated={false} 
          withGlow={false} 
        />
      ),
      code: `<DvmLogo variant="monochrome" size="lg" />`,
    },
    {
      id: 'light',
      title: 'Light Theme Version',
      subtitle: 'High contrast purple and blue mark on clean white canvas',
      render: (
        <div className="p-4 bg-white rounded-2xl shadow-inner border border-slate-200">
          <DvmLogo 
            variant="light" 
            size="md" 
            animated={testAnimated} 
            withGlow={false} 
          />
        </div>
      ),
      code: `<DvmLogo variant="light" size="md" />`,
    },
    {
      id: 'appIcon',
      title: 'App Icon / Squircle',
      subtitle: 'Glass squircle mark for desktop apps, mobile icons, and badges',
      render: (
        <DvmAppIcon size={68} animated={testAnimated} />
      ),
      code: `<DvmAppIcon size={68} />`,
    },
    {
      id: 'favicon',
      title: 'Browser Favicon (32x32)',
      subtitle: 'Pixel-optimized 32x32 SVG for browser tabs and web shortcuts',
      render: (
        <div className="flex items-center gap-4">
          <DvmFaviconLogo size={48} />
          <DvmFaviconLogo size={32} />
          <DvmFaviconLogo size={24} />
        </div>
      ),
      code: `<DvmFaviconLogo size={32} />`,
    },
  ];

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Brand Identity Header Banner */}
      <div className="glass-card p-6 lg:p-8 rounded-[2.5rem] border border-[#8B5CF6]/30 bg-gradient-to-br from-[#0D111E]/90 via-[#080A12]/95 to-[#05070E] relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#8B5CF6]/20 via-[#22D3EE]/15 to-transparent rounded-full blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#D8B4FE] text-[10px] font-mono font-bold tracking-widest uppercase">
              <Sparkles className="w-3 h-3 text-[#22D3EE]" /> Official DVM Brand System v1.0
            </div>
            <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-sans">
              Rebuilt Enterprise Brand & Vector System
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
              Designed specifically for high-density cloud infrastructure, VPS virtualization, and hypervisor management. Clean geometric vectors, ambient lighting, and fluid hover dynamics.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-3">
              <DvmAppIcon size={52} animated={true} />
              <div>
                <div className="text-xs font-bold text-white font-sans">DVM Cloud Engine</div>
                <div className="text-[10px] font-mono text-[#22D3EE]">Vector Mark Verified</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Abstract "D" Concept & Architectural Meaning */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          {
            icon: Server,
            title: 'Server Rack Spine',
            color: 'text-[#8B5CF6]',
            desc: 'Left vertical spine represents physical hypervisor node blades with live LED status indicators.'
          },
          {
            icon: Cloud,
            title: 'Cloud Hypervisor Loop',
            color: 'text-[#3B82F6]',
            desc: 'Sweeping outer arc symbolizes scalable cloud virtualization and seamless network routing.'
          },
          {
            icon: Cpu,
            title: 'VM Core Gem',
            color: 'text-[#22D3EE]',
            desc: 'Central isometric diamond depicts isolated guest virtual machines running in high-performance RAM.'
          },
          {
            icon: Network,
            title: 'Interconnect Nodes',
            color: 'text-[#C084FC]',
            desc: 'Pulsing vertex nodes signal zero-latency WebSocket cluster synchronization across data centers.'
          },
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="p-5 rounded-2xl glass-card border border-white/5 space-y-2 hover:border-[#8B5CF6]/30 transition-all">
              <div className="flex items-center gap-2">
                <Icon className={`w-5 h-5 ${item.color}`} />
                <h4 className="text-xs font-bold text-white font-sans">{item.title}</h4>
              </div>
              <p className="text-[11px] text-[#A1A1AA] leading-relaxed">{item.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Color System Showcase */}
      <div className="glass-card p-6 lg:p-8 rounded-[2rem] space-y-4">
        <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Palette className="w-4 h-4 text-[#8B5CF6]" /> Precision Color Palette
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {brandColors.map((color) => (
            <div 
              key={color.name}
              className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-3 group hover:border-white/20 transition-all"
            >
              <div className={`h-12 rounded-xl bg-gradient-to-r ${color.class} shadow-lg relative overflow-hidden flex items-end justify-end p-2`}>
                <button
                  onClick={() => copyToClipboard(color.hex, color.name)}
                  className="px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[9px] font-mono text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 cursor-pointer"
                >
                  {copiedId === color.name ? <Check className="w-2.5 h-2.5 text-[#22C55E]" /> : <Copy className="w-2.5 h-2.5" />}
                  {copiedId === color.name ? 'COPIED' : 'COPY'}
                </button>
              </div>

              <div>
                <div className="text-xs font-bold text-white font-sans">{color.name}</div>
                <div className="text-[10px] font-mono text-[#22D3EE]">{color.hex}</div>
                <div className="text-[10px] text-[#A1A1AA] mt-1">{color.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Controls & Canvas Background Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 glass-card rounded-2xl border border-white/10">
        <div className="flex items-center gap-4">
          <span className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#22D3EE]" /> Motion & Lighting Sandbox:
          </span>

          <label className="flex items-center gap-2 text-xs font-medium text-[#A1A1AA] cursor-pointer">
            <input
              type="checkbox"
              checked={testAnimated}
              onChange={(e) => setTestAnimated(e.target.checked)}
              className="w-4 h-4 accent-[#8B5CF6] rounded"
            />
            <span>Animations Active</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-medium text-[#A1A1AA] cursor-pointer">
            <input
              type="checkbox"
              checked={testGlow}
              onChange={(e) => setTestGlow(e.target.checked)}
              className="w-4 h-4 accent-[#22D3EE] rounded"
            />
            <span>Breathing Glow Halo</span>
          </label>
        </div>

        {/* Canvas Background Selector */}
        <div className="flex items-center gap-2 bg-black/40 p-1 rounded-xl border border-white/10">
          <span className="text-[10px] font-mono text-[#A1A1AA] px-2">Canvas:</span>
          {(['dark', 'light', 'grid'] as const).map((bg) => (
            <button
              key={bg}
              onClick={() => setSelectedBg(bg)}
              className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                selectedBg === bg 
                  ? 'bg-[#8B5CF6] text-white shadow-md' 
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              {bg}
            </button>
          ))}
        </div>
      </div>

      {/* Logo Variants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {logoVariants.map((variant) => (
          <div
            key={variant.id}
            className="glass-card rounded-[2rem] p-6 space-y-4 flex flex-col justify-between border border-white/5 hover:border-[#8B5CF6]/30 transition-all group"
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white font-sans">{variant.title}</h4>
                <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#8B5CF6]/20 text-[#D8B4FE] uppercase border border-[#8B5CF6]/30">
                  {variant.id}
                </span>
              </div>
              <p className="text-[11px] text-[#A1A1AA]">{variant.subtitle}</p>
            </div>

            {/* Render Preview Area */}
            <div className={`p-8 rounded-2xl flex items-center justify-center min-h-[140px] transition-all border ${
              selectedBg === 'light' 
                ? 'bg-slate-100 border-slate-300' 
                : selectedBg === 'grid' 
                  ? 'bg-[#080A12] border-white/10 bg-[radial-gradient(#8B5CF6_1px,transparent_1px)] [background-size:16px_16px]' 
                  : 'bg-[#080A12] border-white/5'
            }`}>
              {variant.render}
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              <code className="text-[10px] font-mono text-[#22D3EE] truncate max-w-[180px] bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
                {variant.code}
              </code>

              <button
                onClick={() => copyToClipboard(variant.code, variant.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/10 cursor-pointer"
              >
                {copiedId === variant.id ? <Check className="w-3.5 h-3.5 text-[#22C55E]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === variant.id ? 'Copied' : 'Copy JSX'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
