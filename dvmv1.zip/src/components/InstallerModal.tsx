import React, { useState, useEffect } from 'react';
import { 
  X, 
  Terminal, 
  Copy, 
  Check, 
  ShieldCheck, 
  Server, 
  Layers, 
  ExternalLink,
  Zap,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ONE_LINE_INSTALL_COMMAND, INSTALLER_SCRIPT_CONTENT } from '../data/mockData';

interface InstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallerModal: React.FC<InstallerModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'master' | 'worker'>('master');
  const [activeTab, setActiveTab] = useState<'one-line' | 'script-source'>('one-line');

  const customCommand = selectedRole === 'master'
    ? ONE_LINE_INSTALL_COMMAND
    : `curl -sSL https://get.dvm-panel.io/install.sh | sudo bash -s -- --role=worker --master-ip=10.100.0.10`;

  const handleCopyCmd = () => {
    navigator.clipboard.writeText(customCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(INSTALLER_SCRIPT_CONTENT);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl overflow-y-auto">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className="glass-card rounded-[2.5rem] w-full max-w-3xl max-h-[90vh] flex flex-col shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] my-auto overflow-hidden relative"
        >
          {/* Subtle gradient glow behind modal header */}
          <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-[#A855F7]/10 via-[#3B82F6]/10 to-transparent pointer-events-none" />

          {/* Header */}
          <div className="p-8 pb-6 border-b border-[rgba(255,255,255,0.05)] flex items-center justify-between relative z-10">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#A855F7]/20 to-[#3B82F6]/20 border border-[#A855F7]/30 flex items-center justify-center text-[#C084FC] shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <Terminal className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-2xl font-black text-white font-sans tracking-wide">Automated Installer</h2>
                  <span className="text-[10px] font-bold font-sans tracking-widest uppercase bg-[#A855F7]/10 text-[#C084FC] border border-[#A855F7]/20 px-3 py-1.5 rounded-full shadow-sm">
                    v3.2.0 STABLE
                  </span>
                </div>
                <p className="text-sm text-[#A1A1AA] font-medium tracking-wide mt-1">
                  Deploy master controller or hypervisor worker agent.
                </p>
              </div>
            </div>

            <button onClick={onClose} className="p-2.5 text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)] rounded-xl transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Subnav */}
          <div className="flex items-center gap-2 px-8 py-2 bg-[rgba(0,0,0,0.4)] border-b border-[rgba(255,255,255,0.05)]">
            <button
              onClick={() => setActiveTab('one-line')}
              className={`py-3 px-5 text-[11px] font-bold uppercase tracking-widest font-sans rounded-xl transition-all ${
                activeTab === 'one-line'
                  ? 'bg-[#A855F7]/20 text-[#D8B4FE] border border-[#A855F7]/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                  : 'text-[#A1A1AA] hover:text-white border border-transparent'
              }`}
            >
              One-Line Bash

            </button>
            <button
              onClick={() => setActiveTab('script-source')}
              className={`py-3.5 px-3.5 text-xs font-semibold border-b-2 transition-all ${
                activeTab === 'script-source'
                  ? 'border-[#C084FC] text-[#D8B4FE] font-bold'
                  : 'border-transparent text-[#A1A1AA] hover:text-[#E4E4E7]'
              }`}
            >
              View Installer Source Code
            </button>
          </div>

          {/* Body */}
          <div className="p-8 flex-1 overflow-y-auto space-y-8 custom-scrollbar relative z-10">
            {activeTab === 'one-line' ? (
              <div className="space-y-8">
                {/* Role Picker */}
                <div className="space-y-3">
                  <label className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans">
                    Select Deployment Role
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedRole('master')}
                      className={`p-5 rounded-[1.5rem] border cursor-pointer transition-all flex flex-col justify-between group relative overflow-hidden ${
                        selectedRole === 'master'
                          ? 'bg-[#A855F7]/10 border-[#A855F7]/50 text-white shadow-[0_0_20px_rgba(168,85,247,0.15)]'
                          : 'bg-[rgba(0,0,0,0.5)] border-[rgba(255,255,255,0.05)] text-[#A1A1AA] hover:bg-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.1)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 font-bold text-sm text-[#D8B4FE] font-sans tracking-wide">
                        <Server className="w-5 h-5" /> Master Panel
                      </div>
                      <p className="text-[11px] text-[#A1A1AA] mt-2 font-medium tracking-wide leading-relaxed">
                        Full Web UI + API Gateway + KVM Management Plane (Installs on Master Host)
                      </p>
                    </motion.div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedRole('worker')}
                      className={`p-5 rounded-[1.5rem] border cursor-pointer transition-all flex flex-col justify-between group relative overflow-hidden ${
                        selectedRole === 'worker'
                          ? 'bg-[#A855F7]/10 border-[#A855F7]/50 text-white shadow-[0_0_20px_rgba(168,85,247,0.15)]'
                          : 'bg-[rgba(0,0,0,0.5)] border-[rgba(255,255,255,0.05)] text-[#A1A1AA] hover:bg-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.1)]'
                      }`}
                    >
                      <div className="flex items-center gap-3 font-bold text-sm text-[#D8B4FE] font-sans tracking-wide">
                        <Layers className="w-5 h-5" /> Worker Agent
                      </div>
                      <p className="text-[11px] text-[#A1A1AA] mt-2 font-medium tracking-wide leading-relaxed">
                        Bare-metal KVM worker daemon that connects to existing Master Controller
                      </p>
                    </motion.div>
                  </div>
                </div>

                {/* Command Box */}
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-[#C084FC]" /> Terminal Command
                    </span>
                    <span className="text-[10px] text-[#34D399] font-sans font-bold tracking-widest uppercase bg-[#10B981]/10 px-2 py-0.5 rounded shadow-sm">
                      Supports Ubuntu/Debian/Alma
                    </span>
                  </div>

                  <div className="relative group bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.1)] rounded-[1.5rem] p-5 font-mono text-xs sm:text-sm text-[#D8B4FE] flex items-center justify-between gap-4 shadow-inner">
                    <div className="truncate select-all text-[#F4F4F5] font-mono tracking-wide leading-relaxed">
                      <span className="text-[#C084FC] select-none mr-2">$</span>{customCommand}
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(168,85,247,0.4)' }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleCopyCmd}
                      className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-sans font-bold uppercase tracking-widest text-[10px] rounded-xl transition-all shadow-[0_5px_15px_-5px_rgba(168,85,247,0.5)] shrink-0 border border-[rgba(255,255,255,0.1)]"
                    >
                      {copiedCmd ? (
                        <>
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Copy</span>
                        </>
                      )}
                    </motion.button>
                  </div>
                </div>

                {/* Prerequisites Checklist */}
                <div className="bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.5rem] p-6 space-y-4 shadow-inner">
                  <h4 className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#10B981]" /> Automated Workflow
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#D4D4D8] font-sans tracking-wide">
                    <div className="flex items-center gap-3">
                      <Check className="w-4 h-4 text-[#10B981] shrink-0" />
                      <span>Requires Root privileges</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check className="w-4 h-4 text-[#10B981] shrink-0" />
                      <span>Configures Open vSwitch bridge</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check className="w-4 h-4 text-[#10B981] shrink-0" />
                      <span>Enables KVM hardware virtualization</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check className="w-4 h-4 text-[#10B981] shrink-0" />
                      <span>Binds Web UI securely to Port 8443</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center font-sans uppercase tracking-widest font-bold">
                  <span className="text-[11px] text-[#A1A1AA]">install.sh Source Code</span>
                  <button
                    onClick={handleCopyScript}
                    className="flex items-center gap-2 px-4 py-2 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-white text-[10px] rounded-xl transition-colors"
                  >
                    {copiedScript ? <Check className="w-4 h-4 text-[#10B981] stroke-[3]" /> : <Copy className="w-4 h-4" />}
                    <span>Copy Script</span>
                  </button>
                </div>
                <pre className="p-6 bg-[rgba(0,0,0,0.6)] border border-[rgba(255,255,255,0.05)] rounded-[1.5rem] font-mono text-[11px] text-[#D4D4D8] overflow-x-auto max-h-96 leading-loose shadow-inner custom-scrollbar">
                  {INSTALLER_SCRIPT_CONTENT}
                </pre>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
