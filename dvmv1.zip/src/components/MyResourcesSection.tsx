import React from 'react';
import { motion } from 'motion/react';
import { 
  Cpu, 
  Activity, 
  HardDrive, 
  Globe, 
  Wifi, 
  Camera, 
  Archive, 
  ShieldCheck, 
  Zap,
  Layers,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';
import { VMInstance } from '../types';
import { PremiumProgressBar } from './PremiumProgressBar';

interface MyResourcesSectionProps {
  vms: VMInstance[];
}

export const MyResourcesSection: React.FC<MyResourcesSectionProps> = ({ vms }) => {
  const totalVcpu = vms.reduce((acc, v) => acc + v.vcpu, 0);
  const totalRamGB = vms.reduce((acc, v) => acc + v.ramGB, 0);
  const totalDiskGB = vms.reduce((acc, v) => acc + v.diskGB, 0);
  const totalNetworkRx = vms.reduce((acc, v) => acc + v.networkRxMbps, 0);
  const totalNetworkTx = vms.reduce((acc, v) => acc + v.networkTxMbps, 0);
  
  const totalIpv4 = vms.length; // Each VM has 1 IPv4
  const totalIpv6 = vms.length; // Each VM has 1 IPv6
  
  // Estimate total snapshots and backups
  const totalSnapshots = vms.length * 3;
  const totalBackups = vms.filter(v => v.autoBackup).length;

  const avgCpuLoad = vms.length > 0 ? Math.round(vms.reduce((acc, v) => acc + v.cpuUsagePct, 0) / vms.length) : 0;
  const avgRamLoad = vms.length > 0 ? Math.round(vms.reduce((acc, v) => acc + v.ramUsagePct, 0) / vms.length) : 0;
  const avgDiskLoad = vms.length > 0 ? Math.round(vms.reduce((acc, v) => acc + v.diskUsagePct, 0) / vms.length) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight font-sans flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-[#8B5CF6]" />
            <span>My Combined Cloud Resources</span>
          </h2>
          <p className="text-xs text-[#A1A1AA] mt-1 font-medium">
            Aggregated infrastructure capacity and real-time usage metrics across all owned instances
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 text-[#D8B4FE] text-xs font-mono font-bold shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#22D3EE]" />
          <span>Real-time Hardware Metering</span>
        </div>
      </div>

      {/* Main Aggregated Resources Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* vCPU Capacity Card */}
        <div className="glass-card rounded-[2rem] p-6 relative overflow-hidden group hover:border-[#8B5CF6]/40 transition-all duration-500">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#A1A1AA] uppercase tracking-wider">Total vCPU Cores</span>
            <div className="p-2.5 rounded-2xl bg-[#8B5CF6]/15 text-[#C084FC] border border-[#8B5CF6]/30 shadow-sm">
              <Cpu className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black font-mono text-white tracking-tight">
            {totalVcpu} <span className="text-xs font-normal text-[#A1A1AA]">vCPUs</span>
          </div>
          <div className="mt-4">
            <PremiumProgressBar value={avgCpuLoad} label="Avg Cluster Load" showValue size="sm" color="purple" />
          </div>
        </div>

        {/* RAM DDR5 Capacity Card */}
        <div className="glass-card rounded-[2rem] p-6 relative overflow-hidden group hover:border-[#3B82F6]/40 transition-all duration-500">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#A1A1AA] uppercase tracking-wider">Total DDR5 RAM</span>
            <div className="p-2.5 rounded-2xl bg-[#3B82F6]/15 text-[#60A5FA] border border-[#3B82F6]/30 shadow-sm">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black font-mono text-white tracking-tight">
            {totalRamGB} <span className="text-xs font-normal text-[#A1A1AA]">GB</span>
          </div>
          <div className="mt-4">
            <PremiumProgressBar value={avgRamLoad} label="Allocated Memory" showValue size="sm" color="blue" />
          </div>
        </div>

        {/* NVMe Storage Capacity Card */}
        <div className="glass-card rounded-[2rem] p-6 relative overflow-hidden group hover:border-[#22D3EE]/40 transition-all duration-500">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#A1A1AA] uppercase tracking-wider">NVMe RAID-10</span>
            <div className="p-2.5 rounded-2xl bg-[#22D3EE]/15 text-[#22D3EE] border border-[#22D3EE]/30 shadow-sm">
              <HardDrive className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black font-mono text-white tracking-tight">
            {totalDiskGB} <span className="text-xs font-normal text-[#A1A1AA]">GB Pool</span>
          </div>
          <div className="mt-4">
            <PremiumProgressBar value={avgDiskLoad} label="Disk Provisioned" showValue size="sm" color="emerald" />
          </div>
        </div>

        {/* Bandwidth & Network Traffic Card */}
        <div className="glass-card rounded-[2rem] p-6 relative overflow-hidden group hover:border-[#10B981]/40 transition-all duration-500">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#A1A1AA] uppercase tracking-wider">Network Bandwidth</span>
            <div className="p-2.5 rounded-2xl bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30 shadow-sm">
              <Wifi className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black font-mono text-white tracking-tight">
            {totalNetworkRx + totalNetworkTx} <span className="text-xs font-normal text-[#A1A1AA]">Mbps</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
            <span>Rx: {totalNetworkRx} Mbps</span>
            <span>Tx: {totalNetworkTx} Mbps</span>
          </div>
        </div>
      </div>

      {/* Secondary Resource Allocation Cards (IPs, Snapshots, Backups) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-[#8B5CF6]/10 text-[#C084FC]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase font-sans">IP Addresses Allocated</div>
              <div className="text-sm font-mono text-[#A1A1AA] mt-0.5">{totalIpv4} Public IPv4 • {totalIpv6} Routed IPv6</div>
            </div>
          </div>
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#10B981]/10 text-[#10B981] rounded-full border border-[#10B981]/20">Active</span>
        </div>

        <div className="p-5 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-[#3B82F6]/10 text-[#60A5FA]">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase font-sans">ZFS Snapshots</div>
              <div className="text-sm font-mono text-[#A1A1AA] mt-0.5">{totalSnapshots} Active Recovery Points</div>
            </div>
          </div>
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#3B82F6]/10 text-[#3B82F6] rounded-full border border-[#3B82F6]/20">Protected</span>
        </div>

        <div className="p-5 rounded-2xl bg-[rgba(10,13,22,0.6)] border border-[rgba(255,255,255,0.06)] backdrop-blur-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-[#22D3EE]/10 text-[#22D3EE]">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase font-sans">Automated Backups</div>
              <div className="text-sm font-mono text-[#A1A1AA] mt-0.5">{totalBackups} / {vms.length} VMs Schedule Enabled</div>
            </div>
          </div>
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#22D3EE]/10 text-[#22D3EE] rounded-full border border-[#22D3EE]/20">Daily Sync</span>
        </div>
      </div>
    </div>
  );
};
