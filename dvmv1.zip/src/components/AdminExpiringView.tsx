import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldAlert, 
  Search, 
  Filter, 
  MoreVertical, 
  Play, 
  Square, 
  Trash2, 
  Clock, 
  CalendarDays,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { VMInstance } from '../types';
import { VmTableSkeleton } from './DashboardSkeleton';

interface AdminExpiringViewProps {
  vms: VMInstance[];
  onVMAction: (vmId: string, action: 'start' | 'stop' | 'reboot' | 'pause' | 'delete') => void;
  onRenewVM?: (vmId: string, days: number) => void;
  isLoading?: boolean;
}

export const AdminExpiringView: React.FC<AdminExpiringViewProps> = ({ vms, onVMAction, onRenewVM, isLoading = false }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'expired' | 'expiring-soon' | 'active'>('all');

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <VmTableSkeleton rows={6} />
      </motion.div>
    );
  }
  
  // Calculate expiry status for all VMs
  const vmsWithExpiry = vms.map(vm => {
    let remainingDays = 0;
    let isExpired = false;
    let statusCategory = 'active';
    
    if (vm.expiryDate) {
      const expiry = new Date(vm.expiryDate).getTime();
      const now = Date.now();
      const diff = expiry - now;
      remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
      
      if (remainingDays <= 0) {
        isExpired = true;
        statusCategory = 'expired';
        remainingDays = 0;
      } else if (remainingDays <= 7) {
        statusCategory = 'expiring-soon';
      }
    } else {
        statusCategory = 'no-expiry';
    }
    
    return { ...vm, remainingDays, isExpired, statusCategory };
  }).filter(vm => vm.statusCategory !== 'no-expiry');
  
  const filteredVMs = vmsWithExpiry.filter(vm => {
    const matchesSearch = vm.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          vm.vmid.toString().includes(searchQuery);
    
    if (filterStatus === 'all') return matchesSearch;
    return matchesSearch && vm.statusCategory === filterStatus;
  }).sort((a, b) => a.remainingDays - b.remainingDays);
  
  const expiredCount = vmsWithExpiry.filter(v => v.isExpired).length;
  const expiringSoonCount = vmsWithExpiry.filter(v => v.statusCategory === 'expiring-soon').length;

  return (
    <div className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 bg-[rgba(10,13,22,0.6)] backdrop-blur-2xl p-6 lg:p-8 rounded-[2rem] border border-[rgba(255,255,255,0.05)] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="relative z-10">
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <ShieldAlert className="w-6 h-6 text-rose-500 drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]" />
            VPS Expiry Management
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
            Monitor and manage expiring and expired virtual machine instances across the cluster
          </p>
        </div>
        
        <div className="flex items-center gap-4 relative z-10">
           <div className="px-5 py-3 rounded-2xl bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.05)] flex items-center gap-4">
             <div className="flex flex-col">
               <span className="text-[10px] uppercase font-bold tracking-widest text-[#A1A1AA]">Expired</span>
               <span className="text-xl font-black text-rose-500">{expiredCount}</span>
             </div>
             <div className="w-px h-8 bg-[rgba(255,255,255,0.1)]" />
             <div className="flex flex-col">
               <span className="text-[10px] uppercase font-bold tracking-widest text-[#A1A1AA]">Expiring &lt;7d</span>
               <span className="text-xl font-black text-amber-500">{expiringSoonCount}</span>
             </div>
           </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-[rgba(10,13,22,0.4)] p-4 rounded-2xl border border-[rgba(255,255,255,0.03)]">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA]" />
          <input
            type="text"
            placeholder="Search by VM name or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.1)] rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-[#A1A1AA] outline-none focus:border-[#A855F7]/50 transition-all shadow-inner"
          />
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.1)] rounded-xl p-1 shadow-inner w-full sm:w-auto">
            <button 
              onClick={() => setFilterStatus('all')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all flex-1 sm:flex-none ${filterStatus === 'all' ? 'bg-[#A855F7]/20 text-[#D8B4FE]' : 'text-[#A1A1AA] hover:text-white'}`}
            >
              All
            </button>
            <button 
              onClick={() => setFilterStatus('expiring-soon')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all flex-1 sm:flex-none ${filterStatus === 'expiring-soon' ? 'bg-amber-500/20 text-amber-400' : 'text-[#A1A1AA] hover:text-white'}`}
            >
              Warning
            </button>
            <button 
              onClick={() => setFilterStatus('expired')}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all flex-1 sm:flex-none ${filterStatus === 'expired' ? 'bg-rose-500/20 text-rose-400' : 'text-[#A1A1AA] hover:text-white'}`}
            >
              Expired
            </button>
          </div>
        </div>
      </div>
      
      {/* List */}
      <div className="glass-panel rounded-[1.5rem] overflow-hidden shadow-inner">
        <table className="w-full text-left text-sm font-sans tracking-wide">
          <thead className="bg-[rgba(0,0,0,0.5)] text-[#A1A1AA] uppercase font-bold text-[10px] tracking-widest border-b border-[rgba(255,255,255,0.05)]">
            <tr>
              <th className="p-5 font-bold">Instance</th>
              <th className="p-5 font-bold">Power State</th>
              <th className="p-5 font-bold">Expiry Date</th>
              <th className="p-5 font-bold">Remaining Time</th>
              <th className="p-5 font-bold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[rgba(255,255,255,0.05)] text-[#E4E4E7]">
            {filteredVMs.map((vm) => {
              
              let statusColor = 'text-[#10B981]';
              let statusBg = 'bg-[#10B981]/10 border-[#10B981]/20';
              let statusText = 'Active';
              
              if (vm.isExpired) {
                statusColor = 'text-gray-400';
                statusBg = 'bg-gray-400/10 border-gray-400/20';
                statusText = 'Expired';
              } else if (vm.remainingDays <= 3) {
                statusColor = 'text-rose-500';
                statusBg = 'bg-rose-500/10 border-rose-500/20';
                statusText = 'Critical';
              } else if (vm.remainingDays <= 7) {
                statusColor = 'text-amber-500';
                statusBg = 'bg-amber-500/10 border-amber-500/20';
                statusText = 'Expiring Soon';
              }

              return (
                <motion.tr 
                  key={vm.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="hover:bg-[rgba(255,255,255,0.02)] transition-colors group"
                >
                  <td className="p-5">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${vm.isExpired ? 'from-gray-500/20 to-gray-700/20 border-gray-500/30 text-gray-400' : 'from-[#A855F7]/20 to-[#3B82F6]/20 border-[#A855F7]/30 text-[#C084FC]'} border flex items-center justify-center font-mono font-bold text-sm shrink-0 shadow-inner`}>
                        {vm.vmid}
                      </div>
                      <div>
                        <div className="font-bold text-white tracking-wide">{vm.name}</div>
                        <div className="text-xs text-[#A1A1AA] font-mono mt-0.5">{vm.ipAddress}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-5">
                     <span className={`inline-flex items-center gap-1.5 text-[10px] font-sans tracking-widest uppercase font-bold px-2.5 py-1 rounded-full shadow-sm border ${
                        vm.status === 'running' ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20' : 
                        vm.status === 'suspended' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                        'bg-gray-500/10 text-gray-400 border-gray-500/20'
                      }`}>
                        {vm.status === 'running' ? <Play className="w-3 h-3" /> : vm.status === 'suspended' ? <Square className="w-3 h-3" /> : <Square className="w-3 h-3" />}
                        {vm.status}
                      </span>
                  </td>
                  <td className="p-5">
                    <div className="flex items-center gap-2 text-[#A1A1AA]">
                      <CalendarDays className="w-4 h-4 text-[#8B5CF6]" />
                      <span className="font-mono text-xs">{new Date(vm.expiryDate!).toLocaleDateString()}</span>
                    </div>
                  </td>
                  <td className="p-5">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2">
                        <Clock className={`w-4 h-4 ${statusColor}`} />
                        <span className={`font-black font-mono text-sm ${statusColor}`}>{vm.remainingDays} Days</span>
                      </div>
                      <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded border inline-block w-max ${statusBg} ${statusColor}`}>
                        {statusText}
                      </span>
                    </div>
                  </td>
                  <td className="p-5 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {vm.isExpired && vm.status === 'running' && (
                        <button
                           onClick={() => onVMAction(vm.id, 'pause')}
                           className="p-2 text-amber-500 hover:bg-amber-500/10 border border-transparent hover:border-amber-500/20 rounded-xl transition-all"
                           title="Force Suspend"
                        >
                          <AlertTriangle className="w-4 h-4" />
                        </button>
                      )}
                      
                      {vm.isExpired && (
                        <button
                          onClick={() => onVMAction(vm.id, 'delete')}
                          className="p-2 text-rose-500 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 rounded-xl transition-all"
                          title="Terminate Instance"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        onClick={() => onRenewVM && onRenewVM(vm.id, 30)}
                        className="px-4 py-2 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#E4E4E7] font-bold text-xs uppercase tracking-widest rounded-xl transition-colors border border-[rgba(255,255,255,0.1)] flex items-center gap-2"
                      >
                        <RefreshCw className="w-3 h-3" /> Renew 30D
                      </button>
                    </div>
                  </td>
                </motion.tr>
              );
            })}
            
            {filteredVMs.length === 0 && (
              <tr>
                <td colSpan={5} className="p-16 text-center text-[#A1A1AA]">
                  <div className="flex flex-col items-center justify-center gap-3">
                    <ShieldAlert className="w-12 h-12 text-[#A1A1AA]/30" />
                    <p className="font-sans text-sm tracking-wide">No VMs matching the current expiry criteria.</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
