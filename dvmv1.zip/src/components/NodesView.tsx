import React, { useState } from 'react';
import { 
  Cpu, 
  HardDrive, 
  Server, 
  Activity, 
  Plus, 
  Terminal, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw,
  Globe,
  MoreVertical,
  ShieldAlert,
  Zap,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';
import { HypervisorNode } from '../types';
import { NodeListSkeleton } from './DashboardSkeleton';

interface NodesViewProps {
  nodes: HypervisorNode[];
  onOpenInstaller: () => void;
  isLoading?: boolean;
}

export const NodesView: React.FC<NodesViewProps> = ({ nodes, onOpenInstaller, isLoading = false }) => {
  const [nodeList, setNodeList] = useState<HypervisorNode[]>(nodes);

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <NodeListSkeleton count={3} />
      </motion.div>
    );
  }

  const toggleMaintenance = (id: string) => {
    setNodeList((prev) =>
      prev.map((n) =>
        n.id === id
          ? { ...n, status: n.status === 'maintenance' ? 'online' : 'maintenance' }
          : n
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 glass-panel p-6 lg:p-8 rounded-[2.5rem] shadow-xl">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
            <Cpu className="w-6 h-6 text-[#A855F7] drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
            Hypervisor Compute Nodes
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
            Physical bare-metal KVM/QEMU hypervisor hosts managed by the controller.
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139,92,246,0.3)' }}
          whileTap={{ scale: 0.98 }}
          onClick={onOpenInstaller}
          className="flex items-center gap-2.5 px-6 py-3 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-sm rounded-2xl shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] border border-[rgba(255,255,255,0.1)] transition-all"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span className="tracking-wide">Add Node (1-Line Command)</span>
        </motion.button>
      </div>

      {/* Nodes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {nodeList.map((node) => {
          const ramPct = Math.round((node.usedRamGB / node.totalRamGB) * 100);
          const vcpuPct = Math.round((node.usedVcpu / node.totalVcpu) * 100);
          const storagePct = Math.round((node.usedStorageTB / node.totalStorageTB) * 100);

          return (
            <motion.div
              key={node.id}
              whileHover={{ y: -4, scale: 1.01 }}
              className="group glass-card rounded-[1.5rem] p-6 flex flex-col justify-between space-y-5 hover:shadow-[0_15px_40px_-10px_rgba(0,0,0,0.5)] transition-all duration-500"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[rgba(255,255,255,0.03)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              
              {/* Card Top Header */}
              <div className="relative z-10">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="font-black text-lg text-white tracking-wide">{node.name}</span>
                      {node.status === 'online' && (
                        <span className="flex items-center gap-1.5 text-[10px] font-bold text-[#10B981] bg-[#10B981]/10 px-2.5 py-1 rounded-full border border-[#10B981]/20 font-sans tracking-widest uppercase shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse shadow-[0_0_5px_rgba(16,185,129,0.8)]" />
                          ONLINE
                        </span>
                      )}
                      {node.status === 'degraded' && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-[#F59E0B] bg-[#F59E0B]/10 px-2.5 py-1 rounded-full border border-[#F59E0B]/20 font-sans tracking-widest uppercase shadow-sm">
                          <AlertTriangle className="w-3 h-3" />
                          DEGRADED
                        </span>
                      )}
                      {node.status === 'maintenance' && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-[#A855F7] bg-[#A855F7]/10 px-2.5 py-1 rounded-full border border-[#A855F7]/20 font-sans tracking-widest uppercase shadow-sm">
                          MAINTENANCE
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-[#A1A1AA] mt-2 flex items-center gap-2 font-mono">
                      <Globe className="w-3.5 h-3.5 text-[#71717A]" />
                      <span>{node.region}</span>
                      <span className="text-[rgba(255,255,255,0.2)]">•</span>
                      <span className="text-[#C084FC] font-bold">{node.ipAddress}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleMaintenance(node.id)}
                    className="px-3 py-1.5 text-[#A1A1AA] hover:text-white bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.1)] rounded-xl text-[10px] font-bold font-sans uppercase tracking-widest hover:border-[#A855F7]/40 transition-colors shadow-sm"
                    title="Toggle Maintenance Mode"
                  >
                    Maint
                  </button>
                </div>

                <div className="mt-5 pt-4 border-t border-[rgba(255,255,255,0.05)] text-[11px] text-[#A1A1AA] space-y-2 font-sans tracking-wide">
                  <div className="flex justify-between">
                    <span>Active Virtual Machines:</span>
                    <span className="text-white font-bold">{node.vmCount} VMs</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Hypervisor Kernel:</span>
                    <span className="text-[#E4E4E7]">{node.kvmVersion}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Node Uptime:</span>
                    <span className="text-[#10B981] font-bold">{node.uptimeDays} days</span>
                  </div>
                </div>
              </div>

              {/* Resource Meters */}
              <div className="space-y-4 pt-3 relative z-10">
                {/* vCPU */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA]">
                    <span>vCPU Cores</span>
                    <span className="text-[#C084FC]">
                      {node.usedVcpu} / {node.totalVcpu} ({vcpuPct}%)
                    </span>
                  </div>
                  <div className="w-full bg-[rgba(0,0,0,0.4)] h-1.5 rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
                    <div className="bg-gradient-to-r from-[#A855F7] to-[#3B82F6] h-full rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)] transition-all duration-500" style={{ width: `${vcpuPct}%` }} />
                  </div>
                </div>

                {/* RAM */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA]">
                    <span>RAM Memory</span>
                    <span className="text-[#C084FC]">
                      {node.usedRamGB} / {node.totalRamGB} GB ({ramPct}%)
                    </span>
                  </div>
                  <div className="w-full bg-[rgba(0,0,0,0.4)] h-1.5 rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
                    <div className="bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] h-full rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)] transition-all duration-500" style={{ width: `${ramPct}%` }} />
                  </div>
                </div>

                {/* Storage */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA]">
                    <span>Local NVMe Pool</span>
                    <span className="text-[#10B981]">
                      {node.usedStorageTB} / {node.totalStorageTB} TB ({storagePct}%)
                    </span>
                  </div>
                  <div className="w-full bg-[rgba(0,0,0,0.4)] h-1.5 rounded-full overflow-hidden border border-[rgba(255,255,255,0.05)] shadow-inner">
                    <div className="bg-gradient-to-r from-[#10B981] to-[#14B8A6] h-full rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)] transition-all duration-500" style={{ width: `${storagePct}%` }} />
                  </div>
                </div>
              </div>

              {/* Card Footer Load Avg */}
              <div className="pt-4 border-t border-[rgba(255,255,255,0.05)] flex items-center justify-between text-[11px] font-sans font-bold tracking-wider uppercase text-[#A1A1AA] relative z-10">
                <span>Load Avg (1/5/15m):</span>
                <span className="text-[#E4E4E7]">
                  {node.loadAverage.join(', ')}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
