import React, { useState, useEffect } from 'react';
import { 
  X, 
  Cpu, 
  HardDrive, 
  Server, 
  Plus, 
  Check, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  Database,
  Sliders,
  Terminal,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { OS_TEMPLATES, INITIAL_NODES } from '../data/mockData';

interface CreateVMModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateVM: (vmData: {
    name: string;
    osId: string;
    node: string;
    vcpu: number;
    ramGB: number;
    diskGB: number;
    tags: string[];
    autoBackup: boolean;
  }) => void;
}

export const CreateVMModal: React.FC<CreateVMModalProps> = ({
  isOpen,
  onClose,
  onCreateVM,
}) => {
  const [name, setName] = useState('');
  const [selectedOsId, setSelectedOsId] = useState(OS_TEMPLATES[0].id);
  const [node, setNode] = useState(INITIAL_NODES[0].name);
  const [vcpu, setVcpu] = useState(4);
  const [ramGB, setRamGB] = useState(8);
  const [diskGB, setDiskGB] = useState(80);
  const [tagsInput, setTagsInput] = useState('production, web');
  const [autoBackup, setAutoBackup] = useState(true);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    onCreateVM({
      name: name.trim(),
      osId: selectedOsId,
      node,
      vcpu,
      ramGB,
      diskGB,
      tags,
      autoBackup,
    });

    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className="glass-card rounded-[2.5rem] w-full max-w-2xl max-h-[90vh] flex flex-col shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] my-auto overflow-hidden relative"
        >
          {/* Subtle gradient glow behind modal header */}
          <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-[#8B5CF6]/10 via-[#3B82F6]/10 to-transparent pointer-events-none" />

          {/* Modal Header */}
          <div className="p-8 pb-6 border-b border-[rgba(255,255,255,0.05)] flex items-center justify-between relative z-10">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#A855F7]/20 to-[#3B82F6]/20 border border-[#A855F7]/30 flex items-center justify-center text-[#C084FC] shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <Plus className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-white font-sans tracking-wide">
                  Provision Instance
                </h2>
                <p className="text-sm text-[#A1A1AA] font-medium tracking-wide mt-1">
                  Configure and deploy a new virtual machine.
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2.5 text-[#A1A1AA] hover:text-white hover:bg-[rgba(255,255,255,0.05)] rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Form Body */}
          <form onSubmit={handleSubmit} className="p-8 space-y-8 overflow-y-auto flex-1 custom-scrollbar relative z-10">
            {/* Instance Name Input */}
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#A855F7]" /> Instance Identity
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. 'vm-prod-k8s-master-01'"
                className="w-full bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] px-5 py-3.5 text-sm text-white placeholder-[#71717A] font-sans tracking-wide outline-none focus:border-[#A855F7]/50 focus:shadow-[0_0_15px_rgba(168,85,247,0.15)] transition-all shadow-inner"
              />
            </div>

            {/* Operating System Picker Grid */}
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#A855F7]" /> Select OS Image
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {OS_TEMPLATES.map((tmpl) => {
                  const isSelected = selectedOsId === tmpl.id;
                  return (
                    <motion.div
                      key={tmpl.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedOsId(tmpl.id)}
                      className={`p-4 rounded-[1.25rem] border cursor-pointer transition-all flex items-start gap-4 relative group ${
                        isSelected
                          ? 'bg-[#A855F7]/10 border-[#A855F7]/50 text-white shadow-[0_0_20px_rgba(168,85,247,0.15)]'
                          : 'bg-[rgba(0,0,0,0.4)] border-[rgba(255,255,255,0.05)] text-[#A1A1AA] hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.1)]'
                      }`}
                    >
                      <div className="text-3xl filter drop-shadow-md">{tmpl.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm text-white truncate font-sans tracking-wide">{tmpl.name}</div>
                        <div className="text-[10px] text-[#A1A1AA] font-mono mt-1.5 truncate uppercase tracking-widest">
                          {tmpl.category}
                        </div>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#C084FC] text-black flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(168,85,247,0.8)]">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Hardware Resources Sliders */}
            <div className="space-y-6 glass-panel p-6 rounded-[1.5rem] shadow-inner relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#A855F7]/5 rounded-full blur-3xl pointer-events-none" />
              
              <h3 className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center justify-between relative z-10">
                <span className="flex items-center gap-2"><Sliders className="w-4 h-4 text-[#10B981]" /> Hardware Allocation</span>
                <span className="text-[#C084FC]">Live Quota Check</span>
              </h3>

              {/* vCPU */}
              <div className="space-y-2 relative z-10">
                <div className="flex justify-between text-xs font-sans tracking-wide">
                  <span className="text-[#A1A1AA]">vCPU Cores</span>
                  <span className="text-[#C084FC] font-bold bg-[#A855F7]/10 px-2 py-0.5 rounded text-[10px]">{vcpu} Cores</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={32}
                  value={vcpu}
                  onChange={(e) => setVcpu(parseInt(e.target.value))}
                  className="w-full accent-[#C084FC] bg-[rgba(255,255,255,0.05)] h-2 rounded-lg cursor-pointer"
                />
              </div>

              {/* RAM */}
              <div className="space-y-2 relative z-10">
                <div className="flex justify-between text-xs font-sans tracking-wide">
                  <span className="text-[#A1A1AA]">Memory (RAM)</span>
                  <span className="text-[#C084FC] font-bold bg-[#A855F7]/10 px-2 py-0.5 rounded text-[10px]">{ramGB} GB</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={128}
                  value={ramGB}
                  onChange={(e) => setRamGB(parseInt(e.target.value))}
                  className="w-full accent-[#C084FC] bg-[rgba(255,255,255,0.05)] h-2 rounded-lg cursor-pointer"
                />
              </div>

              {/* Disk */}
              <div className="space-y-2 relative z-10">
                <div className="flex justify-between text-xs font-sans tracking-wide">
                  <span className="text-[#A1A1AA]">NVMe Storage</span>
                  <span className="text-[#10B981] font-bold bg-[#10B981]/10 px-2 py-0.5 rounded text-[10px]">{diskGB} GB</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={1000}
                  step={10}
                  value={diskGB}
                  onChange={(e) => setDiskGB(parseInt(e.target.value))}
                  className="w-full accent-[#10B981] bg-[rgba(255,255,255,0.05)] h-2 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Target Node & Tags */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 relative z-10">
              {/* Target Hypervisor Node */}
              <div className="space-y-3">
                <label className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                  <Server className="w-4 h-4 text-[#3B82F6]" /> Target Node
                </label>
                <select
                  value={node}
                  onChange={(e) => setNode(e.target.value)}
                  className="w-full bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] px-5 py-3.5 text-sm text-white font-sans tracking-wide outline-none focus:border-[#A855F7]/50 transition-all appearance-none shadow-inner"
                >
                  {INITIAL_NODES.map((n) => (
                    <option key={n.id} value={n.name} className="bg-[#050509] text-white">
                      {n.name} ({n.region}) - {n.totalRamGB - n.usedRamGB} GB Free
                    </option>
                  ))}
                </select>
              </div>

              {/* Tags Input */}
              <div className="space-y-3">
                <label className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-widest font-sans flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#A855F7]" /> Instance Tags
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="e.g. web, prod, k8s"
                  className="w-full bg-[rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.05)] rounded-[1.25rem] px-5 py-3.5 text-sm text-white placeholder-[#71717A] font-sans tracking-wide outline-none focus:border-[#A855F7]/50 transition-all shadow-inner"
                />
              </div>
            </div>

            {/* ZFS Auto Snapshot Checkbox */}
            <div className="flex items-center gap-3 p-4 glass-panel rounded-[1.25rem] relative z-10 hover:border-[#A855F7]/30 transition-colors shadow-inner cursor-pointer" onClick={() => setAutoBackup(!autoBackup)}>
              <div className={`w-5 h-5 rounded flex items-center justify-center border transition-all ${autoBackup ? 'bg-[#A855F7] border-[#C084FC] shadow-[0_0_10px_rgba(168,85,247,0.5)]' : 'bg-[rgba(0,0,0,0.5)] border-[rgba(255,255,255,0.1)]'}`}>
                {autoBackup && <Check className="w-3.5 h-3.5 text-black stroke-[3]" />}
              </div>
              <label className="text-sm text-[#D4D4D8] font-sans tracking-wide cursor-pointer flex-1 select-none">
                Enable Automated Nightly ZFS Storage Snapshots
              </label>
            </div>

            {/* Form Footer Action */}
            <div className="pt-6 border-t border-[rgba(255,255,255,0.05)] flex flex-col sm:flex-row justify-end gap-4 relative z-10">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 rounded-xl bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[#D4D4D8] text-xs font-bold font-sans tracking-wide uppercase transition-colors"
              >
                Cancel
              </button>
              <motion.button
                whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139,92,246,0.4)' }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="flex items-center justify-center gap-2.5 px-8 py-3 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#60A5FA] text-white font-bold text-sm rounded-xl shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] border border-[rgba(255,255,255,0.1)] transition-all uppercase tracking-wide font-sans"
              >
                <Zap className="w-4 h-4 fill-white" />
                <span>Deploy Instance</span>
              </motion.button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
