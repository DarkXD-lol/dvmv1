import React, { useState } from 'react';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PremiumProgressBar } from './PremiumProgressBar';
import { useTheme } from '../context/ThemeContext';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  subValue?: string;
  icon: LucideIcon;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  change?: string;
  changePositive?: boolean;
  color?: 'cyan' | 'purple' | 'emerald' | 'blue' | 'amber';
  progressPct?: number;
  progress?: number;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  subValue,
  icon: Icon,
  trend,
  change,
  changePositive = true,
  color = 'cyan',
  progressPct,
  progress,
}) => {
  const { theme } = useTheme();
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  const displaySubtitle = subtitle || subValue;
  const displayProgress = progressPct !== undefined ? progressPct : progress;
  const displayTrend = trend || (change ? { value: change, isPositive: changePositive } : undefined);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setMousePos(null);
  };

  // Color mappings
  const colorMap = {
    cyan: {
      hex: theme.accentColor || '#22D3EE',
      border: 'hover:border-[#22D3EE]/50',
      glowShadow: 'group-hover:shadow-[0_15px_40px_-10px_rgba(34,211,238,0.25)]',
      bgIcon: 'bg-[#22D3EE]/10 border-[#22D3EE]/20 text-[#22D3EE] group-hover:bg-[#22D3EE]/20',
    },
    purple: {
      hex: theme.primaryColor || '#8B5CF6',
      border: 'hover:border-[#A855F7]/50',
      glowShadow: 'group-hover:shadow-[0_15px_40px_-10px_rgba(168,85,247,0.25)]',
      bgIcon: 'bg-[#A855F7]/10 border-[#A855F7]/20 text-[#A855F7] group-hover:bg-[#A855F7]/20',
    },
    emerald: {
      hex: theme.successColor || '#10B981',
      border: 'hover:border-[#10B981]/50',
      glowShadow: 'group-hover:shadow-[0_15px_40px_-10px_rgba(16,185,129,0.25)]',
      bgIcon: 'bg-[#10B981]/10 border-[#10B981]/20 text-[#10B981] group-hover:bg-[#10B981]/20',
    },
    blue: {
      hex: theme.secondaryColor || '#3B82F6',
      border: 'hover:border-[#3B82F6]/50',
      glowShadow: 'group-hover:shadow-[0_15px_40px_-10px_rgba(59,130,246,0.25)]',
      bgIcon: 'bg-[#3B82F6]/10 border-[#3B82F6]/20 text-[#3B82F6] group-hover:bg-[#3B82F6]/20',
    },
    amber: {
      hex: theme.warningColor || '#F59E0B',
      border: 'hover:border-[#F59E0B]/50',
      glowShadow: 'group-hover:shadow-[0_15px_40px_-10px_rgba(245,158,11,0.25)]',
      bgIcon: 'bg-[#F59E0B]/10 border-[#F59E0B]/20 text-[#F59E0B] group-hover:bg-[#F59E0B]/20',
    },
  }[color];

  const currentGlowHex = colorMap.hex;

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.01 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`relative overflow-hidden glass-card p-6 transition-all duration-300 group rounded-[1.75rem] border border-[rgba(255,255,255,0.06)] ${colorMap.border} ${colorMap.glowShadow}`}
    >
      {/* Interactive Mouse-Following Radial Gradient Glow */}
      <AnimatePresence>
        {isHovered && mousePos && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="pointer-events-none absolute inset-0 z-0 overflow-hidden rounded-[inherit]"
          >
            {/* Outer soft ambient halo */}
            <div
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full blur-2xl transition-all duration-75"
              style={{
                left: `${mousePos.x}px`,
                top: `${mousePos.y}px`,
                width: '320px',
                height: '320px',
                background: `radial-gradient(circle, ${currentGlowHex} 0%, transparent 70%)`,
                opacity: (theme.glowIntensity / 100) * 0.35,
              }}
            />
            {/* Inner sharper glow beam */}
            <div
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full blur-xl transition-all duration-75"
              style={{
                left: `${mousePos.x}px`,
                top: `${mousePos.y}px`,
                width: '180px',
                height: '180px',
                background: `radial-gradient(circle, ${currentGlowHex} 0%, transparent 60%)`,
                opacity: (theme.glowIntensity / 100) * 0.45,
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Static corner ambient fallback glow */}
      <div
        className="absolute -top-16 -right-16 w-44 h-44 rounded-full blur-3xl opacity-0 group-hover:opacity-40 transition-opacity duration-500 pointer-events-none"
        style={{
          background: `radial-gradient(circle, ${currentGlowHex} 0%, transparent 70%)`,
        }}
      />

      {/* Content Layer */}
      <div className="flex items-start justify-between gap-3 relative z-10">
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold text-[#A1A1AA] tracking-widest font-sans uppercase">
            {title}
          </span>
          <div className="text-3xl font-black text-white tracking-tight drop-shadow-sm font-sans">
            {value}
          </div>
        </div>

        <div className={`p-3 rounded-[1rem] border ${colorMap.bgIcon} shadow-sm shrink-0 transition-colors duration-300`}>
          <Icon className="w-6 h-6 drop-shadow-sm" />
        </div>
      </div>

      {/* Progress Line or Subtitle */}
      {displayProgress !== undefined ? (
        <div className="mt-6 relative z-10">
          <PremiumProgressBar 
            value={displayProgress} 
            label={displaySubtitle || 'Capacity Utilization'}
            className="w-full"
          />
        </div>
      ) : displaySubtitle ? (
        <div className="mt-6 flex items-center justify-between text-[11px] text-[#A1A1AA] font-sans tracking-wide relative z-10 pt-3 border-t border-[rgba(255,255,255,0.05)]">
          <span className="uppercase font-bold tracking-widest">{displaySubtitle}</span>
          {displayTrend && (
            <span
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border ${
                displayTrend.isPositive
                  ? 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20 shadow-[0_0_10px_rgba(16,185,129,0.15)]'
                  : 'bg-[#F43F5E]/10 text-[#F43F5E] border-[#F43F5E]/20 shadow-[0_0_10px_rgba(244,63,94,0.15)]'
              }`}
            >
              {displayTrend.isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span className="font-bold tracking-widest uppercase">{displayTrend.value}</span>
            </span>
          )}
        </div>
      ) : null}
    </motion.div>
  );
};
