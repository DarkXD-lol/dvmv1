import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Wifi, 
  Plus, 
  Terminal, 
  ShieldCheck, 
  Activity, 
  Boxes,
  Zap,
  Layers,
  Sparkles,
  Lock,
  ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ViewTab, 
  VMInstance, 
  HypervisorNode, 
  VMSnapshot, 
  ActivityLog, 
  ClusterStats,
  AlertThresholdSettings
} from './types';
import { 
  INITIAL_STATS, 
  INITIAL_VMS, 
  INITIAL_NODES, 
  INITIAL_SNAPSHOTS, 
  INITIAL_LOGS, 
  CURRENT_USER,
  OS_TEMPLATES
} from './data/mockData';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { StatCard } from './components/StatCard';
import { MetricsChart } from './components/Charts';
import { VMList } from './components/VMList';
import { VMDetailModal } from './components/VMDetailModal';
import { CreateVMModal } from './components/CreateVMModal';
import { NodesView } from './components/NodesView';
import { NetworkingView } from './components/NetworkingView';
import { StorageView } from './components/StorageView';
import { InstallerModal } from './components/InstallerModal';
import { WebConsoleModal } from './components/WebConsoleModal';
import { SettingsView } from './components/SettingsView';
import { LogsView } from './components/LogsView';
import { NotificationToast } from './components/NotificationToast';
import { LoginView } from './components/LoginView';
import { AlertThresholdsCard, AlertThresholdsModal } from './components/AlertThresholdsModal';
import { UserDashboardView } from './components/UserDashboardView';
import { VPSActionOverlay, VPSActionType } from './components/VPSActionOverlay';
import { AdminExpiringView } from './components/AdminExpiringView';
import { GlobalInfrastructureView } from './components/GlobalInfrastructureView';
import { ScheduledTasksView } from './components/ScheduledTasksView';
import { BroadcastCenterView } from './components/BroadcastCenterView';
import { MaintenanceManagerView } from './components/MaintenanceManagerView';
import { UserSettingsView } from './components/UserSettingsView';
import { DvmLogo } from './components/DvmLogo';
import { ThemeProvider } from './context/ThemeContext';
import { FuturisticBackground } from './components/FuturisticBackground';
import { DvmAiAssistant } from './components/DvmAiAssistant';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { DashboardFullSkeleton } from './components/DashboardSkeleton';

const SplashScreen = () => {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#030305]"
    >
      <div className="absolute inset-0 bg-noise opacity-[0.03] mix-blend-overlay z-0" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
        <div className="w-[40vw] h-[40vw] bg-[#A855F7]/20 rounded-full blur-[100px] mix-blend-screen animate-pulse" />
      </div>
      
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center"
      >
        <div className="relative group inline-block mb-6">
          <div className="absolute -inset-4 bg-gradient-to-r from-[#A855F7] via-[#3B82F6] to-[#A855F7] rounded-[2rem] blur-xl opacity-60 animate-pulse" />
          <div className="relative w-24 h-24 bg-[rgba(10,10,15,0.8)] backdrop-blur-xl rounded-3xl border border-[rgba(255,255,255,0.15)] flex items-center justify-center shadow-[0_0_40px_rgba(168,85,247,0.3)]">
            <DvmLogo variant="icon" size={60} withGlow={true} animated={true} />
          </div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center gap-3 mb-8"
        >
          <span className="text-3xl font-black tracking-tight text-white font-sans">
            DVM<span className="text-[#A855F7] font-light"> Panel</span>
          </span>
        </motion.div>

        <div className="w-48 h-1 bg-[#ffffff10] rounded-full overflow-hidden">
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 1.2, ease: "easeInOut" }}
            className="h-full bg-gradient-to-r from-[#A855F7] to-[#3B82F6] rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)]"
          />
        </div>
      </motion.div>
    </motion.div>
  );
};

const FloatingParticles = () => {
  return (
    <div className="fixed inset-0 z-[1] pointer-events-none overflow-hidden">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          initial={{
            x: Math.random() * 100 + 'vw',
            y: Math.random() * 100 + 'vh',
            scale: Math.random() * 0.5 + 0.5,
            opacity: Math.random() * 0.3 + 0.1,
          }}
          animate={{
            y: [null, Math.random() * -100 - 50 + 'vh'],
            opacity: [null, Math.random() * 0.8 + 0.2, 0],
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute w-1 h-1 rounded-full bg-[#C084FC] shadow-[0_0_8px_#C084FC]"
        />
      ))}
    </div>
  );
};

function MainApp() {
  const [showSplash, setShowSplash] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'user'>('admin');
  const [currentTab, setCurrentTab] = useState<ViewTab>('dashboard');
  const [isTabLoading, setIsTabLoading] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handleTabChange = (tab: ViewTab) => {
    if (tab === currentTab) return;
    setIsTabLoading(true);
    setCurrentTab(tab);
    setTimeout(() => {
      setIsTabLoading(false);
    }, 280);
  };

  // Core Application State
  const [stats, setStats] = useState<ClusterStats>(INITIAL_STATS);
  const [vms, setVms] = useState<VMInstance[]>(INITIAL_VMS);
  const [nodes, setNodes] = useState<HypervisorNode[]>(INITIAL_NODES);
  const [snapshots, setSnapshots] = useState<VMSnapshot[]>(INITIAL_SNAPSHOTS);
  const [logs, setLogs] = useState<ActivityLog[]>(INITIAL_LOGS);

  // Modals & Drawers State
  const [selectedVM, setSelectedVM] = useState<VMInstance | null>(null);
  const [consoleVM, setConsoleVM] = useState<VMInstance | null>(null);
  const [isCreateVMOpen, setIsCreateVMOpen] = useState(false);
  const [isInstallerOpen, setIsInstallerOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [activeAction, setActiveAction] = useState<{
    type: VPSActionType | null;
    vmName: string;
    vmid?: number | string;
  } | null>(null);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'info' | 'error' | 'alert'>('success');

  // Alert Thresholds State
  const [alertSettings, setAlertSettings] = useState<AlertThresholdSettings>({
    enabled: true,
    cpuLimitPct: 80,
    ramLimitPct: 85,
    notifyOnExceed: true,
  });
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  
  // VPS Expiry Logic
  const [autoSuspendEnabled, setAutoSuspendEnabled] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 1500);
    return () => clearTimeout(timer);
  }, []);
  
  // Expiry Notifications and Auto-Suspend Check
  useEffect(() => {
    if (!isAuthenticated || userRole !== 'admin') return;
    
    let hasShownToasts = false;
    
    const checkExpiries = () => {
      const now = Date.now();
      
      setVms(prevVms => {
        let changed = false;
        const newVms = prevVms.map(vm => {
          if (!vm.expiryDate) return vm;
          
          const expiry = new Date(vm.expiryDate).getTime();
          const diff = expiry - now;
          const remainingDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
          
          // Auto Suspend if expired and currently running
          if (remainingDays <= 0 && vm.status === 'running' && autoSuspendEnabled) {
            changed = true;
            if (!hasShownToasts) {
              setTimeout(() => {
                showToast(`Auto-Suspended ${vm.name} due to subscription expiry.`, 'alert');
              }, 1000);
            }
            return { ...vm, status: 'suspended' };
          }
          
          // Toast Notifications on initial load
          if (!hasShownToasts) {
            setTimeout(() => {
               if (remainingDays === 14) showToast(`${vm.name} expires in exactly 14 days.`, 'info');
               if (remainingDays === 7) showToast(`${vm.name} expires in 7 days. Renewal recommended.`, 'info');
               if (remainingDays === 3) showToast(`Warning: ${vm.name} expires in 3 days.`, 'alert');
               if (remainingDays === 1) showToast(`CRITICAL: ${vm.name} expires tomorrow!`, 'alert');
               if (remainingDays === 0) showToast(`${vm.name} has expired today.`, 'error');
            }, Math.random() * 3000 + 1000); // Stagger toasts slightly
          }
          
          return vm;
        });
        
        hasShownToasts = true;
        return changed ? newVms : prevVms;
      });
    };
    
    checkExpiries();
    
    // Check every hour in a real app, here we just do it once on mount
    // const interval = setInterval(checkExpiries, 3600000);
    // return () => clearInterval(interval);
  }, [isAuthenticated, userRole, autoSuspendEnabled]);

  const showToast = (msg: string, type: 'success' | 'info' | 'error' | 'alert' = 'success') => {
    setToastType(type);
    setToastMessage(msg);
  };

  // Compute VMs currently breaching thresholds
  const breachingVMs = vms.filter(
    (vm) =>
      alertSettings.enabled &&
      vm.status === 'running' &&
      (vm.cpuUsagePct >= alertSettings.cpuLimitPct || vm.ramUsagePct >= alertSettings.ramLimitPct)
  );

  const handleSimulateLoadSpike = () => {
    setVms((prev) => {
      if (prev.length === 0) return prev;
      const runningIdx = prev.findIndex((v) => v.status === 'running');
      if (runningIdx === -1) return prev;

      const copy = [...prev];
      const target = copy[runningIdx];
      const spikedCpu = Math.min(96, alertSettings.cpuLimitPct + 12);
      
      copy[runningIdx] = {
        ...target,
        cpuUsagePct: spikedCpu,
      };

      showToast(
        `🚨 ALERT THRESHOLD EXCEEDED: '${target.name}' CPU load (${spikedCpu}%) exceeds set limit (${alertSettings.cpuLimitPct}%)!`,
        'alert'
      );

      return copy;
    });
  };

  const handleTriggerTestAlert = (vmName: string) => {
    showToast(
      `🚨 ALERT THRESHOLD EXCEEDED: '${vmName}' vCPU load (92.4%) exceeds set limit (${alertSettings.cpuLimitPct}%)!`,
      'alert'
    );
  };

  // VM Power State Handlers
  const handleVMAction = (vmId: string, action: 'start' | 'stop' | 'reboot' | 'pause' | 'delete') => {
    const targetVM = vms.find((v) => v.id === vmId);
    setActiveAction({
      type: action,
      vmName: targetVM?.name || vmId,
      vmid: targetVM?.vmid,
    });

    setVms((prev) => {
      if (action === 'delete') {
        const deleted = prev.find((v) => v.id === vmId);
        showToast(`Virtual Machine ${deleted?.name || vmId} deleted permanently.`);
        return prev.filter((v) => v.id !== vmId);
      }

      return prev.map((vm) => {
        if (vm.id !== vmId) return vm;

        let newStatus = vm.status;
        if (action === 'start') {
          newStatus = 'running';
          showToast(`Power ON command sent to ${vm.name}`);
        } else if (action === 'stop') {
          newStatus = 'stopped';
          showToast(`Power OFF command sent to ${vm.name}`);
        } else if (action === 'reboot') {
          newStatus = 'rebooting';
          showToast(`Reboot signal sent to ${vm.name}`);
          setTimeout(() => {
            setVms((current) =>
              current.map((item) => (item.id === vmId ? { ...item, status: 'running' } : item))
            );
          }, 2000);
        } else if (action === 'pause') {
          newStatus = 'suspended';
          showToast(`Paused execution of ${vm.name}`);
        }

        const updated = { ...vm, status: newStatus };
        if (selectedVM?.id === vmId) {
          setSelectedVM(updated);
        }
        return updated;
      });
    });

    // Add Audit Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: CURRENT_USER.email,
      action: `VM ${action.toUpperCase()}`,
      target: targetVM ? `${targetVM.name} (vmid: ${targetVM.vmid})` : vmId,
      status: 'success',
      ipAddress: '184.72.112.4',
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Create VM Handler
  const handleCreateVM = (vmData: {
    name: string;
    osId: string;
    node: string;
    vcpu: number;
    ramGB: number;
    diskGB: number;
    tags: string[];
    autoBackup: boolean;
  }) => {
    const osTemplate = OS_TEMPLATES.find((o) => o.id === vmData.osId) || OS_TEMPLATES[0];
    const newVmid = 100 + vms.length + 1;

    const newVm: VMInstance = {
      id: `vm-${newVmid}`,
      vmid: newVmid,
      name: vmData.name,
      status: 'running',
      os: vmData.osId as any,
      osName: osTemplate.name,
      ipAddress: `192.168.10.${100 + vms.length + 1}`,
      node: vmData.node,
      vcpu: vmData.vcpu,
      ramGB: vmData.ramGB,
      diskGB: vmData.diskGB,
      cpuUsagePct: 12.5,
      ramUsagePct: 28.0,
      diskUsagePct: 5.0,
      networkRxMbps: 30,
      networkTxMbps: 65,
      uptimeSeconds: 120,
      tags: vmData.tags.length > 0 ? vmData.tags : ['web'],
      autoBackup: vmData.autoBackup,
      createdTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setVms((prev) => [newVm, ...prev]);
    setStats((prev) => ({
      ...prev,
      totalVMs: prev.totalVMs + 1,
      runningVMs: prev.runningVMs + 1,
    }));
    showToast(`Successfully deployed ${newVm.name} (VMID: ${newVm.vmid})`);
  };

  // Snapshot Creation Handler
  const handleCreateSnapshot = (vmId: string, name: string) => {
    const targetVM = vms.find((v) => v.id === vmId);
    const newSnapshot: VMSnapshot = {
      id: `snp-${vmId}-${Date.now()}`,
      vmId,
      vmName: targetVM?.name || vmId,
      name,
      description: 'User initiated ZFS snapshot',
      sizeMB: Math.round(Math.random() * 5000 + 1000),
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type: 'manual',
    };

    setSnapshots((prev) => [newSnapshot, ...prev]);
    showToast(`Created ZFS snapshot '${name}' for ${targetVM?.name}`);
  };

  // Filtered VMs for search
  const searchedVMs = vms.filter((vm) => {
    const q = (searchQuery || '').toLowerCase();
    if (!q) return true;
    return (
      (vm.name || '').toLowerCase().includes(q) ||
      (vm.vmid ? vm.vmid.toString() : '').includes(q) ||
      (vm.ipAddress || '').includes(q) ||
      (vm.node || '').toLowerCase().includes(q) ||
      (vm.tags || []).some((t) => (t || '').toLowerCase().includes(q))
    );
  });

  if (!isAuthenticated) {
    return (
      <>
        <AnimatePresence>
          {showSplash && <SplashScreen />}
        </AnimatePresence>
        <LoginView 
          onLogin={(role = 'admin') => {
            setUserRole(role);
            setIsAuthenticated(true);
          }} 
        />
      </>
    );
  }

  return (
    <div className="min-h-screen text-slate-100 flex flex-col font-sans selection:bg-purple-500/30 selection:text-purple-200 relative overflow-hidden bg-[#030305]">
      {/* Dynamic Futuristic Living Background */}
      <FuturisticBackground />

      {/* Main Floating Container */}
      <div className="flex flex-1 z-10 relative h-screen max-w-[1800px] w-full mx-auto p-4 sm:p-6 gap-4 sm:gap-6 overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={handleTabChange}
          collapsed={sidebarCollapsed}
          onToggleCollapsed={() => setSidebarCollapsed(!sidebarCollapsed)}
          vmCount={vms.length}
          nodeCount={nodes.length}
          userRole={userRole}
          onToggleUserRole={() => setUserRole(userRole === 'admin' ? 'user' : 'admin')}
        />

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-w-0 glass-panel rounded-[1.5rem] overflow-hidden relative border border-white/5 shadow-2xl">
          {/* Header */}
          <Header
            onOpenCreateVM={() => setIsCreateVMOpen(true)}
            onOpenInstaller={() => setIsInstallerOpen(true)}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
            userRole={userRole}
            onToggleUserRole={() => setUserRole(userRole === 'admin' ? 'user' : 'admin')}
          />

          {/* Main Viewport */}
          <main className="flex-1 p-6 lg:p-10 overflow-y-auto overflow-x-hidden custom-scrollbar">
            <div className="max-w-7xl mx-auto w-full space-y-8">
              {userRole === 'user' && ['nodes', 'global_map', 'scheduled_tasks', 'networking', 'storage', 'installer', 'broadcast', 'maintenance', 'logs'].includes(currentTab) ? (
                <motion.div
                  initial={{ opacity: 0, y: 15, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -15, scale: 0.98 }}
                  transition={{ duration: 0.3 }}
                  className="glass-card p-12 lg:p-16 rounded-[2.5rem] border border-[#F43F5E]/30 bg-[rgba(10,13,22,0.85)] backdrop-blur-2xl text-center max-w-2xl mx-auto my-12 space-y-6 shadow-[0_0_50px_rgba(244,63,94,0.15)] relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-[#F43F5E]/10 rounded-full blur-[100px] pointer-events-none" />
                  <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[#F43F5E]/20 to-[#8B5CF6]/20 border border-[#F43F5E]/30 flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(244,63,94,0.3)]">
                    <Lock className="w-10 h-10 text-[#F43F5E]" />
                  </div>

                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#F43F5E]/10 border border-[#F43F5E]/20 text-[#FDA4AF] text-xs font-mono font-bold uppercase tracking-widest">
                      <ShieldAlert className="w-3.5 h-3.5" /> 403 Forbidden Access
                    </div>
                    <h2 className="text-3xl font-black text-white tracking-tight font-sans">Administrator Area Restricted</h2>
                    <p className="text-sm text-[#A1A1AA] leading-relaxed max-w-lg mx-auto font-medium">
                      This portal module (<span className="text-[#22D3EE] font-mono font-bold">{currentTab.toUpperCase()}</span>) requires Root Administrator privileges. Your current active session is authorized as a Client User.
                    </p>
                  </div>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                    <button
                      onClick={() => handleTabChange('dashboard')}
                      className="w-full sm:w-auto px-6 py-3.5 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-white font-bold text-xs uppercase tracking-wider rounded-2xl border border-[rgba(255,255,255,0.1)] transition-all cursor-pointer"
                    >
                      Return to My Cloud Overview
                    </button>
                    <button
                      onClick={() => setUserRole('admin')}
                      className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] hover:from-[#A855F7] hover:to-[#6366F1] text-white font-bold text-xs uppercase tracking-wider rounded-2xl shadow-[0_0_25px_rgba(139,92,246,0.4)] border border-white/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4" /> Switch to Administrator Area
                    </button>
                  </div>
                </motion.div>
              ) : userRole === 'user' && currentTab === 'dashboard' ? (
                <UserDashboardView
                  vms={vms}
                  logs={logs}
                  onSelectVM={(vm) => setSelectedVM(vm)}
                  onOpenConsole={(vm) => setConsoleVM(vm)}
                  onOpenCreateVM={() => setIsCreateVMOpen(true)}
                  onVMAction={handleVMAction}
                  onRenewVM={(vmId) => {
                    setVms(prev => prev.map(vm => {
                      if (vm.id === vmId) {
                        const currentExpiry = vm.expiryDate ? new Date(vm.expiryDate) : new Date();
                        currentExpiry.setDate(currentExpiry.getDate() + 30);
                        return { ...vm, expiryDate: currentExpiry.toISOString() };
                      }
                      return vm;
                    }));
                    showToast('VPS renewed for +30 days', 'success');
                  }}
                />
              ) : (
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentTab}
                    initial={{ opacity: 0, scale: 0.98, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.98, y: -10 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  >
                  {/* OVERVIEW / DASHBOARD TAB */}
                  {currentTab === 'dashboard' && (
                    isTabLoading ? (
                      <DashboardFullSkeleton />
                    ) : (
                    <div className="space-y-8">
                    
                    {/* Premium Hero Section */}
                    <div className="relative overflow-hidden rounded-[2.5rem] glass-card p-10 lg:p-14 group">
                        {/* Animated background glows */}
                        <div className="absolute -top-40 -right-40 w-[40rem] h-[40rem] bg-[#8B5CF6]/10 rounded-full blur-[120px] pointer-events-none group-hover:bg-[#8B5CF6]/20 transition-colors duration-1000" />
                        <div className="absolute -bottom-40 -left-40 w-[30rem] h-[30rem] bg-[#22D3EE]/10 rounded-full blur-[100px] pointer-events-none group-hover:bg-[#22D3EE]/20 transition-colors duration-1000" />
                        
                        <div className="relative z-10 max-w-3xl">
                          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}>
                            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.1)] text-xs font-bold font-sans uppercase tracking-widest text-[#A1A1AA] mb-6 shadow-sm">
                              <Sparkles className="w-4 h-4 text-[#A855F7]" />
                              System Operating Optimally
                            </div>
                            <h1 className="text-4xl lg:text-5xl font-black text-white tracking-tight mb-5 leading-tight">
                              Welcome back to <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C084FC] via-[#A855F7] to-[#3B82F6]">DVM Panel</span>
                            </h1>
                            <p className="text-lg text-[#A1A1AA] font-medium leading-relaxed mb-8 max-w-2xl">
                              Your luxury cloud infrastructure is fully operational. CPU load is balanced across {stats.totalNodes} premium nodes, securely managing {stats.totalVMs} virtual instances with zero downtime.
                            </p>
                            <div className="flex flex-col sm:flex-row items-center gap-4">
                               <motion.button 
                                 whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139,92,246,0.3)' }} 
                                 whileTap={{ scale: 0.98 }} 
                                 onClick={() => setIsCreateVMOpen(true)}
                                 className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#3B82F6] text-white font-bold text-sm tracking-wide rounded-2xl shadow-[0_10px_30px_-10px_rgba(139,92,246,0.5)] border border-[rgba(255,255,255,0.1)] transition-all flex items-center justify-center gap-3"
                               >
                                 <Plus className="w-5 h-5 stroke-[3]" /> Deploy New Instance
                               </motion.button>
                               <motion.button 
                                 whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.08)' }} 
                                 whileTap={{ scale: 0.98 }} 
                                 onClick={() => setCurrentTab('nodes')}
                                 className="w-full sm:w-auto px-8 py-4 bg-[rgba(255,255,255,0.03)] text-white font-bold text-sm tracking-wide rounded-2xl border border-[rgba(255,255,255,0.1)] hover:border-[rgba(255,255,255,0.2)] transition-all flex items-center justify-center gap-3 shadow-inner"
                               >
                                 <Activity className="w-5 h-5 text-[#A855F7]" /> View Telemetry
                               </motion.button>
                            </div>
                          </motion.div>
                        </div>
                    </div>

                    {/* Hero Cluster Stat Cards Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                      <StatCard
                        title="Active Virtual Instances"
                        value={`${vms.filter((v) => v.status === 'running').length} / ${vms.length}`}
                        subValue="All hypervisor nodes online"
                        change="+2 this week"
                        icon={Server}
                        color="purple"
                        progress={(vms.filter((v) => v.status === 'running').length / vms.length) * 100}
                      />

                      <StatCard
                        title="Hypervisor Nodes"
                        value={`${stats.onlineNodes} Nodes`}
                        subValue="US, EU, AP Regions"
                        change="100% Uptime"
                        icon={Cpu}
                        color="purple"
                        progress={100}
                      />

                      <StatCard
                        title="Cluster RAM Pool"
                        value={`${stats.avgRamUsagePct}%`}
                        subValue="1.2 TB Allocated Capacity"
                        change="-4.2% Load"
                        changePositive={true}
                        icon={Activity}
                        color="blue"
                        progress={stats.avgRamUsagePct}
                      />

                      <StatCard
                        title="Global NVMe Storage"
                        value={`${stats.totalStorageUsedTB} TB`}
                        subValue={`Of ${stats.totalStorageCapacityTB} TB Total Pool`}
                        change="30.8% Used"
                        icon={HardDrive}
                        color="emerald"
                        progress={(stats.totalStorageUsedTB / stats.totalStorageCapacityTB) * 100}
                      />
                    </div>

                    {/* Performance Chart, Alert Thresholds & Quick Banner Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      <div className="lg:col-span-2">
                        <MetricsChart />
                      </div>

                      {/* Alert Thresholds Card Widget */}
                      <AlertThresholdsCard
                        settings={alertSettings}
                        onOpenModal={() => setIsAlertModalOpen(true)}
                        breachingVMs={breachingVMs}
                        onSimulateLoad={handleSimulateLoadSpike}
                      />
                    </div>

                    {/* 1-Line Installer Highlight Banner */}
                    <motion.div 
                      whileHover={{ y: -2 }}
                      className="glass-card rounded-[2rem] p-6 lg:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden group transition-all"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6]/10 to-[#3B82F6]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                      <div className="flex items-center gap-4 relative z-10">
                        <div className="w-12 h-12 rounded-2xl bg-[#A855F7]/10 border border-[#A855F7]/20 flex items-center justify-center text-[#A855F7] shrink-0">
                          <Zap className="w-6 h-6 animate-pulse" />
                        </div>
                        <div>
                          <h3 className="text-lg font-black text-white tracking-wide font-sans">
                            Deploy Hypervisor Node in 10 Seconds
                          </h3>
                          <p className="text-xs text-[#A1A1AA] mt-1 leading-relaxed font-medium">
                            Run our official automated bash installation script on any bare-metal Linux server to join it to cluster.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 w-full md:w-auto relative z-10">
                        <div className="p-3 bg-[#050509]/80 border border-[rgba(255,255,255,0.05)] rounded-xl font-mono text-xs text-[#C084FC] truncate max-w-xs shadow-inner">
                          $ curl -sSL https://get.dvm-panel.io/install.sh | sudo bash
                        </div>
                        <motion.button
                          whileHover={{ scale: 1.02, boxShadow: '0 0 25px rgba(139,92,246,0.3)' }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setIsInstallerOpen(true)}
                          className="py-3 px-5 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white text-xs font-bold font-sans tracking-wide uppercase rounded-xl shadow-[0_5px_20px_-5px_rgba(139,92,246,0.4)] transition-all flex items-center justify-center gap-2 shrink-0 border border-[rgba(255,255,255,0.1)]"
                        >
                          <Terminal className="w-4 h-4" />
                          <span>Installer Wizard</span>
                        </motion.button>
                      </div>
                    </motion.div>

                    {/* VMs Overview List */}
                    <div className="space-y-6 pt-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-black text-white tracking-tight font-sans">Virtual Machine Instances</h3>
                          <p className="text-sm text-[#A1A1AA] mt-1 font-medium tracking-wide">Live KVM guest domains and power controls</p>
                        </div>

                        <motion.button
                          whileHover={{ scale: 1.02, x: 2 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setIsCreateVMOpen(true)}
                          className="flex items-center gap-2 text-xs font-bold text-[#A855F7] hover:text-[#C084FC] uppercase tracking-widest font-sans px-4 py-2 bg-[#A855F7]/10 rounded-xl border border-[#A855F7]/20 transition-all hover:bg-[#A855F7]/20 shadow-[0_0_15px_rgba(168,85,247,0.1)]"
                        >
                          <Plus className="w-4 h-4 stroke-[3]" /> Deploy Instance
                        </motion.button>
                      </div>

                      <VMList
                        vms={searchedVMs}
                        onSelectVM={(vm) => setSelectedVM(vm)}
                        onOpenConsole={(vm) => setConsoleVM(vm)}
                        onVMAction={handleVMAction}
                        searchQuery={searchQuery}
                        setSearchQuery={setSearchQuery}
                        onOpenCreateVM={() => setIsCreateVMOpen(true)}
                        alertThresholds={alertSettings}
                        isLoading={isTabLoading}
                      />
                    </div>
                  </div>
                  )
                )}

                {/* VIRTUAL MACHINES TAB */}
                {currentTab === 'vms' && (
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 bg-[rgba(10,13,22,0.6)] backdrop-blur-2xl p-6 lg:p-8 rounded-[2rem] border border-[rgba(255,255,255,0.05)] shadow-xl">
                      <div>
                        <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-3 font-sans">
                          <Server className="w-6 h-6 text-[#C084FC] drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
                          Virtual Machine Manager
                        </h2>
                        <p className="text-sm text-[#A1A1AA] mt-2 font-medium tracking-wide">
                          Manage KVM instances, power status, console VNC, and storage snapshots
                        </p>
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(168,85,247,0.3)' }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setIsCreateVMOpen(true)}
                        className="flex items-center gap-2.5 px-6 py-3 bg-gradient-to-r from-[#8B5CF6] via-[#3B82F6] to-[#4F46E5] hover:from-[#A855F7] hover:to-[#6366F1] text-white font-bold text-sm rounded-2xl shadow-[0_10px_20px_-10px_rgba(168,85,247,0.5)] border border-[rgba(255,255,255,0.1)] transition-all"
                      >
                        <Plus className="w-4 h-4 stroke-[3]" /> <span className="tracking-wide">Provision New VM</span>
                      </motion.button>
                    </div>

                    <VMList
                      vms={searchedVMs}
                      onSelectVM={(vm) => setSelectedVM(vm)}
                      onOpenConsole={(vm) => setConsoleVM(vm)}
                      onVMAction={handleVMAction}
                      searchQuery={searchQuery}
                      setSearchQuery={setSearchQuery}
                      onOpenCreateVM={() => setIsCreateVMOpen(true)}
                      isLoading={isTabLoading}
                    />
                  </div>
                )}

                {/* HYPERVISOR NODES TAB */}
                {currentTab === 'nodes' && (
                  <NodesView nodes={nodes} onOpenInstaller={() => setIsInstallerOpen(true)} isLoading={isTabLoading} />
                )}

                {/* GLOBAL INFRASTRUCTURE TAB */}
                {currentTab === 'global_map' && (
                  <GlobalInfrastructureView nodes={nodes} vms={vms} />
                )}

                {/* SCHEDULED TASKS TAB */}
                {currentTab === 'scheduled_tasks' && (
                  <ScheduledTasksView />
                )}

                {/* BROADCAST CENTER TAB */}
                {currentTab === 'broadcast' && (
                  <BroadcastCenterView />
                )}

                {/* MAINTENANCE MANAGER TAB */}
                {currentTab === 'maintenance' && (
                  <MaintenanceManagerView />
                )}

                {/* NETWORKING TAB */}
                {currentTab === 'networking' && <NetworkingView isLoading={isTabLoading} />}

                {/* STORAGE TAB */}
                {currentTab === 'storage' && <StorageView isLoading={isTabLoading} />}

                {/* EXPIRING VPS TAB */}
                {currentTab === 'expiring' && (
                  <AdminExpiringView 
                    vms={vms} 
                    onVMAction={handleVMAction} 
                    isLoading={isTabLoading}
                    onRenewVM={(vmId, days) => {
                      setVms(prev => prev.map(vm => {
                        if (vm.id === vmId) {
                           const currentExpiry = vm.expiryDate ? new Date(vm.expiryDate) : new Date();
                           const wasExpired = vm.expiryDate ? new Date(vm.expiryDate).getTime() <= Date.now() : false;
                           currentExpiry.setDate(currentExpiry.getDate() + days);
                           return { ...vm, expiryDate: currentExpiry.toISOString(), status: (wasExpired && vm.status === 'suspended') ? 'running' : vm.status };
                        }
                        return vm;
                      }));
                      showToast(`Successfully renewed VM for ${days} days.`, 'success');
                    }}
                  />
                )}

                {/* ONE-LINE INSTALLER TAB */}
                {currentTab === 'installer' && (
                  <div className="space-y-6">
                    <div className="p-6 bg-[rgba(0,0,0,0.7)] backdrop-blur-xl border border-[#A855F7]/30 rounded-3xl space-y-4 shadow-2xl">
                      <div className="flex items-center gap-3">
                        <Terminal className="w-8 h-8 text-[#C084FC]" />
                        <div>
                          <h2 className="text-lg font-bold text-[#FFFFFF]">DVM Panel One-Line Automated Installer</h2>
                          <p className="text-xs text-[#A1A1AA]">Master controller & hypervisor node worker setup script</p>
                        </div>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => setIsInstallerOpen(true)}
                        className="px-6 py-3 bg-gradient-to-r from-[#8B5CF6] to-[#4F46E5] text-white font-semibold text-xs rounded-2xl shadow-lg shadow-[#8B5CF6]/20"
                      >
                        Open Interactive Installer Wizard
                      </motion.button>
                    </div>
                  </div>
                )}

                {/* AUDIT LOGS TAB */}
                {currentTab === 'logs' && <LogsView logs={logs} isLoading={isTabLoading} />}

                {/* SETTINGS TAB */}
                {currentTab === 'settings' && (
                  userRole === 'user' ? <UserSettingsView /> : <SettingsView userRole={userRole} />
                )}
              </motion.div>
            </AnimatePresence>
          )}
            </div>
          </main>
        </div>
      </div>

      {/* Modals */}
      <VMDetailModal
        vm={selectedVM}
        onClose={() => setSelectedVM(null)}
        onOpenConsole={(vm) => setConsoleVM(vm)}
        onVMAction={handleVMAction}
        snapshots={snapshots}
        onCreateSnapshot={handleCreateSnapshot}
      />

      <CreateVMModal
        isOpen={isCreateVMOpen}
        onClose={() => setIsCreateVMOpen(false)}
        onCreateVM={handleCreateVM}
      />

      <InstallerModal
        isOpen={isInstallerOpen}
        onClose={() => setIsInstallerOpen(false)}
      />

      <WebConsoleModal
        vm={consoleVM}
        onClose={() => setConsoleVM(null)}
      />

      <AlertThresholdsModal
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
        settings={alertSettings}
        onUpdateSettings={(newSet) => {
          setAlertSettings(newSet);
          showToast('Alert threshold limits updated successfully', 'success');
        }}
        vms={vms}
        onTriggerTestAlert={handleTriggerTestAlert}
      />

      <VPSActionOverlay
        isOpen={Boolean(activeAction)}
        actionType={activeAction?.type || null}
        vmName={activeAction?.vmName || ''}
        vmid={activeAction?.vmid}
        onClose={() => setActiveAction(null)}
        onOpenConsole={() => {
          const target = vms.find((v) => v.name === activeAction?.vmName || v.vmid === activeAction?.vmid);
          if (target) setConsoleVM(target);
        }}
      />

      <NotificationToast
        message={toastMessage}
        type={toastType}
        onClose={() => setToastMessage(null)}
      />

      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        vms={vms}
        nodes={nodes}
        onSelectTab={handleTabChange}
        onSelectVM={(vm) => setSelectedVM(vm)}
        onOpenCreateVM={() => setIsCreateVMOpen(true)}
        onOpenInstaller={() => setIsInstallerOpen(true)}
        userRole={userRole}
      />

      <DvmAiAssistant vms={vms} stats={stats} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}
