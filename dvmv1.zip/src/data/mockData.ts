import { VMInstance, HypervisorNode, NetworkInterface, FirewallRule, StoragePool, VMSnapshot, ActivityLog, ClusterStats, UserAccount } from '../types';

export const OS_TEMPLATES = [
  { id: 'ubuntu-24.04', name: 'Ubuntu 24.04 LTS', category: 'Linux Server', icon: '🐧' },
  { id: 'debian-12', name: 'Debian 12 Bookworm', category: 'Linux Server', icon: '🌀' },
  { id: 'almalinux-9', name: 'AlmaLinux 9.4', category: 'Enterprise Linux', icon: '🛡️' },
  { id: 'windows-2022', name: 'Windows Server 2022', category: 'Windows Server', icon: '🪟' },
  { id: 'arch-linux', name: 'Arch Linux Rolling', category: 'Arch Linux', icon: '🏹' },
  { id: 'alpine-3.20', name: 'Alpine Linux 3.20', category: 'Minimal Container', icon: '🏔️' },
];

export const INITIAL_STATS: ClusterStats = {
  totalVMs: 28,
  runningVMs: 24,
  totalNodes: 6,
  onlineNodes: 6,
  avgCpuUsagePct: 38.4,
  avgRamUsagePct: 62.1,
  totalStorageUsedTB: 14.8,
  totalStorageCapacityTB: 48.0,
  totalNetworkRxMbps: 842.5,
  totalNetworkTxMbps: 1240.2,
};

export const INITIAL_VMS: VMInstance[] = [
  {
    id: 'vm-101',
    vmid: 101,
    name: 'dvm-prod-api-01',
    status: 'running',
    os: 'ubuntu-24.04',
    osName: 'Ubuntu 24.04 LTS',
    ipAddress: '192.168.10.15',
    ipv6Address: '2001:db8:85a3::8a2e:370:7334',
    node: 'node-us-east-1a',
    vcpu: 8,
    ramGB: 16,
    diskGB: 160,
    cpuUsagePct: 24.5,
    ramUsagePct: 58.2,
    diskUsagePct: 42.1,
    networkRxMbps: 124.8,
    networkTxMbps: 310.4,
    uptimeSeconds: 1249200, // 14.4 days
    tags: ['production', 'backend', 'api'],
    autoBackup: true,
    notes: 'Primary REST API Gateway cluster node',
    createdTime: '2026-03-12 14:20',
    expiryDate: '2026-08-15 14:20',
    renewalDate: '2026-07-15 14:20',
  },
  {
    id: 'vm-102',
    vmid: 102,
    name: 'dvm-db-postgres-primary',
    status: 'running',
    os: 'almalinux-9',
    osName: 'AlmaLinux 9.4 (Vanilla)',
    ipAddress: '192.168.10.20',
    ipv6Address: '2001:db8:85a3::8a2e:370:7335',
    node: 'node-us-east-1b',
    vcpu: 16,
    ramGB: 64,
    diskGB: 500,
    cpuUsagePct: 64.2,
    ramUsagePct: 81.6,
    diskUsagePct: 68.4,
    networkRxMbps: 380.2,
    networkTxMbps: 512.9,
    uptimeSeconds: 2592000, // 30 days
    tags: ['database', 'high-priority', 'nvme'],
    autoBackup: true,
    notes: 'PostgreSQL 16 Cluster Leader with WAL streaming',
    createdTime: '2026-01-08 09:15',
    expiryDate: '2026-08-04 09:15',
    renewalDate: '2026-07-04 09:15',
  },
  {
    id: 'vm-103',
    vmid: 103,
    name: 'dvm-k8s-worker-01',
    status: 'running',
    os: 'ubuntu-24.04',
    osName: 'Ubuntu 24.04 LTS',
    ipAddress: '192.168.20.101',
    node: 'node-eu-west-1a',
    vcpu: 4,
    ramGB: 8,
    diskGB: 80,
    cpuUsagePct: 18.2,
    ramUsagePct: 44.0,
    diskUsagePct: 31.0,
    networkRxMbps: 45.1,
    networkTxMbps: 62.8,
    uptimeSeconds: 864000,
    tags: ['kubernetes', 'worker'],
    autoBackup: true,
    notes: 'Kubernetes ingress worker node',
    createdTime: '2026-04-01 11:00',
    expiryDate: '2026-08-10 11:00',
    renewalDate: '2026-07-10 11:00',
  },
  {
    id: 'vm-104',
    vmid: 104,
    name: 'dvm-redis-cache-cluster',
    status: 'running',
    os: 'alpine-3.20',
    osName: 'Alpine Linux 3.20',
    ipAddress: '192.168.10.35',
    node: 'node-us-east-1a',
    vcpu: 2,
    ramGB: 16,
    diskGB: 40,
    cpuUsagePct: 12.0,
    ramUsagePct: 74.5,
    diskUsagePct: 15.2,
    networkRxMbps: 180.3,
    networkTxMbps: 210.0,
    uptimeSeconds: 1814400,
    tags: ['cache', 'in-memory'],
    autoBackup: false,
    notes: 'Redis v7.2 in-memory caching instance',
    createdTime: '2026-02-15 18:30',
    expiryDate: '2026-08-01 18:30',
    renewalDate: '2026-07-01 18:30',
  },
  {
    id: 'vm-105',
    vmid: 105,
    name: 'dvm-win-ad-dc01',
    status: 'running',
    os: 'windows-2022',
    osName: 'Windows Server 2022 Datacenter',
    ipAddress: '192.168.30.5',
    node: 'node-us-central-1',
    vcpu: 4,
    ramGB: 16,
    diskGB: 200,
    cpuUsagePct: 8.5,
    ramUsagePct: 52.3,
    diskUsagePct: 48.9,
    networkRxMbps: 12.4,
    networkTxMbps: 18.9,
    uptimeSeconds: 4320000,
    tags: ['windows', 'active-directory', 'internal'],
    autoBackup: true,
    notes: 'Primary Active Directory Domain Controller',
    createdTime: '2025-11-20 08:00',
    expiryDate: '2026-11-20 08:00',
    renewalDate: '2025-11-20 08:00',
  },
  {
    id: 'vm-106',
    vmid: 106,
    name: 'dvm-staging-env',
    status: 'stopped',
    os: 'debian-12',
    osName: 'Debian 12 Bookworm',
    ipAddress: '192.168.10.88',
    node: 'node-eu-west-1a',
    vcpu: 2,
    ramGB: 4,
    diskGB: 50,
    cpuUsagePct: 0.0,
    ramUsagePct: 0.0,
    diskUsagePct: 28.5,
    networkRxMbps: 0.0,
    networkTxMbps: 0.0,
    uptimeSeconds: 0,
    tags: ['staging', 'testing'],
    autoBackup: false,
    notes: 'QA & Staging preview cluster',
    createdTime: '2026-05-10 16:45',
    expiryDate: '2026-07-28 16:45',
    renewalDate: '2026-06-28 16:45',
  },
  {
    id: 'vm-107',
    vmid: 107,
    name: 'dvm-builder-runner-01',
    status: 'provisioning',
    os: 'arch-linux',
    osName: 'Arch Linux Rolling',
    ipAddress: '192.168.20.210',
    node: 'node-ap-south-1',
    vcpu: 8,
    ramGB: 32,
    diskGB: 250,
    cpuUsagePct: 88.0,
    ramUsagePct: 35.0,
    diskUsagePct: 12.0,
    networkRxMbps: 450.0,
    networkTxMbps: 120.0,
    uptimeSeconds: 120,
    tags: ['cicd', 'github-runner'],
    autoBackup: false,
    notes: 'High-performance ephemeral build agent',
    createdTime: '2026-07-31 05:30',
    expiryDate: '2026-08-31 05:30',
    renewalDate: '2026-07-31 05:30',
  },
  {
    id: 'vm-108',
    vmid: 108,
    name: 'dvm-mail-gateway',
    status: 'running',
    os: 'debian-12',
    osName: 'Debian 12 Bookworm',
    ipAddress: '192.168.10.42',
    node: 'node-us-east-1a',
    vcpu: 2,
    ramGB: 4,
    diskGB: 100,
    cpuUsagePct: 5.2,
    ramUsagePct: 38.1,
    diskUsagePct: 55.4,
    networkRxMbps: 8.5,
    networkTxMbps: 24.1,
    uptimeSeconds: 3110400,
    tags: ['mail', 'postfix', 'security'],
    autoBackup: true,
    notes: 'Secure outbound SMTP & DKIM signing server',
    createdTime: '2026-02-01 10:00',
    expiryDate: '2026-08-25 10:00',
    renewalDate: '2026-07-25 10:00',
  }
];

export const INITIAL_NODES: HypervisorNode[] = [
  {
    id: 'node-1',
    name: 'node-us-east-1a',
    region: 'US East (N. Virginia)',
    status: 'online',
    ipAddress: '10.100.0.11',
    kvmVersion: 'QEMU 9.0 / Linux 6.8 LTS',
    totalVcpu: 128,
    usedVcpu: 72,
    totalRamGB: 512,
    usedRamGB: 340,
    totalStorageTB: 12.0,
    usedStorageTB: 4.8,
    vmCount: 9,
    loadAverage: [1.42, 1.28, 1.15],
    uptimeDays: 142,
  },
  {
    id: 'node-2',
    name: 'node-us-east-1b',
    region: 'US East (N. Virginia)',
    status: 'online',
    ipAddress: '10.100.0.12',
    kvmVersion: 'QEMU 9.0 / Linux 6.8 LTS',
    totalVcpu: 128,
    usedVcpu: 84,
    totalRamGB: 512,
    usedRamGB: 410,
    totalStorageTB: 12.0,
    usedStorageTB: 6.2,
    vmCount: 7,
    loadAverage: [2.85, 2.10, 1.90],
    uptimeDays: 98,
  },
  {
    id: 'node-3',
    name: 'node-eu-west-1a',
    region: 'EU West (Ireland)',
    status: 'online',
    ipAddress: '10.200.0.15',
    kvmVersion: 'QEMU 8.2 / Linux 6.6 LTS',
    totalVcpu: 64,
    usedVcpu: 32,
    totalRamGB: 256,
    usedRamGB: 128,
    totalStorageTB: 8.0,
    usedStorageTB: 2.1,
    vmCount: 5,
    loadAverage: [0.85, 0.92, 0.88],
    uptimeDays: 210,
  },
  {
    id: 'node-4',
    name: 'node-us-central-1',
    region: 'US Central (Iowa)',
    status: 'online',
    ipAddress: '10.150.0.8',
    kvmVersion: 'QEMU 9.0 / Linux 6.8 LTS',
    totalVcpu: 96,
    usedVcpu: 48,
    totalRamGB: 384,
    usedRamGB: 198,
    totalStorageTB: 8.0,
    usedStorageTB: 3.4,
    vmCount: 4,
    loadAverage: [1.10, 1.05, 0.98],
    uptimeDays: 64,
  },
  {
    id: 'node-5',
    name: 'node-ap-south-1',
    region: 'Asia Pacific (Mumbai)',
    status: 'degraded',
    ipAddress: '10.300.0.22',
    kvmVersion: 'QEMU 8.2 / Linux 6.6 LTS',
    totalVcpu: 64,
    usedVcpu: 56,
    totalRamGB: 256,
    usedRamGB: 220,
    totalStorageTB: 6.0,
    usedStorageTB: 4.9,
    vmCount: 3,
    loadAverage: [4.80, 4.25, 3.90],
    uptimeDays: 31,
  },
  {
    id: 'node-6',
    name: 'node-sa-east-1',
    region: 'South America (São Paulo)',
    status: 'online',
    ipAddress: '10.400.0.4',
    kvmVersion: 'QEMU 9.0 / Linux 6.8 LTS',
    totalVcpu: 32,
    usedVcpu: 12,
    totalRamGB: 128,
    usedRamGB: 48,
    totalStorageTB: 4.0,
    usedStorageTB: 0.9,
    vmCount: 2,
    loadAverage: [0.45, 0.50, 0.48],
    uptimeDays: 15,
  }
];

export const INITIAL_NETWORKS: NetworkInterface[] = [
  {
    id: 'net-1',
    name: 'vmbr0-public',
    bridge: 'vmbr0',
    subnetCIDR: '192.168.10.0/24',
    gateway: '192.168.10.1',
    dhcpEnabled: true,
    totalIPs: 254,
    usedIPs: 48,
    type: 'public',
  },
  {
    id: 'net-2',
    name: 'vmbr1-private-k8s',
    bridge: 'vmbr1',
    vlanId: 100,
    subnetCIDR: '192.168.20.0/24',
    gateway: '192.168.20.1',
    dhcpEnabled: true,
    totalIPs: 254,
    usedIPs: 112,
    type: 'private',
  },
  {
    id: 'net-3',
    name: 'vmbr2-internal-db',
    bridge: 'vmbr2',
    vlanId: 200,
    subnetCIDR: '10.50.0.0/16',
    gateway: '10.50.0.1',
    dhcpEnabled: false,
    totalIPs: 65534,
    usedIPs: 320,
    type: 'isolated',
  }
];

export const INITIAL_FIREWALL_RULES: FirewallRule[] = [
  {
    id: 'fw-1',
    direction: 'inbound',
    action: 'ACCEPT',
    protocol: 'TCP',
    portRange: '22 (SSH)',
    sourceCIDR: '10.0.0.0/8',
    description: 'Allow internal management SSH',
    enabled: true,
  },
  {
    id: 'fw-2',
    direction: 'inbound',
    action: 'ACCEPT',
    protocol: 'TCP',
    portRange: '80, 443 (HTTP/HTTPS)',
    sourceCIDR: '0.0.0.0/0',
    description: 'Allow public web traffic',
    enabled: true,
  },
  {
    id: 'fw-3',
    direction: 'inbound',
    action: 'ACCEPT',
    protocol: 'TCP',
    portRange: '5432 (PostgreSQL)',
    sourceCIDR: '192.168.10.0/24',
    description: 'Database connection from API layer',
    enabled: true,
  },
  {
    id: 'fw-4',
    direction: 'inbound',
    action: 'DROP',
    protocol: 'ANY',
    portRange: '1-65535',
    sourceCIDR: '0.0.0.0/0',
    description: 'Default deny all unspecified ingress',
    enabled: true,
  }
];

export const INITIAL_STORAGE: StoragePool[] = [
  {
    id: 'st-1',
    name: 'nvme-pool-fast-01',
    type: 'nvme-raid10',
    node: 'node-us-east-1a',
    totalGB: 8000,
    usedGB: 3420,
    freeGB: 4580,
    health: 'HEALTH_OK',
  },
  {
    id: 'st-2',
    name: 'ceph-cluster-replicated',
    type: 'ceph-distributed',
    node: 'Global Cluster',
    totalGB: 32000,
    usedGB: 11200,
    freeGB: 20800,
    health: 'HEALTH_OK',
  },
  {
    id: 'st-3',
    name: 'zfs-tank-primary',
    type: 'zfs-pool',
    node: 'node-us-east-1b',
    totalGB: 16000,
    usedGB: 9800,
    freeGB: 6200,
    health: 'HEALTH_OK',
  },
  {
    id: 'st-4',
    name: 'nfs-backup-vault',
    type: 'nfs-backup',
    node: 'node-eu-west-1a',
    totalGB: 24000,
    usedGB: 18400,
    freeGB: 5600,
    health: 'HEALTH_WARN',
  }
];

export const INITIAL_SNAPSHOTS: VMSnapshot[] = [
  {
    id: 'snp-101-1',
    vmId: 'vm-101',
    vmName: 'dvm-prod-api-01',
    name: 'pre-v2.4-deploy',
    description: 'Automated snapshot before REST API v2.4 rollout',
    sizeMB: 4820,
    createdAt: '2026-07-28 02:00',
    type: 'scheduled',
  },
  {
    id: 'snp-102-1',
    vmId: 'vm-102',
    vmName: 'dvm-db-postgres-primary',
    name: 'weekly-db-freeze',
    description: 'Consistent cold snapshot of DB WAL volume',
    sizeMB: 28400,
    createdAt: '2026-07-26 00:00',
    type: 'scheduled',
  },
  {
    id: 'snp-105-1',
    vmId: 'vm-105',
    vmName: 'dvm-win-ad-dc01',
    name: 'pre-windows-patch',
    description: 'Manual snapshot prior to KB503412 Patch Tuesday',
    sizeMB: 12100,
    createdAt: '2026-07-15 14:30',
    type: 'manual',
  }
];

export const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'log-1',
    timestamp: '2026-07-31 05:40:12',
    user: 'admin@dvm-panel.io',
    action: 'VM Power On',
    target: 'dvm-prod-api-01 (vmid: 101)',
    status: 'success',
    ipAddress: '184.72.112.4',
  },
  {
    id: 'log-2',
    timestamp: '2026-07-31 05:28:45',
    user: 'devops-lead@dvm-panel.io',
    action: 'Create Snapshot',
    target: 'dvm-db-postgres-primary',
    status: 'success',
    ipAddress: '52.91.22.80',
  },
  {
    id: 'log-3',
    timestamp: '2026-07-31 04:15:02',
    user: 'system-agent',
    action: 'Automated Health Check',
    target: 'node-ap-south-1',
    status: 'warning',
    ipAddress: '10.300.0.22',
  },
  {
    id: 'log-4',
    timestamp: '2026-07-31 02:00:00',
    user: 'cron-scheduler',
    action: 'ZFS Backup Sync',
    target: 'zfs-tank-primary',
    status: 'success',
    ipAddress: '127.0.0.1',
  }
];

export const CURRENT_USER: UserAccount = {
  id: 'usr-001',
  name: 'Alex Mercer',
  email: 'admin@dvm-panel.io',
  role: 'Administrator',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  twoFactorEnabled: true,
  lastActive: 'Just now',
};

export const ONE_LINE_INSTALL_COMMAND = `curl -sSL https://get.dvm-panel.io/install.sh | sudo bash`;

export const INSTALLER_SCRIPT_CONTENT = `#!/usr/bin/env bash
# ==============================================================================
# DVM Panel — Modern Automated Hypervisor & VM Controller Installer
# Version: 3.2.0-stable
# Repo: https://github.com/dvm-panel/dvm-core
# ==============================================================================

set -euo pipefail

# Visual Color Variables
RED='\\033[0;31m'
GREEN='\\033[0;32m'
PURPLE='\\033[0;35m'
CYAN='\\033[0;36m'
BOLD='\\033[1m'
NC='\\033[0m'

echo -e "\${PURPLE}"
cat << "EOF"
  ____  ____   ____     ____                      _ 
 |  _ \\/ ___| / ___|   |  _ \\ __ _ _ __   ___| |
 | | | \\___ \\ \\___ \\   | |_) / _\` | '_ \\ / _ \\ |
 | |_| |___) |___) |   |  __/ (_| | | | |  __/ |
 |____/|____/|____/    |_|   \\__,_|_| |_|\\___|_|
                                                
 Next-Gen Hypervisor & Cloud VM Controller v3.2
EOF
echo -e "\${NC}"

echo -e "\${CYAN}[*] Initializing DVM Panel Environment Checks...\${NC}"

if [ "\$(id -u)" -ne 0 ]; then
  echo -e "\${RED}[!] Error: DVM Installer requires root privileges. Please run with sudo.\${NC}"
  exit 1
fi

echo -e "\${GREEN}[✓] Root privileges verified.\${NC}"
echo -e "\${CYAN}[*] Detecting Architecture & OS Kernel...\${NC}"
ARCH=\$(uname -m)
KERNEL=\$(uname -r)
echo -e "    Architecture: \${BOLD}\${ARCH}\${NC}"
echo -e "    Kernel:       \${BOLD}\${KERNEL}\${NC}"

echo -e "\${CYAN}[*] Installing Core Dependencies (KVM, QEMU-KVM, libvirt, Open vSwitch, WireGuard)...\${NC}"
# Simulating installation progress
echo -e "\${GREEN}[✓] KVM Hardware Virtualization extensions enabled.\${NC}"
echo -e "\${GREEN}[✓] DVM Master Control Plane bootstrapped on port 8443.\${NC}"
echo -e "\${GREEN}[✓] Default virtual bridge 'vmbr0' initialized.\${NC}"

echo -e "\${PURPLE}\${BOLD}"
echo "=========================================================================="
echo "      DVM Panel Installation Completed Successfully!                     "
echo "=========================================================================="
echo -e "\${NC}"
echo -e " Access Your DVM Dashboard:  \${CYAN}https://\$(hostname -I | awk '{print \$1}'):8443\${NC}"
echo -e " Default Admin User:         \${BOLD}admin@dvm-panel.io\${NC}"
echo -e " Temporary Secret Pass:      \${BOLD}DVM-Panel-\$(openssl rand -hex 4)\${NC}"
echo ""
`;
